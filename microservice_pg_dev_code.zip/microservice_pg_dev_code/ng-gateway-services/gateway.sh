java -javaagent:./elastic-apm-agent-1.36.0.jar \
-Delastic.apm.service_name=java-application-admin \
-Delastic.apm.server_urls=http://192.168.184.224:8200 \
-Delastic.apm.environment=development \
-Delastic.apm.application_packages=com.ng.gateway \
-jar target/ng-gateway-services-0.0.1-SNAPSHOT.jar

