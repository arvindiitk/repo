cd ng-config-server
mvn install
nohup java -jar target/ng-config-server-0.0.1-SNAPSHOT.jar >ng-config-server.out &

cd ../ng-registry-service
mvn install
nohup java -jar target/ng-registry-service-0.0.1-SNAPSHOT.jar >ng-registry.out & 

cd ../ng-gateway-services
mvn install
nohup java -jar target/ng-gateway-services-0.0.1-SNAPSHOT.jar >ng-gateway.out &

