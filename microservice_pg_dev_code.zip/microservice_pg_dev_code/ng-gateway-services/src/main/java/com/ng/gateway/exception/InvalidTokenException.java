package com.ng.gateway.exception;

import org.apache.http.auth.AuthenticationException;

public class InvalidTokenException extends AuthenticationException {
    /**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public InvalidTokenException(String message) {
        super(message);
    }

    public InvalidTokenException(String message, Throwable cause) {
        super(message, cause);
    }
}