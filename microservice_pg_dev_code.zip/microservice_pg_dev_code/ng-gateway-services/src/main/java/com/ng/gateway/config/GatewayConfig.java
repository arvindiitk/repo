package com.ng.gateway.config;

import com.ng.gateway.filter.JwtAuthenticationFilter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {

	@Autowired
	private JwtAuthenticationFilter filter;

	@Bean
	public RouteLocator routes(RouteLocatorBuilder builder) {
		return builder.routes()
				.route("NG-AUTH-SERVICE",r -> r
						.path("/auth/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NG-AUTH-SERVICE")
										.setFallbackUri("forward:/ngAuthService"))
								)
						.uri("lb://NG-AUTH-SERVICE"))
				.route("NG-ORG-TYPE-SERVICE", r -> r
						.path("/ng-org-type/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NG-ORG-TYPE-SERVICE")
										.setFallbackUri("forword/ngOrganizationtype"))
								)
						.uri("lb://NG-ORG-TYPE-SERVICE")) 
				.route("NG-USECASE-CONFIG-SERVICE", r ->r
						.path("/usecaseAPI/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NG-USECASE-CONFIG-SERVICE")
										.setFallbackUri("forword/ngUseCaseService"))
								)
						.uri("lb://NG-USECASE-CONFIG-SERVICE"))
				.route("NG-PORTAL-SERVICE", r ->r
						.path("/ng-portal/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NG-PORTAL-SERVICE")
										.setFallbackUri("forword/ngPortalService"))
								)
						.uri("lb://NG-PORTAL-SERVICE"))
				.route("NG-MENU-SERVICE", r ->r
						.path("/ng-menu/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NG-MENU-SERVICE")
										.setFallbackUri("forword/ngMenuService"))
								)
						.uri("lb://NG-MENU-SERVICE"))
				.route("NG-ROLE-SERVICE", r ->r
						.path("/ng-role/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NG-ROLE-SERVICE")
										.setFallbackUri("forword/ngRoleService"))
								)
						.uri("lb://NG-ROLE-SERVICE"))
				.route("NG-ORG-SERVICE", r ->r
						.path("/ng-org/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NG-ORG-SERVICE")
										.setFallbackUri("forword/ngOrgService"))
								)
						.uri("lb://NG-ORG-SERVICE"))
				.route("NG-USER-MGMT-SERVICE", r ->r
						.path("/ng-user-mgmt/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NG-USER-MGMT-SERVICE")
										.setFallbackUri("forword/ngUserMgmtService"))
								)
						.uri("lb://NG-USER-MGMT-SERVICE"))
				.route("NG-KEYCLOAK-TOKEN-SERVICE", r ->r
						.path("/ng-keyCloak-type/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NG-KEYCLOAK-TOKEN-SERVICE")
										.setFallbackUri("forword/ngKeycloakService"))
								)
						.uri("lb://NG-KEYCLOAK-TOKEN-SERVICE"))
				.route("NG-NOTIFICATION-SERVICE", r ->r
                        .path("/ng-notification/**")
                        .filters(f -> f
                                        .filter(filter)
                                        .circuitBreaker(config ->config
                                                        .setName("NG-NOTIFICATION-SERVICE")
                                                        .setFallbackUri("forword/ngNotificationService"))
                                        )
                        .uri("lb://NG-NOTIFICATION-SERVICE"))
				.route("NG-WORKFLOW-SERVICE", r ->r
                        .path("/ng-workflow/**")
                        .filters(f -> f
                        		.filter(filter)
                        		.circuitBreaker(config ->config
                        				.setName("NG-WORKFLOW-SERVICE")
                        				.setFallbackUri("forword/ngWorkflowService"))
                        		)
                        .uri("lb://NG-WORKFLOW-SERVICE"))
				.route("NG-REQUEST-STATUS-SERVICE", r ->r
                        .path("/ng-requestStatus/**")
                        .filters(f -> f
                        		.filter(filter)
                        		.circuitBreaker(config ->config
                        				.setName("NG-REQUEST-STATUS-SERVICE")
                        				.setFallbackUri("forword//ngRequestStatus"))
                        		)
                        .uri("lb://NG-REQUEST-STATUS-SERVICE"))
				.route("NG-RESTRICTED-USER-SERVICE", r ->r
                        .path("/ng-restrictedUser/**")
                        .filters(f -> f
                        		.filter(filter)
                        		.circuitBreaker(config ->config
                        				.setName("NG-RESTRICTED-USER-SERVICE")
                        				.setFallbackUri("forword/ngRestrictedUser"))
                        		)
                        .uri("lb://NG-RESTRICTED-USER-SERVICE"))
				.route("NG-USER-STATUS-SERVICE", r ->r
                        .path("/ng-userStatus/**")
                        .filters(f -> f
                        		.filter(filter)
                        		.circuitBreaker(config ->config
                        				.setName("NG-USER-STATUS-SERVICE")
                        				.setFallbackUri("forword/ngUserStatus"))
                        		)
                        .uri("lb://NG-USER-STATUS-SERVICE"))
				.route("NGUA-CASE-SERVICE", r ->r
						.path("/ngua-case/**")
						.filters(f -> f
                                .filter(filter)
                                .circuitBreaker(config ->config
                                		.setName("NGUA-CASE-SERVICE")
                                		.setFallbackUri("forword/nguaCaseService"))
								)
						.uri("lb://NGUA-CASE-SERVICE"))
				.route("NGUA-CASE-NOTE-SERVICE", r ->r
						.path("/ngua-caseNote/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NGUA-CASE-NOTE-SERVICE")
										.setFallbackUri("forword/nguaCaseNote"))
								)
						.uri("lb://NGUA-CASE-NOTE-SERVICE"))
				.route("NGUA-CASE-PARTICIPANT-SERVICE", r ->r
						.path("/ngua-caseParticipant/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NGUA-CASE-PARTICIPANT-SERVICE")
										.setFallbackUri("forword/nguaCaseParticipant"))
								)
						.uri("lb://NGUA-CASE-PARTICIPANT-SERVICE"))
				.route("NGUA-CASE-TRANSFER-SERVICE", r ->r
						.path("/ngua-caseTransfer/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NGUA-CASE-TRANSFER-SERVICE")
										.setFallbackUri("forword/nguaCaseTransfer"))
								)
						.uri("lb://NGUA-CASE-TRANSFER-SERVICE"))
				.route("NG-PO-MASTER-SERVICE", r ->r
						.path("/ng-master/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NG-PO-MASTER-SERVICE")
										.setFallbackUri("forword/ngPoMasterService"))
								)
						.uri("lb://NG-PO-MASTER-SERVICE"))
				.route("NGUA-CASE-REVOKE-SERVICE", r ->r
						.path("/ngua-caseRevoke/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NGUA-CASE-REVOKE-SERVICE")
										.setFallbackUri("forword/nguaCaseRevokeService"))
								)
						.uri("lb://NGUA-CASE-REVOKE-SERVICE"))
				.route("NGUA-CASE-REQUEST-SERVICE", r ->r
						.path("/ngua-case-request/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config ->config
										.setName("NGUA-CASE-REQUEST-SERVICE")
										.setFallbackUri("forword/nguaCaseRequestService"))
								)
						.uri("lb://NGUA-CASE-REQUEST-SERVICE"))
				.route("NGUA-ENTITY-RESOLUTION-SERVICE", r -> r
						.path("/ngua-entity-resolution/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-ENTITY-RESOLUTION-SERVICE")
										.setFallbackUri("forword/nguaEntityResolution"))
						)
						.uri("lb://NGUA-ENTITY-RESOLUTION-SERVICE"))
				.route("NGUA-WORKFLOW-SERVICE", r -> r
						.path("/ngua-workflow/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-WORKFLOW-SERVICE")
										.setFallbackUri("forword/nguaWorkFlowService"))
						)
						.uri("lb://NGUA-WORKFLOW-SERVICE"))
				.route("NG-FEEDBACK-SERVICE", r -> r
						.path("/ng-feedback/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NG-FEEDBACK-SERVICE")
										.setFallbackUri("forword/ngFeedbackService"))
						)
						.uri("lb://NG-FEEDBACK-SERVICE"))
				.route("NG-ENCRYPTION-DECRYPTION-SERVICE", r -> r
						.path("/ng-encryption-decryption/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NG-ENCRYPTION-DECRYPTION-SERVICE")
										.setFallbackUri("forword/ngEncryptionDecryptionService"))
						)
						.uri("lb://NG-ENCRYPTION-DECRYPTION-SERVICE"))
				.route("NGUA-USER-KEYS-SERVICE", r -> r
						.path("/ngua-userKey/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-USER-KEYS-SERVICE")
										.setFallbackUri("forword/nguaUserKeysService"))
						)
						.uri("lb://NGUA-USER-KEYS-SERVICE"))
				.route("NGUA-CASE-REOPEN-SERVICE", r -> r
						.path("/ngua-caseReopen/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-CASE-REOPEN-SERVICE")
										.setFallbackUri("forword/nguaCaseReopenService"))
						)
						.uri("lb://NGUA-CASE-REOPEN-SERVICE"))
				.route("NGUA-CASE-CLOSE-SERVICE", r -> r
						.path("/ngua-caseClose/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-CASE-CLOSE-SERVICE")
										.setFallbackUri("forword/nguaCaseCloseService"))
						)
						.uri("lb://NGUA-CASE-CLOSE-SERVICE"))
				.route("NGUA-CASE-ARCHIVE-SERVICE", r -> r
						.path("/ngua-caseArchive/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-CASE-ARCHIVE-SERVICE")
										.setFallbackUri("forword/nguaCaseArchiveService"))
						)
						.uri("lb://NGUA-CASE-ARCHIVE-SERVICE"))
				.route("NGUA-NOTIFICATION-SERVICE", r -> r
						.path("/ngua-notification/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-NOTIFICATION-SERVICE")
										.setFallbackUri("forword/nguaNotificationService"))
						)
						.uri("lb://NGUA-NOTIFICATION-SERVICE"))
				.route("NGUA-USER-ACTIVITY-SERVICE", r -> r
						.path("/ngua-userActivity/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-USER-ACTIVITY-SERVICE")
										.setFallbackUri("forword/nguaUserActivityService"))
						)
						.uri("lb://NGUA-USER-ACTIVITY-SERVICE"))
				.route("NGUA-MART-SERVICE", r -> r
						.path("/ngua-mart/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-MART-SERVICE")
										.setFallbackUri("forword/nguaMartService"))
						)
						.uri("lb://NGUA-MART-SERVICE"))
				.route("NGUA-CASE-REQUEST-UDC-SERVICE", r -> r
						.path("/ngua-case-request-udc-service/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-CASE-REQUEST-UDC-SERVICE")
										.setFallbackUri("forword/nguaCaseRequestUDCService"))
						)
						.uri("lb://NGUA-CASE-REQUEST-UDC-SERVICE"))
				.route("NGPO-PORTAL-SERVICE", r -> r
						.path("/ngpo-portal/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGPO-PORTAL-SERVICE")
										.setFallbackUri("forword/ngPoPortal"))
						)
						.uri("lb://NGPO-PORTAL-SERVICE"))
				.route("NGUA-WATCHLIST-SERVICE", r -> r
						.path("/ngua-watchlist-service/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-WATCHLIST-SERVICE")
										.setFallbackUri("forword/nguaWatchlistService"))
						)
						.uri("lb://NGUA-WATCHLIST-SERVICE"))
				.route("NG-REPORTS-SERVICE", r -> r
						.path("/ng-reports/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NG-REPORTS-SERVICE")
										.setFallbackUri("forword/ngReportsService"))
						)
						.uri("lb://NG-REPORTS-SERVICE"))
				.route("NGUA-PO-WATCHLIST-SERVICE", r -> r
						.path("/ngua-po-watchlist/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-PO-WATCHLIST-SERVICE")
										.setFallbackUri("forword/nguaPoWatchlistService"))
						)
						.uri("lb://NGUA-PO-WATCHLIST-SERVICE"))
				.route("NG-SMS-SERVICE", r -> r
						.path("/ng-sms-integration/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NG-SMS-SERVICE")
										.setFallbackUri("forword/ngSmsService"))
						)
						.uri("lb://NG-SMS-SERVICE"))
				.route("SMS-GATEWAY-SERVICE", r -> r
						.path("/ng-sms-gateway/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("SMS-GATEWAY-SERVICE")
										.setFallbackUri("forword/ngSmsGatewayService"))
						)
						.uri("lb://SMS-GATEWAY-SERVICE"))
				.route("NGUA-AUDIT-SERVICE", r -> r
						.path("/ngua-audit/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NGUA-AUDIT-SERVICE")
										.setFallbackUri("forword/nguaAuditService"))
						)
						.uri("lb://NGUA-AUDIT-SERVICE"))
				.route("NG-KEYCLOAK-OTP-TOKEN-SERVICE", r -> r
						.path("/ng-keyCloak-otp/**")
						.filters(f -> f
								.filter(filter)
								.circuitBreaker(config -> config
										.setName("NG-KEYCLOAK-OTP-TOKEN-SERVICE")
										.setFallbackUri("forword/ngOtpToken"))
						)
						.uri("lb://NG-KEYCLOAK-OTP-TOKEN-SERVICE"))
				.build();

	}
}


