package com.ng.gateway.util;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.time.Instant;
import java.util.Base64;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.SignatureVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.common.base.Preconditions;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.ng.gateway.exception.InvalidTokenException;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@Component
@RefreshScope
public class JwtTokenValidator {

	public void validateToken(String accessToken) throws InvalidTokenException  {
        DecodedJWT decodedJWT = decodeToken(accessToken);
        verifyTokenHeader(decodedJWT);
        //verifySignature(decodedJWT);
        verifyPayload(decodedJWT);
    }

    private DecodedJWT decodeToken(String accessToken) throws InvalidTokenException {
 
    	try {
    		return JWT.decode(accessToken);
    	 } catch (Exception ex) {
    		 throw new InvalidTokenException("Token is InvalidTokenException ", ex);
         }
    }
    
	private void verifyTokenHeader(DecodedJWT decodedJWT) throws InvalidTokenException {
        try {
            Preconditions.checkArgument(decodedJWT.getType().equals("JWT"));
        } catch (IllegalArgumentException ex) {
            throw new InvalidTokenException("Token is not JWT type", ex);
        }
    }

    private void verifySignature(DecodedJWT decodedJWT) throws InvalidTokenException {
        try {
        	
        	String publicKeyContent = KeycloakJwkProvider.getInstance().getJwks().get("public_key").toString();
        	KeyFactory kf = KeyFactory.getInstance("RSA");
        	X509EncodedKeySpec keySpecX509 = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyContent));
            RSAPublicKey pubKey = (RSAPublicKey) kf.generatePublic(keySpecX509);
        	Algorithm algorithm = Algorithm.RSA256(pubKey,null);
        	algorithm.verify(decodedJWT);
        } catch (SignatureVerificationException ex) {
        	throw new InvalidTokenException("Token has invalid signature", ex);
        } catch (NoSuchAlgorithmException ex) {
        	throw new InvalidTokenException("Token has invalid signature like NoSuchAlgorithmException !! ", ex);
        } catch (InvalidKeySpecException ex) {
        	throw new InvalidTokenException("Token has invalid signature like InvalidKeySpecException !!", ex);
        } catch (Exception ex) {
        	ex.printStackTrace();
        	throw new InvalidTokenException("Token has invalid signature", ex);
        }
    }

    private void verifyPayload(DecodedJWT decodedJWT) throws InvalidTokenException  {
        JsonObject payloadAsJson = decodeTokenPayloadToJsonObject(decodedJWT);
        if (!hasTokenRealmRolesClaim(payloadAsJson)) {
            throw new InvalidTokenException("Token doesn't contain claims with realm roles");
        }
        if (!hasTokenScopeInfo(payloadAsJson)) {
            throw new InvalidTokenException("Token doesn't contain scope information");
        }
        if (hasTokenExpired(payloadAsJson)) {
            throw new InvalidTokenException("Token has expired");
        }
    }

    private JsonObject decodeTokenPayloadToJsonObject(DecodedJWT decodedJWT) throws InvalidTokenException {
        try {
            String payloadAsString = decodedJWT.getPayload();
            return new Gson().fromJson(
                    new String(Base64.getDecoder().decode(payloadAsString), StandardCharsets.UTF_8),
                    JsonObject.class);
        }catch (RuntimeException exception){
            throw new InvalidTokenException("Invalid JWT or JSON format of each of the jwt parts", exception);
        }
    }

    private boolean hasTokenExpired(JsonObject payloadAsJson) throws InvalidTokenException {
        Instant expirationDatetime = extractExpirationDate(payloadAsJson);
        return Instant.now().isAfter(expirationDatetime);
    }

    private Instant extractExpirationDate(JsonObject payloadAsJson) throws InvalidTokenException {
        try {
            return Instant.ofEpochSecond(payloadAsJson.get("exp").getAsLong());
        } catch (NullPointerException ex) {
            throw new InvalidTokenException("There is no 'exp' claim in the token payload");
        }
    }

    private boolean hasTokenRealmRolesClaim(JsonObject payloadAsJson) {
        try {
            return payloadAsJson.getAsJsonObject("realm_access").getAsJsonArray("roles").size() > 0;
        } catch (NullPointerException ex) {
            return false;
        }
    }

    private boolean hasTokenScopeInfo(JsonObject payloadAsJson) {
        return payloadAsJson.has("scope");
    }
  
}
