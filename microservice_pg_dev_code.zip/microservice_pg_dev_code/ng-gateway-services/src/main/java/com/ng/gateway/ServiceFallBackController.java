package com.ng.gateway;


import com.ng.gateway.model.response.ApiResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ServiceFallBackController {

	@PostMapping(value = "/masterService", produces = "application/json")
	public String customerService() {
		return "master-service - JWT validity cannot be asserted and should not be trusted !!";
	}

	@PostMapping(value = "/ngAuthService", produces = "application/json")
	public String authService() {
		return "Calling -  Auth Service is down...";
	}

	@PostMapping(value = "/ngOrganizationtype", produces = "application/json")
	public String ngOrganizationtype() {
		return "Calling - NG Organization Type is down...";
	}

	@PostMapping(value = "/ngCaptchService", produces = "application/json")
	public String ngCaptchService() {
		return "Calling - NG Captch Service is down...";
	}

	@PostMapping(value = "/ngUseCaseService", produces = "application/json")
	public ResponseEntity<Object> ngUseCaseServiceNew() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG Use Case Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ngPortalService", produces = "application/json")
	public ResponseEntity<Object> ngPortalService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG Portal Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ngMenuService", produces = "application/json")
	public ResponseEntity<Object> ngMenuService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG Menu Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ngRoleService", produces = "application/json")
	public ResponseEntity<Object> ngRoleService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG Role Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ngOrgService", produces = "application/json")
	public ResponseEntity<Object> ngOrgService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG ORG Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ngUserMgmtService", produces = "application/json")
	public ResponseEntity<Object> ngUserMgmtService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG User Management Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ngNotificationService", produces = "application/json")
	public ResponseEntity<Object> ngNotificationService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG Notification Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ngWorkflowService", produces = "application/json")
    public ResponseEntity<Object> ngWorkflowService() {   
    	 ApiResponse<?> apiResponse = ApiResponse.builder()
                 .status(String.valueOf(HttpStatus.BAD_GATEWAY))
                 .message("Calling - NG Workflow Service is down...")
                 //.data()
                 .build();
    	 return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ngRequestStatus", produces = "application/json")
    public ResponseEntity<Object> ngRequestStatus() {   
    	 ApiResponse<?> apiResponse = ApiResponse.builder()
                 .status(String.valueOf(HttpStatus.BAD_GATEWAY))
                 .message("Calling - NG Request Status Service is down...")
                 //.data()
                 .build();
    	 return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ngRestrictedUser", produces = "application/json")
    public ResponseEntity<Object> ngRestrictedUser() {   
    	 ApiResponse<?> apiResponse = ApiResponse.builder()
    	                 .status(String.valueOf(HttpStatus.BAD_GATEWAY))
    	                 .message("Calling - NG restricted Entity Service is down...")
    	                 //.data()
    	                 .build();
    	 return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ngUserStatus", produces = "application/json")
	public ResponseEntity<Object> ngUserStatus() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG User Status Service is down...")
				// .data()
				.build();
    	return ResponseEntity.ok().body(apiResponse);
    }
	
	@PostMapping(value = "/nguaCaseService", produces = "application/json")
	public ResponseEntity<Object> nguaCaseService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NGUA Case Service is down...")
				// .data()
				.build();
    	return ResponseEntity.ok().body(apiResponse);
    }
	
	@PostMapping(value = "/nguaCaseNote", produces = "application/json")
	public ResponseEntity<Object> nguaCaseNote() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NGUA Catse Note Service is down...")
				// .data()
				.build();
    	return ResponseEntity.ok().body(apiResponse);
    }
	
	@PostMapping(value = "/nguaCaseParticipant", produces = "application/json")
	public ResponseEntity<Object> nguaCaseParticipant() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NGUA Case Participant Service is down...")
				// .data()
				.build();
    	return ResponseEntity.ok().body(apiResponse);
    }
	
	@PostMapping(value = "/nguaCaseTransfer", produces = "application/json")
	public ResponseEntity<Object> nguaCaseTransfer() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NGUA Case Transfer Service is down...")
				// .data()
				.build();
    	return ResponseEntity.ok().body(apiResponse);
    }
	
	@PostMapping(value = "/ngKeycloakService", produces = "application/json")
	public ResponseEntity<Object> ngKeycloakService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - KeyCloak Service is down...")
				// .data()
				.build();
    	return ResponseEntity.ok().body(apiResponse);
    }
	@PostMapping(value = "/ngPoMasterService", produces = "application/json")
	public ResponseEntity<Object> ngPoMasterService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - Natgrid Po Master Service is down...")
				// .data()
				.build();
    	return ResponseEntity.ok().body(apiResponse);
    }
	
	@PostMapping(value = "/nguaCaseRevokeService", produces = "application/json")
	public ResponseEntity<Object> nguaCaseRevokeService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - Natgrid Case Revoke Service is down...")
				// .data()
				.build();	
    	return ResponseEntity.ok().body(apiResponse);
    }
	
	@PostMapping(value = "/nguaCaseRequestService", produces = "application/json")
	public ResponseEntity<Object> nguaCaseRequestService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - Natgrid Case request Service is down...")
				// .data()
				.build();	
    	return ResponseEntity.ok().body(apiResponse);
    }
	@PostMapping(value = "/nguaEntityResolution", produces = "application/json")
	public ResponseEntity<Object>  nguaEntityResolution() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - Natgrid Entity Resolution Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	@PostMapping(value = "/nguaWorkFlowService", produces = "application/json")
	public ResponseEntity<Object>  nguaWorkFlowService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - UA Worflow Service Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/ngFeedbackService", produces = "application/json")
	public ResponseEntity<Object>  ngFeedbackService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG Feedback Service Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	@PostMapping(value = "/ngEncryptionDecryptionService", produces = "application/json")
	public ResponseEntity<Object>  ngEncryptionDecryptionService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG Encryption Decryption Service Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/nguaUserKeysService", produces = "application/json")
	public ResponseEntity<Object>  nguaUserKeysService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG User Keys Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/nguaCaseReopenService", produces = "application/json")
	public ResponseEntity<Object>  nguaCaseReopenService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG Case Reopen Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/nguaCaseCloseService", produces = "application/json")
	public ResponseEntity<Object>  nguaCaseCloseService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG Case Close Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/nguaCaseArchiveService", produces = "application/json")
	public ResponseEntity<Object>  nguaCaseArchiveService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NG Case Archive Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	@PostMapping(value = "/nguaNotificationService", produces = "application/json")
	public ResponseEntity<Object>  nguaNotificationService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NGUA Notification Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	@PostMapping(value = "/nguaUserActivityService", produces = "application/json")
	public ResponseEntity<Object>  nguaUserActivityService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NGUA UserActivity Service is down...")
				// .data()
				.build();
			return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/nguaMartService", produces = "application/json")
	public ResponseEntity<Object>  nguaMartService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NGUA Mart Service is down...")
				// .data()
				.build();
				return ResponseEntity.ok().body(apiResponse);
	}
	@PostMapping(value = "/nguaCaseRequestUDCService", produces = "application/json")
	public ResponseEntity<Object>  nguaCaseRequestUDCService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - NGUA UDC Service is down...")
				// .data()
				.build();
				return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ngPoPortal", produces = "application/json")
	public ResponseEntity<Object>  ngPoPortal() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - ngPoPortal Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/nguaWatchlistService", produces = "application/json")
	public ResponseEntity<Object>  nguaWatchlistService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - nguaWatchlistService Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/ngReportsService", produces = "application/json")
	public ResponseEntity<Object>  ngReportsService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - ngReportsService Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	@PostMapping(value = "/nguaPoWatchlistService", produces = "application/json")
	public ResponseEntity<Object>  nguaPoWatchlistService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - nguaPoWatchlistService Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	@PostMapping(value = "/ngSmsService", produces = "application/json")
	public ResponseEntity<Object>  ngSmsService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - ngSmsService Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/ngSmsGatewayService", produces = "application/json")
	public ResponseEntity<Object>  ngSmsGatewayService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - ngSmsGatewayService Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/nguaAuditService", produces = "application/json")
	public ResponseEntity<Object>  nguaAuditService() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - nguaAuditService Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/ngOtpToken", produces = "application/json")
	public ResponseEntity<Object>  ngOtpToken() {
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_GATEWAY))
				.message("Calling - ngOtpToken Service is down...")
				// .data()
				.build();
		return ResponseEntity.ok().body(apiResponse);
	}
	
}