package com.ng.gateway.util;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.ng.gateway.exception.InvalidTokenException;


public class KeycloakJwkProvider {

	private static Map<String, Object> map = null;
	
	
	private String jwkProviderUrl;
	
	private static KeycloakJwkProvider keycloakJwkProvider;
	
	public static KeycloakJwkProvider getInstance() {
		if(keycloakJwkProvider==null)
			keycloakJwkProvider = new KeycloakJwkProvider();
		return keycloakJwkProvider;
	}
	
	public void setJwkProviderUrl(String jwkProviderUrl) throws InvalidTokenException {
		this.jwkProviderUrl=jwkProviderUrl;
	}
	
	public Map<String, Object> getJwks() throws InvalidTokenException {
		try {
			if (map == null) {
				URI uri = new URI(jwkProviderUrl).normalize();
				ObjectReader reader = new ObjectMapper().readerFor(Map.class);
				HttpClient client = HttpClient.newHttpClient();
				HttpRequest request = HttpRequest.newBuilder().uri(uri).headers("Accept", "application/json").GET()
						.build();
				HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
				map = reader.readValue(response.body());
			}
			return map;
		} catch (Exception e) {
			throw new InvalidTokenException("Token has invalid signature like InvalidKeySpecException !!", e);
		}
	}
}