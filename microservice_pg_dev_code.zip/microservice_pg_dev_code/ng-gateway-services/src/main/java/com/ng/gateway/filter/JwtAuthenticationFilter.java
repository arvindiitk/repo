package com.ng.gateway.filter;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ng.gateway.exception.InvalidTokenException;
import com.ng.gateway.model.response.ApiResponse;
import com.ng.gateway.util.JwtTokenValidator;
import com.ng.gateway.util.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

@Component
public class JwtAuthenticationFilter implements GatewayFilter {

	@Autowired
	private JwtUtil jwtUtil;
	
	private JwtTokenValidator jwtTokenValidator = new JwtTokenValidator();

	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
		ServerHttpRequest request = (ServerHttpRequest) exchange.getRequest();
		ServerHttpResponse response = (ServerHttpResponse) exchange.getResponse();
		
		final List<String> apiEndpoints = List.of("/ng-keyCloak-type","/ng-keyCloak-otp", "/ng-menu","/ng-org","/ng-org-type","/auth"
				,"/ng-portal","/ng-role","/ng-user-mgmt","/ngua-userActivity","/ngua-notification");
		Predicate<ServerHttpRequest> isApiSecured = r -> apiEndpoints.stream()
				.noneMatch(uri -> r.getURI().getPath().contains(uri));
		if (isApiSecured.test(request)) {
			if (!request.getHeaders().containsKey("Authorization")) {
				response.setStatusCode(HttpStatus.UNAUTHORIZED);
				return response.setComplete();
			}
			String token = request.getHeaders().getOrEmpty("Authorization").get(0);
			try {
				jwtUtil.setJwkProviderUrl();
				token = token.replace("Bearer ", "");
				jwtTokenValidator.validateToken(token);
			} catch (InvalidTokenException e) {

				ApiResponse<Optional<String>> apiResponse = new ApiResponse<>();
				apiResponse.setStatus(String.valueOf(HttpStatus.UNAUTHORIZED));
				apiResponse.setMessage(e.getMessage());
				
				response.getHeaders().setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
				ObjectMapper objectMapper =new ObjectMapper();
				DataBuffer dataBuffer = null;
				try {
					dataBuffer = response.bufferFactory().wrap(objectMapper.writeValueAsBytes(apiResponse));
				} catch (JsonProcessingException e1) {
					e1.printStackTrace();
				}
				response.setStatusCode(HttpStatus.UNAUTHORIZED);
				return response.writeWith(Mono.just(dataBuffer));
			} 
			exchange.getRequest().mutate().header("id", String.valueOf("id")).build();
		}
		return chain.filter(exchange);
	}

}
