package com.ng.gateway.util;

import java.net.URISyntaxException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.ng.gateway.exception.InvalidTokenException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@RefreshScope
public class JwtUtil {
	
	@Value("${jwk.providerUrl}")
	private String jwkProviderUrl;
	
	public void setJwkProviderUrl() throws InvalidTokenException {
		KeycloakJwkProvider.getInstance().setJwkProviderUrl(jwkProviderUrl);
	}
	public Claims getClaims(final String token) {
		Claims body = null;
		try {
			body = Jwts.parser().setSigningKey(getParsedPublicKey().get()).parseClaimsJws(token).getBody();
		} catch (Exception e) {
			log.info("ERROR :: Exception  Occured in getClaims method {} " + e.getMessage() + " => " + e);
		}
		return body;

	}

	public Optional<RSAPublicKey> getParsedPublicKey() throws InvalidTokenException, URISyntaxException {
		try {
			
			String publicKeyContent = KeycloakJwkProvider.getInstance().getJwks().get("public_key").toString();
			byte[] decode = Base64.getDecoder().decode(publicKeyContent);
			X509EncodedKeySpec keySpecX509 = new X509EncodedKeySpec(decode);
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			RSAPublicKey pubKey = (RSAPublicKey) keyFactory.generatePublic(keySpecX509);
			return Optional.of(pubKey);

		} catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
			e.printStackTrace();
			System.out.println("Exception block | Public key parsing error ");
			return Optional.empty();
		}
	}
}
