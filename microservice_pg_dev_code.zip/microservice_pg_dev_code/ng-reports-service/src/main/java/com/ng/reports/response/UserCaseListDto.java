package com.ng.reports.response;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.reports.constants.Constants;

public interface UserCaseListDto {

	public Integer getCaseId();
	public String getCaseNo();
	public String getCaseName();
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	public Timestamp getCreatedOn();
	public String getStatus();
	public String getStatusCode();
	public String getRaisedBy();
	public String getActor();
	public String getRequestType();
	
}