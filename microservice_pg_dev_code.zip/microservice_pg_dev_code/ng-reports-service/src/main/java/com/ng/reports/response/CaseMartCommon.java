package com.ng.reports.response;

public interface CaseMartCommon {
	
	public String getCaseName();
	public Integer getCaseId();
	public String getCaseArtifact();
	public Integer getRequests();
	public Integer getSubRequests();
	public Integer getResponses();
	public Integer getMartTypeId();
	public String getRoleName();
	public String getRaisedBy();
}