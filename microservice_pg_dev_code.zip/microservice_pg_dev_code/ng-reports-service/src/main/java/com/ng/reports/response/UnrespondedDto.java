package com.ng.reports.response;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.reports.constants.Constants;

public interface UnrespondedDto {
	
	public Integer getSubReqId();
	public Integer getReqId();
	public String getUaName();
	public String getUaAlias();
	public Integer getUaId();
	public String getPoName();
	public String getPoAlias();
	public Integer getPoId();
	public String getReqCategory();
	public String getUseCaseDescription();
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	public Timestamp getReqDate();
	public String getStatus();
	
	
	
}