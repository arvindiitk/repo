package com.ng.reports.response;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.reports.constants.Constants;

public interface CaseTransferNodalDto {
	
	public Integer getRoleId();
	public String getRoleName();
	public String getCaseId();
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	public Timestamp getCaseTransferDate();
	public String getTransferedFrom();
	public String getTransferedToUserName();
	public String getCreator();
	
	
}