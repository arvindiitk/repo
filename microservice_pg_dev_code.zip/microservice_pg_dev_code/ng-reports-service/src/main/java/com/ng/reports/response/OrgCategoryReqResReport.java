package com.ng.reports.response;

public interface OrgCategoryReqResReport {
	
	public String getOrgName();
	public String getRoleName();
	public String getCreatedOn();
	public String getDay();
	public Integer getTotalRequests();
	public Integer getTotalResponses();
	public Integer getReqResDiff();
	public Integer getNsRequests();
	public Integer getNsResponses();
	public Integer getHsRequests();
	public Integer getHsResponses();
	public Integer getSRequests();
	public Integer getSResponses();
	public Integer getOrgId();
	public Integer getUserId();	
	public String getOrgAlias();

}
