package com.ng.reports.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@Entity(name="m_reports_details")
public class ReportsDetails implements Serializable {
	
	private static final long serialVersionUID = 8310499747506330827L;

	@Id
	@Column(name="REPORT_ID")
	private Integer reportId;
	
	@Column(name="REPORT_NAME")
	private String reportName;
	
	@Column(name = "IS_ACTIVE", nullable = false, columnDefinition = "default bit 1")
	private Boolean isActive;

	
}
