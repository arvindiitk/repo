package com.ng.reports.response;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class PoWiseMonthWiseReport implements Serializable{
	

	private static final long serialVersionUID = 2865652618658302939L;
	
	private List<PoWiseMonthWiseReportDto> poWiseMonthWise;
	private List<PoWiseMonthWiseReportDto> monthWise;
	private List<PoWiseMonthWiseReportDto> poWise;
	
	
	
}