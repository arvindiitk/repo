package com.ng.reports.response;

public interface UaCaseStatisticsReport {
	
	public String getOrgName();
	public String getOrgAlias();
	public Integer getOrgId();
	public String getUaType();
	public Integer getActiveUsers();
	public Integer getTotalCases();
	public Integer getActiveCases();
	public Integer getClosedCases();
}
