package com.ng.reports.response;

public interface CaseSummaryReport {
	
	public String getRoleName();
	public String getUserName();
	public Integer getUserId();
	public Integer getCountCases();
	public Integer getRoleId();
	public String getStatus();
	public String getStatusCode();
}