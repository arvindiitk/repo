package com.ng.reports.response;

public interface UAWiseDayWiseDto {
	
	public String getCreatedOn();
	public String getDay();
	public String getOrgName();
	public String getOrgAlias();
	public Integer getOrgId();
	public String getUaCategory();
	public Integer getTotalRequests();
	public Integer getNsRequests();
	public Integer getSRequests();
	public Integer getHSRequests();
	public Integer getTotalResponses();
	public Integer getNsResponses();
	public Integer getSResponses();
	public Integer getHsResponses();
	public Integer getErCount();
	
}
