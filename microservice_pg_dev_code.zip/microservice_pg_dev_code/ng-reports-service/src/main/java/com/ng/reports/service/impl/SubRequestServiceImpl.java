package com.ng.reports.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ng.reports.constants.Constants;
import com.ng.reports.entity.ReportsDetails;
import com.ng.reports.entity.UserReports;
import com.ng.reports.repository.ReportsRepository;
import com.ng.reports.repository.UaReqResViewRepository;
import com.ng.reports.request.RequestDateDTO;
import com.ng.reports.request.UserReportsDto;
import com.ng.reports.response.AdminApprovalReport;
import com.ng.reports.response.AllCaseStatusDTO;
import com.ng.reports.response.AllRequestStatusDTO;
import com.ng.reports.response.CaseHistoryNodalDto;
import com.ng.reports.response.CaseListDto;
import com.ng.reports.response.CaseMartCommon;
import com.ng.reports.response.CaseOwnerParticipantReport;
import com.ng.reports.response.CaseSummaryReport;
import com.ng.reports.response.CaseTransferNodalDto;
import com.ng.reports.response.DayWiseReqResReport;
import com.ng.reports.response.ErReqSummaryDto;
import com.ng.reports.response.MonthlyAdminReportDto;
import com.ng.reports.response.OrgCategoryReqResReport;
import com.ng.reports.response.OrgWiseReqResReport;
import com.ng.reports.response.PoWiseMonthWiseReport;
import com.ng.reports.response.PreviousMonthReqSumDto;
import com.ng.reports.response.ReqErrorNodalDto;
import com.ng.reports.response.ReqListDto;
import com.ng.reports.response.ReqSummaryDto;
import com.ng.reports.response.SharingDataDto;
import com.ng.reports.response.SubReqHistoryNodalDto;
import com.ng.reports.response.UAWiseDayWiseDto;
import com.ng.reports.response.UaCaseStatisticsReport;
import com.ng.reports.response.UaTopWiseReqResReport;
import com.ng.reports.response.UaWiseMonthWiseReport;
import com.ng.reports.response.UnrespondedDto;
import com.ng.reports.response.UserCaseListDto;
import com.ng.reports.response.UserListDto;
import com.ng.reports.response.UserReportList;
import com.ng.reports.response.WorklistStatusDTO;
import com.ng.reports.service.SubRequestService;

@PropertySource("classpath:/messages/business/uri.properties")
@Service
@Transactional
public class SubRequestServiceImpl implements SubRequestService {

	@Autowired
	private UaReqResViewRepository uaReqResViewRepository;
	
	@Autowired
	private ReportsRepository reportsRepository;
	
	@Value("${get.user.hierarchy.url}")
    private String userUrl;
	
	@Autowired
    RestTemplate restTemplate;

	public List<Integer> getUserHierarchy(Integer userId){
		
		UserReportsDto useRep = new UserReportsDto();
		useRep.setUserId(userId);
		useRep.setPortalId(2);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> httpEntity = new HttpEntity<>(useRep, httpHeaders);
		ResponseEntity<UserReportList> responseEntity = restTemplate.postForEntity(userUrl, httpEntity,UserReportList.class);
		List<Integer> userIds = responseEntity.getBody().getUserReports().stream().map(UserReports::getUserId).collect(Collectors.toList());
		userIds.add(userId);
		
		return userIds;
	}
	
	@Override
	public List<OrgWiseReqResReport> uaReqResCount(RequestDateDTO req) {
		if(req.getOrgId() == null || req.getOrgId().equals(""))
			return uaReqResViewRepository.getUaWiseReqResReport(req.getFromDate(), req.getToDate());
		else {
			String[] orgId = req.getOrgId().split(",");
			List<OrgWiseReqResReport> uaReqResReport = new ArrayList<>();
			for(String org : orgId) {
				uaReqResReport.addAll(uaReqResViewRepository.getUaWiseReqResReport(req.getFromDate(), req.getToDate()).stream()
				.filter(a -> a.getOrgId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
			}
			return uaReqResReport;
		}
	}

	@Override
	public List<OrgWiseReqResReport> poReqResCount(RequestDateDTO req) {
		if(req.getOrgId() == null || req.getOrgId().equals(""))
		  return uaReqResViewRepository.getPoWiseReqResReport(req.getFromDate(), req.getToDate());
		else {
			String[] orgId = req.getOrgId().split(",");
			List<OrgWiseReqResReport> poReqResReport = new ArrayList<>();
			for(String org : orgId) {
				poReqResReport.addAll(uaReqResViewRepository.getPoWiseReqResReport(req.getFromDate(), req.getToDate()).stream()
				.filter(a -> a.getOrgId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
			}
			return poReqResReport;
		}
	}

	@Override
	public List<OrgWiseReqResReport> categoryWiseReqSummary(RequestDateDTO req) {
		return uaReqResViewRepository.getCategoryWiseReqSummary(req.getFromDate(), req.getToDate());
	}

	@Override
	public List<PreviousMonthReqSumDto> prevMonthReqSummary(RequestDateDTO req) {
		if(req.getOrgId() == null || req.getOrgId().equals(""))
			return uaReqResViewRepository.getPreviousMonthReqSummary(req.getFromDate(), req.getToDate());
		else {
			String[] orgId = req.getOrgId().split(",");
			List<PreviousMonthReqSumDto> prevReport = new ArrayList<>();
			for(String org : orgId) {
				prevReport.addAll(uaReqResViewRepository.getPreviousMonthReqSummary(req.getFromDate(), req.getToDate()).stream()
				.filter(a -> a.getOrgId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
			}
			return prevReport;
		}
	}

	@Override
	public List<UaTopWiseReqResReport> uaTopWiseReqResCount(RequestDateDTO req) {
		
		List<UaTopWiseReqResReport> uaTopWiseReportList = new ArrayList<>();
		uaTopWiseReportList = uaReqResViewRepository.uaTopWiseReqResCount(req.getFromDate(), req.getToDate());

		if (req.getSameQueryExe() != null) {
			uaTopWiseReportList = uaTopWiseReportList.stream()
			.filter(a -> a.getSameQueryExe() >= req.getSameQueryExe()).collect(Collectors.toList());
		} 
		if (!req.getOrgId().equals("") && req.getOrgId() != null ) {
			String[] uaIdList = req.getOrgId().split(",");
			List<UaTopWiseReqResReport> uaTopWiseReportListUaId = new ArrayList<>();

			for (String uaId : uaIdList) {
				System.out.println("list"+uaId);

				uaTopWiseReportListUaId.addAll(uaTopWiseReportList.stream()
						.filter(a -> a.getOrgId().equals(Integer.parseInt(uaId))).collect(Collectors.toList()));
			}
			uaTopWiseReportList = uaTopWiseReportListUaId;
		}
		return uaTopWiseReportList;
	}

	@Override
	public List<UaTopWiseReqResReport> poTopWiseReqResCount(RequestDateDTO req) {
		
		List<UaTopWiseReqResReport> poTopWiseReportList = new ArrayList<>();
		
		if ((req.getOrgId() == null || req.getOrgId().equals("")) && req.getSameQueryExe() == null)
			return uaReqResViewRepository.poTopWiseReqResCount(req.getFromDate(), req.getToDate());
		
		else if (req.getSameQueryExe() != null) {
			poTopWiseReportList.addAll(uaReqResViewRepository.poTopWiseReqResCount(req.getFromDate(), req.getToDate())
					.stream().filter(a -> a.getSameQueryExe() >= (req.getSameQueryExe())).collect(Collectors.toList()));
		} else {
			String[] poIdList = req.getOrgId().split(",", 0);
			for (String poId : poIdList) {
				poTopWiseReportList
						.addAll(uaReqResViewRepository.poTopWiseReqResCount(req.getFromDate(), req.getToDate()).stream()
								.filter(a -> a.getOrgId().equals(Integer.parseInt(poId))).collect(Collectors.toList()));
			}
		}
		return poTopWiseReportList;
	}

	
	@Override
	public List<ReportsDetails> reportsDetails() {
		return reportsRepository.findAllByIsActive(true);
	}

	@Override
	public List<DayWiseReqResReport> getDayWiseReqRes(RequestDateDTO req) {
		return uaReqResViewRepository.getDayWiseReqRes(req.getFromDate(), req.getToDate());
	}
	
	@Override
	public List<AdminApprovalReport> getAdminApprovalReport(RequestDateDTO req) {
		if(req.getOrgId() == null || req.getOrgId().equals(""))
			return uaReqResViewRepository.getAdminApprovalReport(req.getFromDate(), req.getToDate());
		else {
			String[] orgId = req.getOrgId().split(",");
			List<AdminApprovalReport> adminApprovalList = new ArrayList<>();
			for(String org : orgId) {
				adminApprovalList.addAll(uaReqResViewRepository.getAdminApprovalReport(req.getFromDate(), req.getToDate()).stream()
				.filter(a -> a.getOrgId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
			}
			return adminApprovalList;
		}
	}
	
	@Override
	public List<UAWiseDayWiseDto> getUaCatReqRes(RequestDateDTO req) {
		List<UAWiseDayWiseDto> uaDaywise = new ArrayList<>();

		if (req.getReqCategory().equalsIgnoreCase("All")) {
			uaDaywise.addAll(uaReqResViewRepository.getUaCatReqRes(req.getFromDate(), req.getToDate()));
		} else if (req.getReqCategory().equalsIgnoreCase("true")) {
			uaDaywise.addAll(uaReqResViewRepository.getUaCatReqRes(req.getFromDate(), req.getToDate()).stream()
					.filter(a -> a.getUaCategory().equals("State")).collect(Collectors.toList()));
		} else if (req.getReqCategory().equalsIgnoreCase("false")) {
			uaDaywise.addAll(uaReqResViewRepository.getUaCatReqRes(req.getFromDate(), req.getToDate()).stream()
					.filter(a -> a.getUaCategory().equals("Central")).collect(Collectors.toList()));
		}

		if (req.getOrgId() == null || req.getOrgId().equals(""))
			return uaDaywise;
		else {
			List<UAWiseDayWiseDto> uaDaywiseDay = new ArrayList<>();
			String[] orgId = req.getOrgId().split(",");
			for (String org : orgId) {
				uaDaywiseDay.addAll(uaReqResViewRepository.getUaCatReqRes(req.getFromDate(), req.getToDate()).stream()
						.filter(a -> a.getOrgId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
			}
			return uaDaywiseDay;
		}
	}

	@Override
	public List<UAWiseDayWiseDto> getDayWiseCatReqRes(RequestDateDTO req) {
		return uaReqResViewRepository.getDayWiseCatReqRes(req.getFromDate(), req.getToDate());
	}

	@Override
	public List<UAWiseDayWiseDto> getUAwiseCatReqRes(RequestDateDTO req) {
		List<UAWiseDayWiseDto> orgCatReqRes = new ArrayList<>();

		if (req.getOrgId().equals("")) {

			if (req.getReqCategory().equalsIgnoreCase("All")) {
				orgCatReqRes.addAll(uaReqResViewRepository.getUAwiseCatReqRes(req.getFromDate(), req.getToDate()));
			}
			if (req.getReqCategory().equalsIgnoreCase("true")) {
				orgCatReqRes.addAll(uaReqResViewRepository.getUAwiseCatReqRes(req.getFromDate(), req.getToDate())
						.stream().filter(a -> a.getUaCategory().equals("State")).collect(Collectors.toList()));
			}
			if (req.getReqCategory().equalsIgnoreCase("false")) {
				orgCatReqRes.addAll(uaReqResViewRepository.getUAwiseCatReqRes(req.getFromDate(), req.getToDate())
						.stream().filter(a -> a.getUaCategory().equals("Central")).collect(Collectors.toList()));
			}
			return orgCatReqRes;
		}
		else
		{
			List<UAWiseDayWiseDto> orgCatReqRes2 = new ArrayList<>();
			String[] orgId = req.getOrgId().split(",");
			for (String org : orgId) {
				orgCatReqRes2.addAll(uaReqResViewRepository.getUAwiseCatReqRes(req.getFromDate(), req.getToDate())
						.stream().filter(a -> a.getOrgId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
			}
			return orgCatReqRes2;
		}
		
	}
		
	
	@Override
	public List<OrgCategoryReqResReport> getPoCatReqRes(RequestDateDTO req) {
	if (req.getOrgId() == null || req.getOrgId().equals(""))
		return uaReqResViewRepository.getPoCatReqRes(req.getFromDate(), req.getToDate());
	else {
		List<OrgCategoryReqResReport> orgCatReqRes = new ArrayList<>();
		String[] orgId = req.getOrgId().split(",");
		for (String org : orgId) {
			orgCatReqRes.addAll(uaReqResViewRepository.getPoCatReqRes(req.getFromDate(), req.getToDate()).stream()
					.filter(a -> a.getOrgId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
		}
		return orgCatReqRes;
	}
}

	@Override
	public List<OrgCategoryReqResReport> getPoDayWiseReqRes(RequestDateDTO req) {
	if (req.getOrgId() == null || req.getOrgId().equals(""))
		return uaReqResViewRepository.getPoDayWiseReqRes(req.getFromDate(), req.getToDate());
	else {
		List<OrgCategoryReqResReport> orgCatReqRes = new ArrayList<>();
		String[] orgId = req.getOrgId().split(",");
		for (String org : orgId) {
			orgCatReqRes.addAll(uaReqResViewRepository.getPoDayWiseReqRes(req.getFromDate(), req.getToDate()).stream()
					.filter(a -> a.getOrgId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
		}
		return orgCatReqRes;
	}
}
	
	@Override
	public List<OrgCategoryReqResReport> getPoWiseReqRes(RequestDateDTO req) {
		
	if (req.getOrgId() == null || req.getOrgId().equals(""))
		return uaReqResViewRepository.getPoWiseReqRes(req.getFromDate(), req.getToDate());
	else {
		List<OrgCategoryReqResReport> orgCatReqRes = new ArrayList<>();
		String[] orgId = req.getOrgId().split(",");
		for (String org : orgId) {
			orgCatReqRes.addAll(uaReqResViewRepository.getPoWiseReqRes(req.getFromDate(), req.getToDate()).stream()
					.filter(a -> a.getOrgId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
		}
		return orgCatReqRes;
	}
}
	
	@Override
	public List<OrgCategoryReqResReport> getUserCatReq(RequestDateDTO req) {
		if ((req.getOrgId() == null || req.getOrgId().equals("")) && req.getReqCount() == null)
			return uaReqResViewRepository.getUserCatReq(req.getFromDate(), req.getToDate());
		else if (!(req.getOrgId() == null || req.getOrgId().equals(""))){
			List<OrgCategoryReqResReport> orgCatReqRes = new ArrayList<>();
			String[] orgId = req.getOrgId().split(",");
			if(req.getReqCount() == null) {
				for (String org : orgId) {
					orgCatReqRes.addAll(uaReqResViewRepository.getUserCatReq(req.getFromDate(), req.getToDate()).stream()
							.filter(a -> a.getOrgId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
				}
			}else {
				for (String org : orgId) {
					orgCatReqRes.addAll(uaReqResViewRepository.getUserCatReq(req.getFromDate(), req.getToDate()).stream()
							.filter(a -> a.getOrgId().equals(Integer.parseInt(org)))
							.filter(a -> (a.getTotalRequests()>=req.getReqCount()))
							.collect(Collectors.toList()));
				}
			}
			return orgCatReqRes;
		}
		else {
			return uaReqResViewRepository.getUserCatReq(req.getFromDate(), req.getToDate()).stream()
					.filter(a -> (a.getTotalRequests()>=req.getReqCount())).collect(Collectors.toList());
		}
	}
	
	@Override
	public List<CaseSummaryReport> getCaseSummaryNodal(RequestDateDTO req) {
		return uaReqResViewRepository.getCaseSummaryNodal(req.getFromDate(), req.getToDate(), Integer.parseInt(req.getOrgId()), req.getUserName(), req.getRoleId(), req.getStatusCode());
	}
	
	@Override
	public List<CaseListDto> getCaseListNodal(RequestDateDTO req) {
		
		List<CaseListDto> caseList = uaReqResViewRepository.getCaseListNodal(req.getFromDate(), req.getToDate(), Integer.parseInt(req.getOrgId()));
		
		if(req.getCaseId() != null)
			 caseList =caseList.stream().filter(a -> (a.getCaseId().equals(req.getCaseId()))).collect(Collectors.toList());

		if (!(req.getRoleName() == null || req.getRoleName().equals("")))
			 caseList =caseList.stream().filter(a -> (a.getRoleId().equals(req.getRoleName()))).collect(Collectors.toList());
		
		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			 caseList =caseList.stream().filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());
		
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			caseList = caseList.stream().filter(a -> (a.getCreator().equals(req.getUserName()))).collect(Collectors.toList());
		
		return caseList;
	}
	
	@Override
	public List<ReqListDto> getReqListNodal(RequestDateDTO req) {
		
		List<ReqListDto> reqList = new ArrayList<>();
		if (req.getPos() == null || req.getPos().equals(""))
				reqList = uaReqResViewRepository.getReqListNodal(req.getFromDate(), req.getToDate(), Integer.parseInt(req.getOrgId()));
		else {
			String[] orgId = req.getPos().split(",");
			
			for(String org : orgId) {
				reqList.addAll(uaReqResViewRepository.getReqListNodal(req.getFromDate(), req.getToDate(), Integer.parseInt(req.getOrgId())).stream()
				.filter(a -> a.getPoId().equals(Integer.parseInt(org)))
				.filter(a -> a.getReqType().equals(req.getReqType())).collect(Collectors.toList()));
			}
		}	
		
		if(req.getCaseId() != null)
			reqList = reqList.stream().filter(a -> (a.getCaseId().equals(req.getCaseId()))).collect(Collectors.toList());

		if (!(req.getRoleName() == null || req.getRoleName().equals("")))
			reqList = reqList.stream().filter(a -> (a.getRoleName().equals(req.getRoleName()))).collect(Collectors.toList());

		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			reqList = reqList.stream().filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());
		
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqList = reqList.stream().filter(a -> (a.getRaisedBy().equals(req.getUserName()))).collect(Collectors.toList());
		
		
		if (!(req.getReqCategory() == null || req.getReqCategory().equals("")))
			reqList = reqList.stream().filter(a -> (a.getReqCategory().equals(req.getReqCategory()))).collect(Collectors.toList());
		
		return reqList;
	}
	
	
	@Override
	public List<ReqSummaryDto> getReqSummaryNodal(RequestDateDTO req) {
		
		List<ReqSummaryDto> reqList = uaReqResViewRepository.getReqSummaryNodal(req.getFromDate(), req.getToDate(), Integer.parseInt(req.getOrgId()));
		
		if (!(req.getRoleName() == null || req.getRoleName().equals(""))) 
			reqList = reqList.stream().filter(a -> (a.getRoleName().equals(req.getRoleName()))).collect(Collectors.toList());

		if (!(req.getStatusCode() == null || req.getStatusCode().equals(""))) 
				reqList = reqList.stream().filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());
		
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqList = reqList.stream().filter(a -> (a.getRaisedBy().equals(req.getUserName()))).collect(Collectors.toList());
		
	//	if (req.getPoId() != null)
	//		reqList =  reqList.stream().filter(a -> (a.getPoId().equals(req.getPoId()))).collect(Collectors.toList());
				
		if (req.getPos() != null || !req.getPos().equals("")) {
			String[] poIds = req.getPos().split(",");
			for (String po : poIds) {
				reqList.addAll(reqList.stream().filter(a -> (a.getPoId().equals(Integer.parseInt(po)))).collect(Collectors.toList()));
			}
		}	else { return reqList; }
				
	    return reqList;
	}
	
	@Override
	public List<CaseTransferNodalDto> getCaseTransferNodal(RequestDateDTO req) {
		
		List<CaseTransferNodalDto> caseTransferList = uaReqResViewRepository.getCaseTransferNodal(req.getFromDate(), req.getToDate(), Integer.parseInt(req.getOrgId()));
		if (!(req.getRoleName() == null || req.getRoleName().equals("")))
			caseTransferList = caseTransferList.stream()
					.filter(a -> (a.getRoleName().equals(req.getRoleName()))).collect(Collectors.toList());
		
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			caseTransferList = caseTransferList.stream().filter(a -> (a.getCreator().equals(req.getUserName()))).collect(Collectors.toList());
		
		return caseTransferList;
		
	}
	@Override
	public List<CaseHistoryNodalDto> getCaseHistoryNodal(RequestDateDTO req) {

		List<CaseHistoryNodalDto> uaReqResView = uaReqResViewRepository.getCaseHistoryNodal(Integer.parseInt(req.getOrgId()));

		if (!(req.getRoleName() == null || req.getRoleName().equals(""))) {
			uaReqResView = uaReqResView.stream().filter(a -> a.getRoleName().equals(req.getRoleName())).collect(Collectors.toList());
		} 
		if (!(req.getCaseName() == null || req.getCaseName().equals("")))
			uaReqResView = uaReqResView.stream().filter(a -> (a.getCaseId().equals(req.getCaseName()))).collect(Collectors.toList());
		
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			uaReqResView = uaReqResView.stream().filter(a -> (a.getCreator().equals(req.getUserName()))).collect(Collectors.toList());
		
		return uaReqResView;
	}
	
	@Override
	public List<SubReqHistoryNodalDto> getSubReqHistoryNodal(RequestDateDTO req) {
		return uaReqResViewRepository.getSubReqHistoryNodal(req.getSubReqId());
		
	}
	
	@Override
	public List<ReqErrorNodalDto> getErrorReqNodal(RequestDateDTO req) {
		
		if(req.getPos() == null || req.getPos().equals(""))
			return uaReqResViewRepository.getErrorReqNodal(Integer.parseInt(req.getOrgId()));
		else {
			String[] orgId = req.getPos().split(",");
			List<ReqErrorNodalDto> errorList = new ArrayList<>();
			for(String org : orgId) {
				errorList.addAll(uaReqResViewRepository.getErrorReqNodal(Integer.parseInt(req.getOrgId())).stream()
						.filter(a -> a.getPoId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
			}
			return errorList;
		}
		
	}
	
	@Override
	public List<CaseSummaryReport> getCaseSummaryAuth(RequestDateDTO req) {
		if (req.getStatusCode() == null || req.getStatusCode().equals(""))
			return uaReqResViewRepository.getCaseSummaryAuth(req.getFromDate(), req.getToDate(), req.getUserId());
		else
			return uaReqResViewRepository.getCaseSummaryAuth(req.getFromDate(), req.getToDate(), req.getUserId())
					.stream().filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());

	}
	@Override
	public List<CaseListDto> getCaseListAuth(RequestDateDTO req) {
		
		List<CaseListDto> caseList = uaReqResViewRepository.getCaseListAuth(req.getFromDate(), req.getToDate(), req.getUserId());
		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			caseList = caseList.stream()
					.filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());

		if (!(req.getCaseName() == null || req.getCaseName().equals("")))
			caseList = caseList.stream().filter(a -> (a.getCaseName().equals(req.getCaseName()))).collect(Collectors.toList());
		
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			caseList = caseList.stream().filter(a -> (a.getOwner().equals(req.getUserName()))).collect(Collectors.toList());
		
		return caseList;
			
	}
	
	@Override
	public List<ReqListDto> getReqListAuth(RequestDateDTO req) {
		List<ReqListDto> reqList = new ArrayList<>();
		if (req.getOrgId() == null)
				reqList = uaReqResViewRepository.getReqListAuth(req.getFromDate(), req.getToDate(), req.getUserId());
		else {
			String[] orgId = req.getOrgId().split(",");
			for(String org : orgId) {				
				reqList.addAll(uaReqResViewRepository.getReqListAuth(req.getFromDate(), req.getToDate(), req.getUserId()).stream()
							.filter(a -> a.getPoId().equals(Integer.parseInt(org)))
							.filter(a -> a.getReqType().equals(req.getReqType())).collect(Collectors.toList()));
			}
		}	
		
		if(req.getCaseId() != null)
			reqList =  reqList.stream().filter(a -> (a.getCaseId().equals(req.getCaseId())))
					.collect(Collectors.toList());
		
		if(!(req.getCaseName() == null || req.getCaseName().equals("")))
			reqList =  reqList.stream().filter(a -> (a.getCaseName().equals(req.getCaseName())))
					.collect(Collectors.toList());

		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
				reqList =  reqList.stream().filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());
		
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqList = reqList.stream().filter(a -> (a.getRaisedBy().equals(req.getUserName()))).collect(Collectors.toList());
		
		if (!(req.getReqCategory() == null || req.getReqCategory().equals("")))
			reqList = reqList.stream().filter(a -> (a.getReqCategory().equals(req.getReqCategory()))).collect(Collectors.toList());
		
		if (!(req.getReqType() == null || req.getReqType().equals("")))
			reqList = reqList.stream().filter(a -> (a.getReqType().equals(req.getReqType()))).collect(Collectors.toList());
		
		return reqList;
	}
	
	
	@Override
	public List<ReqSummaryDto> getReqSummaryAuth(RequestDateDTO req) {
		
		List<ReqSummaryDto> reqSummary = uaReqResViewRepository.getReqSummaryAuth(req.getFromDate(), req.getToDate(), req.getUserId());
		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			reqSummary = reqSummary.stream()
					.filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());
		if ((req.getPoId() != null))
			reqSummary = reqSummary.stream().filter(a -> (a.getPoId().equals(req.getPoId()))).collect(Collectors.toList());
		
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqSummary = reqSummary.stream().filter(a -> (a.getRaisedBy().equals(req.getUserName()))).collect(Collectors.toList());
		
		return reqSummary;
	}
	
	@Override
	public List<ReqErrorNodalDto> getErrorReqAuth(RequestDateDTO req) {
		if(req.getOrgId() == null || req.getOrgId().equals(""))
			return uaReqResViewRepository.getErrorReqAuth(req.getUserId());
		else {
			String[] orgId = req.getOrgId().split(",");
			List<ReqErrorNodalDto> errorList = new ArrayList<>();
			for(String org : orgId) {
				errorList.addAll(uaReqResViewRepository.getErrorReqAuth(req.getUserId()).stream()
				.filter(a -> a.getPoId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
			}
			return errorList;
		}
	}
	
//Designated
	
	@Override
	public List<MonthlyAdminReportDto> monthlySummary(RequestDateDTO req) {
		List<MonthlyAdminReportDto> monthlyAdminReport = new ArrayList<>();
		if (req.getOrgId() == null || req.getOrgId().equals(""))
			monthlyAdminReport = uaReqResViewRepository.getMonthlySummary(req.getFromDate(), req.getToDate());
		else {
			String[] orgId = req.getOrgId().split(",");
			for (String org : orgId) {
				monthlyAdminReport.addAll(uaReqResViewRepository.getMonthlySummary(req.getFromDate(), req.getToDate())
						.stream().filter(a -> a.getOrgId().equals(org)).collect(Collectors.toList()));
			}
		}
		if (req.getReqType() != null && !req.getReqType().equals("")) {
			monthlyAdminReport = uaReqResViewRepository.getMonthlySummary(req.getFromDate(), req.getToDate()).stream()
					.filter(a -> a.getReqType().equals(req.getReqType())).collect(Collectors.toList());
		}
		return monthlyAdminReport;
	}
	
	@Override
	public List<ReqSummaryDto> getWatchlistSummaryAuth(RequestDateDTO req) {

		List<ReqSummaryDto> reqSummary = new ArrayList<>();

		if (req.getOrgId() != null) {
			String[] orgId = req.getOrgId().split(",");
			for (String org : orgId) {
				reqSummary.addAll(uaReqResViewRepository.getWatchlistSummaryAuth(req.getFromDate(),req.getToDate(), req.getUserId()).stream().filter(a -> (a.getPoId().equals(Integer.parseInt(org)))).collect(Collectors.toList()));
			}
		}
		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			reqSummary = reqSummary.stream().filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());

		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqSummary = reqSummary.stream().filter(a -> (a.getRaisedBy().equals(req.getUserName()))).collect(Collectors.toList());

		return reqSummary;
	}
	
	@Override
	public List<CaseSummaryReport> getCasePendingNodal(RequestDateDTO req) {
		return uaReqResViewRepository.getCaseApprovalNodal(req.getFromDate(), req.getToDate(), Integer.parseInt(req.getOrgId()), req.getUserName(), req.getRoleId(), req.getStatusCode())
				.stream().filter(a -> (a.getStatusCode().contains(Constants.PENDING_CASES))).collect(Collectors.toList());
	}
	
	
	@Override
	public List<CaseOwnerParticipantReport> getCaseOwnerParticipant(RequestDateDTO req) {
		List<CaseOwnerParticipantReport> caseCountList = uaReqResViewRepository.getCaseOwnerParticipant(Integer.parseInt(req.getOrgId()));
		
		if(!(req.getUserName() == null || req.getUserName().equals("")))
			caseCountList = caseCountList.stream().filter(a -> (a.getUser().contains(req.getUserName()))).collect(Collectors.toList());
		
		if(!(req.getUserLoginId() == null || req.getUserLoginId().equals("")))
			caseCountList = caseCountList.stream().filter(a -> (a.getUser().contains(req.getUserLoginId()))).collect(Collectors.toList());
		
		if(!(req.getRoleName() == null || req.getRoleName().equals("")))
			caseCountList = caseCountList.stream().filter(a -> (a.getUser().contains(req.getRoleName()))).collect(Collectors.toList());
			
		return caseCountList;
	}
	
	@Override
	public List<CaseListDto> getCaseListOwnerParticipant(RequestDateDTO req) {
		
		return uaReqResViewRepository.getCaseListOwnerParticipant(Integer.parseInt(req.getOrgId()))
				.stream().filter(a -> (a.getOwner().equals(req.getUserName()) || a.getParticipant().equals(req.getUserName())))
				.collect(Collectors.toList());
	}
	
	@Override
	public List<ReqSummaryDto> getWatchlistSummaryNodal(RequestDateDTO req) {
		
		List<ReqSummaryDto> reqSummary = uaReqResViewRepository.getWatchlistSummaryNodal(req.getFromDate(), req.getToDate(),Integer.parseInt(req.getOrgId()));
		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			reqSummary = reqSummary.stream()
					.filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());
		if ((req.getPoId() != null))
			reqSummary = reqSummary.stream().filter(a -> (a.getPoId().equals(req.getPoId()))).collect(Collectors.toList());
		
		if(!(req.getUserName() == null || req.getUserName().equals("")))
			reqSummary = reqSummary.stream().filter(a -> (a.getRaisedBy().contains(req.getUserName()))).collect(Collectors.toList());
		
		if(!(req.getRoleName() == null || req.getRoleName().equals("")))
			reqSummary = reqSummary.stream().filter(a -> (a.getRaisedBy().contains(req.getRoleName()))).collect(Collectors.toList());
		
		return reqSummary;
	}
	
	@Override
	public List<CaseMartCommon> getCaseMartCommon(RequestDateDTO req) {
		List<CaseMartCommon> caseMart =  uaReqResViewRepository.getCaseMartCommon(req.getFromDate(), req.getToDate(), Integer.parseInt(req.getOrgId()), req.getUserName(), req.getRoleId());
		
		if (!(req.getCaseName() == null || req.getCaseName().equals("")))
			caseMart = caseMart.stream()
					.filter(a -> (a.getCaseName().equals(req.getCaseName()))).collect(Collectors.toList());
		
		return caseMart;
	}
	
	@Override
	public List<ReqListDto> getCaseMartRequests(RequestDateDTO req) {
		List<ReqListDto> caseMart =  uaReqResViewRepository.getCaseMartRequests(req.getFromDate(), req.getToDate(), Integer.parseInt(req.getOrgId()), req.getUserName(), req.getRoleId());
		
		if (!(req.getCaseName() == null || req.getCaseName().equals("")))
			caseMart = caseMart.stream()
					.filter(a -> (a.getCaseName().equals(req.getCaseName()))).collect(Collectors.toList());
		
		return caseMart;
	}
	
	@Override
	public List<UserCaseListDto> getUserCaseListNodal(RequestDateDTO req) {
		
		List<UserCaseListDto> userCaseList = uaReqResViewRepository.getUserCaseListNodal(req.getFromDate(), req.getToDate(), Integer.parseInt(req.getOrgId()));
		if(!(req.getUserName() == null || req.getUserName().equals("")))
			userCaseList = userCaseList.stream().filter(a -> (a.getRaisedBy().contains(req.getUserName()))).collect(Collectors.toList());
		
		if(!(req.getUserLoginId() == null || req.getUserLoginId().equals("")))
			userCaseList = userCaseList.stream().filter(a -> (a.getRaisedBy().contains(req.getUserLoginId()))).collect(Collectors.toList());
		
		if(!(req.getRoleName() == null || req.getRoleName().equals("")))
			userCaseList = userCaseList.stream().filter(a -> (a.getRaisedBy().contains(req.getRoleName()))).collect(Collectors.toList());
		
		if(!(req.getUserNameActor() == null || req.getUserNameActor().equals("")))
			userCaseList = userCaseList.stream().filter(a -> (a.getActor().contains(req.getUserNameActor()))).collect(Collectors.toList());
		
		if(!(req.getUserLoginIdActor() == null || req.getUserLoginIdActor().equals("")))
			userCaseList = userCaseList.stream().filter(a -> (a.getActor().contains(req.getUserLoginIdActor()))).collect(Collectors.toList());
		
		if(!(req.getRoleNameActor() == null || req.getRoleNameActor().equals("")))
			userCaseList = userCaseList.stream().filter(a -> (a.getActor().contains(req.getRoleNameActor()))).collect(Collectors.toList());
		
		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			userCaseList = userCaseList.stream().filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());
		
		if(!(req.getReqType() == null || req.getReqType().equals("")))
			userCaseList = userCaseList.stream().filter(a -> (a.getRequestType().contains(req.getReqType()))).collect(Collectors.toList());
		
		return userCaseList;
	}
	
	@Override
	public List<AllRequestStatusDTO> getAllReqStatus() {
		return uaReqResViewRepository.getAllReqStatus();
	}

	@Override
	public List<AllCaseStatusDTO> getAllCaseStatus() {
		return uaReqResViewRepository.getAllCaseStatus();
	}
	
	@Override
	public List<CaseListDto> getCaseListSup(RequestDateDTO req) {

		List<CaseListDto> caseListSup = new ArrayList<>();
		
		List<Integer> userIds = getUserHierarchy(req.getUserId());

		for (Integer userId : userIds) {
			caseListSup.addAll(uaReqResViewRepository.getCaseListAuth(req.getFromDate(), req.getToDate(), userId));
		}
		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			caseListSup = caseListSup.stream().filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());

		if (!(req.getUserName() == null || req.getUserName().equals("")))
			caseListSup = caseListSup.stream().filter(a -> (a.getCreator().equals(req.getUserName()))).collect(Collectors.toList());

		return caseListSup;
	}
	
	@Override
	public List<ReqListDto> getCaseRecommendNodal(RequestDateDTO req) {
		List<ReqListDto> caseCountList = uaReqResViewRepository.getCaseRecommendNodal(req.getFromDate(), req.getToDate(),Integer.parseInt(req.getOrgId()));
		
		if(!(req.getUserName() == null || req.getUserName().equals("")))
			caseCountList = caseCountList.stream().filter(a -> (a.getRaisedBy().contains(req.getUserName()))).collect(Collectors.toList());
		
		if(!(req.getUserLoginId() == null || req.getUserLoginId().equals("")))
			caseCountList = caseCountList.stream().filter(a -> (a.getRaisedBy().contains(req.getUserLoginId()))).collect(Collectors.toList());
		
		if(!(req.getRoleName() == null || req.getRoleName().equals("")))
			caseCountList = caseCountList.stream().filter(a -> (a.getRaisedBy().contains(req.getRoleName()))).collect(Collectors.toList());
		
		if(!(req.getCaseName() == null || req.getCaseName().equals("")))
			caseCountList = caseCountList.stream().filter(a -> (a.getCaseName().contains(req.getCaseName()))).collect(Collectors.toList());
			
		return caseCountList;
	}
	
	@Override
	public List<UserListDto> getUserListDesg(RequestDateDTO req) {
		List<UserListDto> userList = uaReqResViewRepository.getUserListDesg(Integer.parseInt(req.getOrgId()));
		
		if (!(req.getUserStatus() == null || req.getUserStatus().equals("")))
			userList = userList.stream().filter(a -> (a.getStatus().equals(req.getUserStatus()))).collect(Collectors.toList());
		if (!(req.getRoleName() == null || req.getRoleName().equals("")))
			userList = userList.stream().filter(a -> (a.getRole().equals(req.getRoleName()))).collect(Collectors.toList());
		
		return userList;
	}

	@Override
	public List<ReqListDto> getReqListSup(RequestDateDTO req) {
		
		List<ReqListDto>  reqList = new ArrayList<>();
		
		List<Integer> userIds = getUserHierarchy(req.getUserId());
		
		for (Integer userId : userIds) {
			reqList.addAll(uaReqResViewRepository.getReqListAuth(req.getFromDate(), req.getToDate(), userId));			
		}		
		if(req.getCaseId() != null)
			reqList = reqList.stream().filter(a -> (a.getCaseId().equals(req.getCaseId()))).collect(Collectors.toList());

		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			reqList = reqList.stream().filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());
				
//		if ((req.getPoId() != null))
//			reqList = reqList.stream().filter(a -> (a.getPoId().equals(req.getPoId()))).collect(Collectors.toList());

		if (req.getPos() != null || !req.getPos().equals("")) {
			String[] poIds = req.getPos().split(",");
			for (String po : poIds) {
				reqList.addAll(reqList.stream().filter(a -> (a.getPoId().equals(Integer.parseInt(po)))).collect(Collectors.toList()));
			}
		}
		
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqList = reqList.stream().filter(a -> (a.getRaisedBy().equals(req.getUserName()))).collect(Collectors.toList());
		
		if (!(req.getReqCategory() == null || req.getReqCategory().equals("")))
			reqList = reqList.stream().filter(a -> (a.getReqCategory().equals(req.getReqCategory()))).collect(Collectors.toList());
		
		if (!(req.getReqType() == null || req.getReqType().equals("")))
			reqList = reqList.stream().filter(a -> (a.getReqType( ).equals(req.getReqType()))).collect(Collectors.toList());
				
		if (!(req.getCaseName() == null || req.getCaseName().equals("")))
			reqList = reqList.stream().filter(a -> (a.getCaseName().equals(req.getCaseName()))).collect(Collectors.toList());
		
		return reqList;
	}
	
	@Override
	public List<ReqSummaryDto> getReqSummarySup(RequestDateDTO req) {

		List<ReqSummaryDto> reqSummary = new ArrayList<>();

		List<Integer> userIds = getUserHierarchy(req.getUserId());

		for (Integer userId : userIds) {
			reqSummary.addAll(uaReqResViewRepository.getReqSummaryAuth(req.getFromDate(), req.getToDate(), userId));
		}
		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			reqSummary = reqSummary.stream().filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());
	//	if ((req.getPoId() != null))
	//		reqSummary = reqSummary.stream().filter(a -> (a.getPoId().equals(req.getPoId()))).collect(Collectors.toList());
		
		if (req.getPos() != null || !req.getPos().equals("")) {
			String[] poIds = req.getPos().split(",");
			for (String po : poIds) {
				reqSummary.addAll(reqSummary.stream().filter(a -> (a.getPoId().equals(Integer.parseInt(po)))).collect(Collectors.toList()));
			}
		}	

		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqSummary = reqSummary.stream().filter(a -> (a.getRaisedBy().equals(req.getUserName()))).collect(Collectors.toList());

		return reqSummary;
	}
	

	@Override
	public List<DayWiseReqResReport> getDayWiseErReq(RequestDateDTO req) {
		List<DayWiseReqResReport> erDayCount = new ArrayList<>();
				
		if(req.getOrgId() == null || req.getOrgId().equals(""))
			erDayCount.addAll(uaReqResViewRepository.getDayWiseErReq(req.getFromDate(), req.getToDate()));
		else {
					String[] orgId = req.getOrgId().split(",");
					for(String org : orgId) {
						erDayCount.addAll(uaReqResViewRepository.getDayWiseErReqOrg(req.getFromDate(), req.getToDate(),Integer.parseInt(org)));
					}
		}
		
		if(!(req.getRoleName() == null || req.getRoleName().equals("")))
			erDayCount = erDayCount.stream().filter(a -> (a.getRoleName().equals(req.getRoleName()))).collect(Collectors.toList());
		
		if(req.getReqCount() != null)
			erDayCount = erDayCount.stream().filter(a -> (a.getRequest()>=req.getReqCount())).collect(Collectors.toList());
		
		return erDayCount;
	}
	
	@Override
	public List<ReqErrorNodalDto> getErrorReqSup(RequestDateDTO req) {
		List<Integer> userIds = getUserHierarchy(req.getUserId());
		List<ReqErrorNodalDto> reqError = new ArrayList<>();
		
		for (Integer userId : userIds) {
			reqError.addAll(uaReqResViewRepository.getErrorReqAuth(userId));
		}
			
		if(req.getPoId() == null || req.getPoId().equals(""))
			return reqError;
		else {
			String[] poIds = req.getOrgId().split(",");
			for(String poId : poIds) {
				reqError.addAll(reqError.stream().filter(a -> a.getPoId().equals(Integer.parseInt(poId))).collect(Collectors.toList()));
			}
			return reqError;
		}
	}
	
	@Override
	public List<CaseSummaryReport> getCasePendingSup(RequestDateDTO req) {
		
		List<Integer> userIds = getUserHierarchy(req.getUserId());
		List<CaseSummaryReport> reqPending = new ArrayList<>();
		for (Integer userId : userIds) {			
			reqPending.addAll(uaReqResViewRepository.getCaseApprovalSup(req.getFromDate(), req.getToDate(), userId, req.getRoleId(), req.getStatusCode()));
		}		
		return reqPending.stream().filter(a -> (a.getStatusCode().contains(Constants.PENDING_CASES))).collect(Collectors.toList());
	}
	
	@Override
	public List<ReqListDto> getCaseRecommendSup(RequestDateDTO req) {

		List<Integer> userIds = getUserHierarchy(req.getUserId());
		List<ReqListDto> reqRecom = new ArrayList<>();

		for (Integer userId : userIds) {
			reqRecom.addAll(uaReqResViewRepository.getCaseRecommendSup(req.getFromDate(), req.getToDate(), userId));
		}
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqRecom = reqRecom.stream().filter(a -> (a.getRaisedBy().contains(req.getUserName()))).collect(Collectors.toList());

		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			reqRecom = reqRecom.stream().filter(a -> (a.getStatusCode().contains(req.getStatusCode()))).collect(Collectors.toList());

		if (!(req.getCaseName() == null || req.getCaseName().equals("")))
			reqRecom = reqRecom.stream().filter(a -> (a.getCaseName().contains(req.getCaseName()))).collect(Collectors.toList());
		
		return reqRecom;
	}
	
	@Override
	public List<ReqSummaryDto> getWatchlistSummarySup(RequestDateDTO req) {
		
		List<Integer> userIds = getUserHierarchy(req.getUserId());
		List<ReqSummaryDto> reqSummary = new ArrayList<>();

		for (Integer userId : userIds) {
			reqSummary = uaReqResViewRepository.getWatchlistSummaryAuth(req.getFromDate(), req.getToDate(), userId);
		}		
		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			reqSummary = reqSummary.stream()
					.filter(a -> (a.getStatusCode().equals(req.getStatusCode()))).collect(Collectors.toList());
		if ((req.getPoId() != null))
			reqSummary = reqSummary.stream().filter(a -> (a.getPoId().equals(req.getPoId()))).collect(Collectors.toList());
		
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqSummary = reqSummary.stream().filter(a -> (a.getRaisedBy().equals(req.getUserName()))).collect(Collectors.toList());
		
		return reqSummary;
	}
	
	@Override
	public List<ErReqSummaryDto> getErReqSummaryAuth(RequestDateDTO req) {
		
		List<ErReqSummaryDto> reqSummary = uaReqResViewRepository.getErReqSummaryAuth(req.getFromDate(), req.getToDate(), req.getUserId());
	
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqSummary = reqSummary.stream().filter(a -> (a.getRaisedBy().equals(req.getUserName()))).collect(Collectors.toList());
		
		return reqSummary;
	}
	
	@Override
	public List<ErReqSummaryDto> getErReqSummaryNodal(RequestDateDTO req) {
		
		List<ErReqSummaryDto> reqSummary = uaReqResViewRepository.getErReqSummaryNodal(req.getFromDate(), req.getToDate(), Integer.parseInt(req.getOrgId()));
		
		if (!(req.getRoleName() == null || req.getRoleName().equals(""))) 
			reqSummary = reqSummary.stream().filter(a -> (a.getRaisedBy().contains(req.getRoleName()))).collect(Collectors.toList());

		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqSummary = reqSummary.stream().filter(a -> (a.getRaisedBy().equals(req.getUserName()))).collect(Collectors.toList());
		
		return reqSummary;
	}
	
	@Override
	public List<ErReqSummaryDto> getErReqSummarySup(RequestDateDTO req) {

		List<ErReqSummaryDto> reqSummary = new ArrayList<>();

		List<Integer> userIds = getUserHierarchy(req.getUserId());

		for (Integer userId : userIds) {
			reqSummary.addAll(uaReqResViewRepository.getErReqSummaryAuth(req.getFromDate(), req.getToDate(), userId));
		}
		if (!(req.getRoleName() == null || req.getRoleName().equals(""))) 
			reqSummary = reqSummary.stream().filter(a -> (a.getRaisedBy().contains(req.getRoleName()))).collect(Collectors.toList());
		if (!(req.getUserName() == null || req.getUserName().equals("")))
			reqSummary = reqSummary.stream().filter(a -> (a.getRaisedBy().equals(req.getUserName()))).collect(Collectors.toList());

		return reqSummary;
	}
	
	@Override
	public List<CaseMartCommon> getPendingReqForMart(RequestDateDTO req) {
		
		List<CaseMartCommon> caseCountList = new ArrayList<>();
		List<Integer> userIds = getUserHierarchy(req.getUserId());

		for (Integer userId : userIds) {
			caseCountList.addAll( uaReqResViewRepository.getPendingReqForMart(req.getFromDate(), req.getToDate(),userId, req.getUserName(),req.getMartTypeId()));
		}
		if(!(req.getCaseName() == null || req.getCaseName().equals("")))
			caseCountList = caseCountList.stream().filter(a -> (a.getCaseName().contains(req.getCaseName()))).collect(Collectors.toList());
		
		if(!(req.getRoleName() == null || req.getRoleName().equals("")))
			caseCountList = caseCountList.stream().filter(a -> (a.getRoleName().equals(req.getRoleName()))).collect(Collectors.toList());

		return caseCountList;
	}
	@Override
	public List<ReqListDto> getCaseMartRequestsApp(RequestDateDTO req) {
		
		List<ReqListDto> caseMart = new ArrayList<>();
		List<Integer> userIds = getUserHierarchy(req.getUserId());

		for (Integer userId : userIds) {
			caseMart.addAll(uaReqResViewRepository.getCaseMartRequestsApp(req.getFromDate(), req.getToDate(), userId, req.getUserName(), req.getMartTypeId()));
					}	
		if (!(req.getCaseName() == null || req.getCaseName().equals("")))
			caseMart = caseMart.stream().filter(a -> (a.getCaseName().equals(req.getCaseName()))).collect(Collectors.toList());
		
		return caseMart;
	}
	
	@Override
	public List<CaseSummaryReport> getCaseSummarySup(RequestDateDTO req) {
		List<CaseSummaryReport> caseMart = new ArrayList<>();
		List<Integer> userIds = getUserHierarchy(req.getUserId());

		for (Integer userId : userIds) {
			caseMart.addAll(uaReqResViewRepository.getCaseSummarySup(req.getFromDate(), req.getToDate(), userId,req.getUserName()));
		}
		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			caseMart = caseMart.stream().filter(a -> a.getStatusCode().equals(req.getStatusCode())).collect(Collectors.toList());
		return caseMart;
	}
	
	@Override
	public List<UaCaseStatisticsReport> uaCaseStats(RequestDateDTO req) {
		List<UaCaseStatisticsReport> uaCaseReport = new ArrayList<>();
		
		if(req.getOrgId() == null || req.getOrgId().equals(""))
			uaCaseReport.addAll(uaReqResViewRepository.getUaCaseStats(req.getFromDate(), req.getToDate()));
		else {
			String[] orgId = req.getOrgId().split(",");
			for(String org : orgId) {
				uaCaseReport.addAll(uaReqResViewRepository.getUaCaseStats(req.getFromDate(), req.getToDate()).stream()
				.filter(a -> a.getOrgId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
			}	
		}
		return uaCaseReport;
	}
	
	@Override
	public UaWiseMonthWiseReport uaWiseMonthWiseReport(RequestDateDTO req) {		
		UaWiseMonthWiseReport uaWiseMonthWiseReport = new UaWiseMonthWiseReport();
		
		if(req.getOrgId() == null || req.getOrgId().equals("")) {
			uaWiseMonthWiseReport.setUaWiseMonthWise(uaReqResViewRepository.getMonthWiseUaWiseAdmin(req.getFromDate(), req.getToDate()));
			uaWiseMonthWiseReport.setMonthWise(uaReqResViewRepository.getMonthWiseAdmin(req.getFromDate(), req.getToDate()));
			uaWiseMonthWiseReport.setUaWise(uaReqResViewRepository.getUaWiseAdmin(req.getFromDate(), req.getToDate()));
		}
		
		else {
			String[] orgId = req.getOrgId().split(",");
			Integer[] ua = new Integer[orgId.length];
			for(int i = 0; i< orgId.length; i++)
				ua[i] =  Integer.parseInt(orgId[i]);
			uaWiseMonthWiseReport.getMonthWise().addAll(uaReqResViewRepository.getMonthWiseAdmin(req.getFromDate(), req.getToDate(), ua));
			for(String org : orgId) {
				uaWiseMonthWiseReport.getUaWiseMonthWise().addAll(uaReqResViewRepository.getMonthWiseUaWiseAdmin(req.getFromDate(), req.getToDate()).stream()
						.filter(a -> a.getOrgId().equals(org)).collect(Collectors.toList()));
				uaWiseMonthWiseReport.getUaWise().addAll(uaReqResViewRepository.getUaWiseAdmin(req.getFromDate(), req.getToDate()).stream()
						.filter(a -> a.getOrgId().equals(org)).collect(Collectors.toList()));
			}	
		}
		
		return uaWiseMonthWiseReport; 
	}
	
	@Override
	public PoWiseMonthWiseReport poWiseMonthWiseReport(RequestDateDTO req) {
		PoWiseMonthWiseReport poWiseMonthWiseReport = new PoWiseMonthWiseReport();
		if(req.getOrgId() == null || req.getOrgId().equals("")) {
			poWiseMonthWiseReport.setPoWiseMonthWise(uaReqResViewRepository.getMonthWisePoWiseAdmin(req.getFromDate(), req.getToDate()));
			poWiseMonthWiseReport.setMonthWise(uaReqResViewRepository.getMonthWiseAdminPo(req.getFromDate(), req.getToDate()));
			poWiseMonthWiseReport.setPoWise(uaReqResViewRepository.getPoWiseAdmin(req.getFromDate(), req.getToDate()));
		}
			
		else {
			String[] orgId = req.getOrgId().split(",");
			Integer[] po = new Integer[orgId.length];
			for(int i = 0; i< orgId.length; i++)
				po[i] =  Integer.parseInt(orgId[i]);
			poWiseMonthWiseReport.getMonthWise().addAll(uaReqResViewRepository.getMonthWiseAdminPo(req.getFromDate(), req.getToDate(), po));
			for(String org : orgId) {
				poWiseMonthWiseReport.getPoWiseMonthWise().addAll(uaReqResViewRepository.getMonthWisePoWiseAdmin(req.getFromDate(), req.getToDate()).stream()
						.filter(a -> a.getOrgId().equals(org)).collect(Collectors.toList()));
				poWiseMonthWiseReport.getPoWise().addAll(uaReqResViewRepository.getPoWiseAdmin(req.getFromDate(), req.getToDate()).stream()
						.filter(a -> a.getOrgId().equals(org)).collect(Collectors.toList()));
			}	
		}
		return poWiseMonthWiseReport; 
	}
	
	@Override
	public List<UnrespondedDto> getUnresponded(RequestDateDTO req) {
		List<UnrespondedDto> unresponded = new ArrayList<>();
		
		if(req.getOrgId() == null || req.getOrgId().equals("")) {
			if(!(req.getPos() == null || req.getPos().equals(""))) {
				String[] poId = req.getPos().split(",");
				for(String po : poId)
					unresponded.addAll(uaReqResViewRepository.getUnresponded(req.getFromDate(), req.getToDate())
					.stream().filter(a -> a.getPoId().equals(Integer.parseInt(po))).collect(Collectors.toList()));
			}
			else
				unresponded.addAll(uaReqResViewRepository.getUnresponded(req.getFromDate(), req.getToDate()));
		}
		else {
			if(!(req.getPos() == null || req.getPos().equals(""))) {
				String[] poId = req.getPos().split(",");
				for(String po : poId) {
					String[] orgId = req.getOrgId().split(",");
					for(String org : orgId)
						unresponded.addAll(uaReqResViewRepository.getUnresponded(req.getFromDate(), req.getToDate())
								.stream().filter(a -> a.getPoId().equals(Integer.parseInt(po)))
								.filter(a -> a.getUaId().equals(Integer.parseInt(org))).collect(Collectors.toList()));
				}		
			}
			else {
				String[] orgId = req.getOrgId().split(",");
				for(String org : orgId)
					unresponded.addAll(uaReqResViewRepository.getUnresponded(req.getFromDate(), req.getToDate())
						.stream().filter(a -> a.getUaId().equals(Integer.parseInt(org))).collect(Collectors.toList()));	
			}
		}
		
		if (!(req.getStatusCode() == null || req.getStatusCode().equals("")))
			unresponded =unresponded.stream().filter(a -> (a.getStatus().equals(req.getStatusCode()))).collect(Collectors.toList());
		
		return unresponded;
	}
	@Override
	public List<AllRequestStatusDTO> getUnrespondedReqStatus() {
		return uaReqResViewRepository.getUnrespondedReqStatus();	
	}

	@Override
	public List<SharingDataDto> getSharingDataReport(RequestDateDTO req) {
		List<SharingDataDto> sharingData = new ArrayList<>();

		if (req.getReqCategory().equalsIgnoreCase("All")) {
			sharingData.addAll(uaReqResViewRepository.getSharingData(req.getFromDate(), req.getToDate()));
		} else if (req.getReqCategory().equalsIgnoreCase("true")) {
			sharingData.addAll(uaReqResViewRepository.getSharingData(req.getFromDate(), req.getToDate()).stream()
					.filter(a -> a.getUaCategory().equals("State")).collect(Collectors.toList()));
		} else if (req.getReqCategory().equalsIgnoreCase("false")) {
			sharingData.addAll(uaReqResViewRepository.getSharingData(req.getFromDate(), req.getToDate()).stream()
					.filter(a -> a.getUaCategory().equals("Central")).collect(Collectors.toList()));
		}

		if (req.getOrgId() == null || req.getOrgId().equals("")) {
			return sharingData;
		} else {
			List<SharingDataDto> sharingDataOrg = new ArrayList<>();
			String[] orgId = req.getOrgId().split(",");
			for (String org : orgId)
				sharingDataOrg.addAll(uaReqResViewRepository.getSharingData(req.getFromDate(), req.getToDate()).stream()
						.filter(a -> a.getUaId().equals(Integer.parseInt(org))).collect(Collectors.toList()));

			return sharingDataOrg;
		}
	}
	
	
	@Override
	public List<WorklistStatusDTO> getWorklistStatus() {
		return uaReqResViewRepository.getWorklistStatus();
	}
}
