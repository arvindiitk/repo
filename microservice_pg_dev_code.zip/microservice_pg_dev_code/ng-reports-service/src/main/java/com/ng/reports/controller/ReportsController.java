package com.ng.reports.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ng.common.constant.Constants;
import com.ng.common.response.ApiResponse;
import com.ng.reports.entity.ReportsDetails;
import com.ng.reports.request.RequestDateDTO;
import com.ng.reports.response.AdminApprovalReport;
import com.ng.reports.response.AllCaseStatusDTO;
import com.ng.reports.response.AllRequestStatusDTO;
import com.ng.reports.response.CaseHistoryNodalDto;
import com.ng.reports.response.CaseListDto;
import com.ng.reports.response.CaseMartCommon;
import com.ng.reports.response.CaseOwnerParticipantReport;
import com.ng.reports.response.CaseSummaryReport;
import com.ng.reports.response.CaseTransferNodalDto;
import com.ng.reports.response.DayWiseReqResReport;
import com.ng.reports.response.ErReqSummaryDto;
import com.ng.reports.response.MonthlyAdminReportDto;
import com.ng.reports.response.OrgCategoryReqResReport;
import com.ng.reports.response.OrgWiseReqResReport;
import com.ng.reports.response.PoWiseMonthWiseReport;
import com.ng.reports.response.PreviousMonthReqSumDto;
import com.ng.reports.response.ReqErrorNodalDto;
import com.ng.reports.response.ReqListDto;
import com.ng.reports.response.ReqSummaryDto;
import com.ng.reports.response.SharingDataDto;
import com.ng.reports.response.SubReqHistoryNodalDto;
import com.ng.reports.response.UAWiseDayWiseDto;
import com.ng.reports.response.UaCaseStatisticsReport;
import com.ng.reports.response.UaTopWiseReqResReport;
import com.ng.reports.response.UaWiseMonthWiseReport;
import com.ng.reports.response.UnrespondedDto;
import com.ng.reports.response.UserCaseListDto;
import com.ng.reports.response.UserListDto;
import com.ng.reports.response.WorklistStatusDTO;
import com.ng.reports.service.SubRequestService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/ng-reports")
@Transactional(timeout = 240)
public class ReportsController {

	@Autowired
	SubRequestService subRequestService;

	@PostMapping("/ng-getUaWiseReqResReport")
	public ResponseEntity<Object> getUaWiseReqResReport(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getUaWiseReqResReport");

		List<OrgWiseReqResReport> uaReqResCount = subRequestService.uaReqResCount(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaReqResCount).build();
		log.info("[ReportsController.getUaWiseReqResReport] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping("/ng-getPoWiseReqResReport")
	public ResponseEntity<Object> getPoWiseReqResReport(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getPoWiseReqResReport");

		List<OrgWiseReqResReport> poReqResCount = subRequestService.poReqResCount(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(poReqResCount).build();
		log.info("[ReportsController.getPoWiseReqResReport] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping("/ng-getCategoryWiseReqSummary")
	public ResponseEntity<Object> getCategoryWiseReqSummary(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCategoryWiseReqSummary");

		List<OrgWiseReqResReport> poReqResCount = subRequestService.categoryWiseReqSummary(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(poReqResCount).build();
		log.info("[ReportsController.getCategoryWiseReqSummary] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping("/ng-getPreviousMonthReqSummary")
	public ResponseEntity<Object> getPreviousMonthReqSummary(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getPreviousMonthReqSummary");

		List<PreviousMonthReqSumDto> prevMonthReqSum = subRequestService.prevMonthReqSummary(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(prevMonthReqSum).build();
		log.info("[ReportsController.getPreviousMonthReqSummary] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping("/ng-getUaTopWiseReqRes")
	public ResponseEntity<Object> getUaTopWiseReqRes(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getUaTopWiseReqRes");

		List<UaTopWiseReqResReport> uaReqResCount = subRequestService.uaTopWiseReqResCount(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaReqResCount).build();
		log.info("[ReportsController.getUaTopWiseReqRes] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}

	@PostMapping("/ng-getPoTopWiseReqRes")
	public ResponseEntity<Object> getPoTopWiseReqRes(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getPoTopWiseReqRes");

		List<UaTopWiseReqResReport> uaReqResCount = subRequestService.poTopWiseReqResCount(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaReqResCount).build();
		log.info("[ReportsController.getPoTopWiseReqRes] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@GetMapping("/ng-getAllReportsDetails")
	public ResponseEntity<Object> getAllReportsDetails() {
		log.info("ReportsController :getAllReportsDetails");

		List<ReportsDetails> reportList = subRequestService.reportsDetails();

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(reportList).build();
		log.info("[ReportsController.getAllReportsDetails] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@PostMapping("/ng-getDayWiseReqRes")
	public ResponseEntity<Object> getDayWiseReqRes(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getDayWiseReqRes");

		List<DayWiseReqResReport> uaReqResCount = subRequestService.getDayWiseReqRes(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaReqResCount).build();
		log.info("[ReportsController.getDayWiseReqRes] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@PostMapping("/ng-getAdminApprovalReport")
	public ResponseEntity<Object> getAdminApprovalReport(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getAdminApprovalReport");

		List<AdminApprovalReport> adminApprovalReport = subRequestService.getAdminApprovalReport(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(adminApprovalReport).build();
		log.info("[ReportsController.getAdminApprovalReport] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@PostMapping("/ng-getUaCategoryWiseReqResReport")
	public ResponseEntity<Object> getUaCategoryWiseReqResReport(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getUaCategoryWiseReqResReport");

		List<UAWiseDayWiseDto> uaCatReqResReport = subRequestService.getUaCatReqRes(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaCatReqResReport).build();
		log.info("[ReportsController.getUaCategoryWiseReqResReport] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getUaDayWiseReqResReport")
	public ResponseEntity<Object> getUaDayWiseReqResReport(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getUaCategoryReqResReport");

		List<UAWiseDayWiseDto> uaCatReqResReport = subRequestService.getDayWiseCatReqRes(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaCatReqResReport).build();
		log.info("[ReportsController.getUaDayWiseReqResReport] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getUaWiseReqRes")
	public ResponseEntity<Object> getUaWiseReqRes(@RequestBody RequestDateDTO req) {
		log.info("ReportsController : getUaCategoryReqResReport");

		List<UAWiseDayWiseDto> uaCatReqResReport = subRequestService.getUAwiseCatReqRes(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaCatReqResReport).build();
		log.info("[ReportsController.getUaDayWiseReqResReport] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getPoCategoryReqResReport")
	public ResponseEntity<Object> getPoCategoryReqResReport(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getPoCategoryReqResReport");

		List<OrgCategoryReqResReport> poCatReqResReport = subRequestService.getPoCatReqRes(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(poCatReqResReport).build();
		log.info("[ReportsController.getPoCategoryReqResReport] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getPoDayWiseReqResReport")
	public ResponseEntity<Object> getPoDayWiseReqResReport(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getPoDayWiseReqResReport");

		List<OrgCategoryReqResReport> poCatReqResReport = subRequestService.getPoDayWiseReqRes(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(poCatReqResReport).build();
		log.info("[ReportsController.getPoDayWiseReqResReport] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getPoWiseReqResReportData")
	public ResponseEntity<Object> getPoWiseReqResReportData(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getPoWiseReqResReportData");

		List<OrgCategoryReqResReport> poCatReqResReport = subRequestService.getPoWiseReqRes(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(poCatReqResReport).build();
		log.info("[ReportsController.getPoWiseReqResReportData] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getUaCategoryRequest")
	public ResponseEntity<Object> getUaCategoryRequest(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getUaCategoryRequest");

		List<OrgCategoryReqResReport> poCatReqResReport = subRequestService.getUserCatReq(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(poCatReqResReport).build();
		log.info("[ReportsController.getUaCategoryRequest] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseSummaryNodal")
	public ResponseEntity<Object> getCaseSummaryNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseSummaryNodal");

		List<CaseSummaryReport> caseSummaryReport = subRequestService.getCaseSummaryNodal(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCaseSummaryNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseListNodal")
	public ResponseEntity<Object> getCaseListNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseListNodal");

		List<CaseListDto> caseSummaryReport = subRequestService.getCaseListNodal(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCaseListNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getReqListNodal")
	public ResponseEntity<Object> getReqListNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getReqListNodal");

		List<ReqListDto> caseSummaryReport = subRequestService.getReqListNodal(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getReqListNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getReqSummaryNodal")
	public ResponseEntity<Object> getReqSummaryNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getReqSummaryNodal");

		List<ReqSummaryDto> caseSummaryReport = subRequestService.getReqSummaryNodal(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getReqSummaryNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseTransferNodal")
	public ResponseEntity<Object> getCaseTransferNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseTransferNodal");

		List<CaseTransferNodalDto> caseSummaryReport = subRequestService.getCaseTransferNodal(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCaseTransferNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseHistoryNodal")
	public ResponseEntity<Object> getCaseHistoryNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseHistoryNodal");

		List<CaseHistoryNodalDto> caseSummaryReport = subRequestService.getCaseHistoryNodal(req);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCaseHistoryNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getSubReqHistoryNodal")
	public ResponseEntity<Object> getSubReqHistoryNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getSubReqHistoryNodal");

		List<SubReqHistoryNodalDto> subReqHistory = subRequestService.getSubReqHistoryNodal(req);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(subReqHistory).build();
		log.info("[ReportsController.getSubReqHistoryNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getReqErrorNodal")
	public ResponseEntity<Object> getReqErrorNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getReqErrorNodal");

		List<ReqErrorNodalDto> subReqHistory = subRequestService.getErrorReqNodal(req);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(subReqHistory).build();
		log.info("[ReportsController.getReqErrorNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseSummaryAuth")
	public ResponseEntity<Object> getCaseSummaryAuth(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseSummaryAuth");

		List<CaseSummaryReport> caseSummaryReport = subRequestService.getCaseSummaryAuth(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCaseSummaryAuth] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseListAuth")
	public ResponseEntity<Object> getCaseListAuth(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseListAuth");

		List<CaseListDto> caseSummaryReport = subRequestService.getCaseListAuth(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCaseListAuth] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getReqListAuth")
	public ResponseEntity<Object> getReqListAuth(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getReqListAuth");

		List<ReqListDto> caseSummaryReport = subRequestService.getReqListAuth(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getReqListAuth] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getReqSummaryAuth")
	public ResponseEntity<Object> getReqSummaryAuth(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getReqSummaryAuth");

		List<ReqSummaryDto> caseSummaryReport = subRequestService.getReqSummaryAuth(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getReqSummaryAuth] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	
	@PostMapping("/ngua-getReqErrorAuth")
	public ResponseEntity<Object> getReqErrorAuth(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getReqErrorAuth");

		List<ReqErrorNodalDto> subReqHistory = subRequestService.getErrorReqAuth(req);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(subReqHistory).build();
		log.info("[ReportsController.getReqErrorAuth] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	
	@PostMapping("/ngua-getPendingCommonMartDesgn")
	public ResponseEntity<Object> getPendingCommonMartDesgn(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getPendingCommonMartDesgn");

		//subRequestService.getReqSummaryDesgn(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data("ok").build();
		log.info("[ReportsController.getPendingCommonMartDesgn] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getMonthlyReportAdmin")
	public ResponseEntity<Object> getMonthlyReportAdmin(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getMonthlyReportAdmin");

		List<MonthlyAdminReportDto> monthlySummary = subRequestService.monthlySummary(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(monthlySummary).build();
		log.info("[ReportsController.getMonthlyReportAdmin] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getWatchlistSummaryAuth")
	public ResponseEntity<Object> getWatchlistSummaryAuth(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getWatchlistSummaryAuth");

		List<ReqSummaryDto> caseSummaryReport = subRequestService.getWatchlistSummaryAuth(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getWatchlistSummaryAuth] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCasePendingNodal")
	public ResponseEntity<Object> getCasePendingNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCasePendingNodal");

		List<CaseSummaryReport> caseSummaryReport = subRequestService.getCasePendingNodal(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCasePendingNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseOwnerParticipant")
	public ResponseEntity<Object> getCaseOwnerParticipant(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseOwnerParticipant");

		List<CaseOwnerParticipantReport> caseSummaryReport = subRequestService.getCaseOwnerParticipant(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCaseOwnerParticipant] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	
	@PostMapping("/ngua-getCaseListOwnerParticipant")
	public ResponseEntity<Object> getCaseListOwnerParticipant(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseListOwnerParticipant");

		List<CaseListDto> caseSummaryReport = subRequestService.getCaseListOwnerParticipant(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCaseListOwnerParticipant] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	
	@PostMapping("/ngua-getWatchlistSummaryNodal")
	public ResponseEntity<Object> getWatchlistSummaryNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getWatchlistSummaryNodal");

		List<ReqSummaryDto> caseSummaryReport = subRequestService.getWatchlistSummaryNodal(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getWatchlistSummaryNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	
	@PostMapping("/ngua-getCaseMartCommon")
	public ResponseEntity<Object> getCaseMartCommon(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseMartCommon");

		List<CaseMartCommon> caseMartReport = subRequestService.getCaseMartCommon(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseMartReport).build();
		log.info("[ReportsController.getCaseMartCommon] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseMartCommonRequests")
	public ResponseEntity<Object> getCaseMartCommonRequests(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseMartCommonRequests");

		List<ReqListDto> caseMartReport = subRequestService.getCaseMartRequests(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseMartReport).build();
		log.info("[ReportsController.getCaseMartCommonRequests] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getUserCaseRequests")
	public ResponseEntity<Object> getUserCaseRequests(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getUserCaseRequests");

		List<UserCaseListDto> userCaseReport = subRequestService.getUserCaseListNodal(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(userCaseReport).build();
		log.info("[ReportsController.getUserCaseRequests] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@GetMapping("/ngua-getAllRequestStatus")
	public ResponseEntity<Object> getAllRequestStatus() {
		log.info("ReportsController :getAllRequestStatus");

		List<AllRequestStatusDTO> uaReqResCount = subRequestService.getAllReqStatus();

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaReqResCount).build();
		log.info("[ReportsController.getAllRequestStatus] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@GetMapping("/ngua-getAllCaseStatus")
	public ResponseEntity<Object> getAllCaseStatus() {
		log.info("ReportsController :getAllCaseStatus");

		List<AllCaseStatusDTO> uaReqResCount = subRequestService.getAllCaseStatus();

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaReqResCount).build();
		log.info("[ReportsController.getAllCaseStatus] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseListSup")
	public ResponseEntity<Object> getCaseListSup(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseListSup");

		List<CaseListDto> caseSummaryReport = subRequestService.getCaseListSup(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCaseListSup ] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseRecommendNodal")
	public ResponseEntity<Object> getCaseRecommendNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseListSup");

		List<ReqListDto> reqRecommendList = subRequestService.getCaseRecommendNodal(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(reqRecommendList).build();
		log.info("[ReportsController.getCaseRecommendNodal ] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getUserListDesg")
	public ResponseEntity<Object> getUserListDesg(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getUserListDesg");

		List<UserListDto> subReqHistory = subRequestService.getUserListDesg(req);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(subReqHistory).build();
		log.info("[ReportsController.getUserListDesg] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	@PostMapping("/ngua-getReqListSup")
	public ResponseEntity<Object> getReqListSup(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getReqListSup");

		List<ReqListDto> caseSummaryReport = subRequestService.getReqListSup(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getReqListSup] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getReqSummarySup")
	public ResponseEntity<Object> getReqSummarySup(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getReqSummarySup");

		List<ReqSummaryDto> caseSummaryReport = subRequestService.getReqSummarySup(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getReqSummarySup] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getDayWiseErReq")
	public ResponseEntity<Object> getDayWiseErReq(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getDayWiseErReq");

		List<DayWiseReqResReport> erReqResCount = subRequestService.getDayWiseErReq(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(erReqResCount).build();
		log.info("[ReportsController.getDayWiseErReq] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@PostMapping("/ngua-getReqErrorSup")
	public ResponseEntity<Object> getReqErrorSup(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getReqErrorSup");

		List<ReqErrorNodalDto> subReqHistory = subRequestService.getErrorReqSup(req);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(subReqHistory).build();
		log.info("[ReportsController.getReqErrorSup] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCasePendingSup")
	public ResponseEntity<Object> getCasePendingSup(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCasePendingSup");

		List<CaseSummaryReport> caseSummaryReport = subRequestService.getCasePendingSup(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCasePendingSup] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseRecommendSup")
	public ResponseEntity<Object> getCaseRecommendSup(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseRecommendSup");

		List<ReqListDto> reqRecommendList = subRequestService.getCaseRecommendSup(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(reqRecommendList).build();
		log.info("[ReportsController.getCaseRecommendSup] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getWatchlistSummarySup")
	public ResponseEntity<Object> getWatchlistSummarySup(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getWatchlistSummarySup");

		List<ReqSummaryDto> caseSummaryReport = subRequestService.getWatchlistSummarySup(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getWatchlistSummarySup] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getErReqSummaryAuth")
	public ResponseEntity<Object> getErReqSummaryAuth(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getErReqSummaryAuth");

		List<ErReqSummaryDto> erSummaryReport = subRequestService.getErReqSummaryAuth(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(erSummaryReport).build();
		log.info("[ReportsController.getErReqSummaryAuth] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getErReqSummaryNodal")
	public ResponseEntity<Object> getErReqSummaryNodal(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getErReqSummaryNodal");

		List<ErReqSummaryDto> erSummaryReport = subRequestService.getErReqSummaryNodal(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(erSummaryReport).build();
		log.info("[ReportsController.getErReqSummaryNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getErReqSummarySup")
	public ResponseEntity<Object> getErReqSummarySup(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getErReqSummarySup");

		List<ErReqSummaryDto> erSummaryReport = subRequestService.getErReqSummarySup(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(erSummaryReport).build();
		log.info("[ReportsController.getErReqSummarySup] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getPendingReqForMart")
	public ResponseEntity<Object> getPendingReqForMart(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getPendingReqForMart");

		List<CaseMartCommon> reqRecommendList = subRequestService.getPendingReqForMart(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(reqRecommendList).build();
		log.info("[ReportsController.getPendingReqForMart] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseMartCommonRequestsApp")
	public ResponseEntity<Object> getCaseMartCommonRequestsApp(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseMartCommonRequestsApp");

		List<ReqListDto> caseMartReport = subRequestService.getCaseMartRequestsApp(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseMartReport).build();
		log.info("[ReportsController.getCaseMartCommonRequestsApp] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ngua-getCaseSummarySup")
	public ResponseEntity<Object> getCaseSummarySup(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getCaseSummarySup");

		List<CaseSummaryReport> caseSummaryReport = subRequestService.getCaseSummarySup(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(caseSummaryReport).build();
		log.info("[ReportsController.getCaseSummarySup] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getUaCaseStats")
	public ResponseEntity<Object> getUaCaseStats(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getUaCaseStats");

		List<UaCaseStatisticsReport> uaReqResCount = subRequestService.uaCaseStats(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaReqResCount).build();
		log.info("[ReportsController.getUaCaseStats] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getMonthWiseUaWiseReport")
	public ResponseEntity<Object> getMonthWiseUaWiseReport(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getMonthWiseUaWiseReport");

		UaWiseMonthWiseReport uaWiseMonthWiseReport = subRequestService.uaWiseMonthWiseReport(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaWiseMonthWiseReport).build();
		log.info("[ReportsController.getMonthWiseUaWiseReport] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getMonthWisePoWiseReport")
	public ResponseEntity<Object> getMonthWisePoWiseReport(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getMonthWisePoWiseReport");

		PoWiseMonthWiseReport uaWiseMonthWiseReport = subRequestService.poWiseMonthWiseReport(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(uaWiseMonthWiseReport).build();
		log.info("[ReportsController.getMonthWisePoWiseReport] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getUnresponded")
	public ResponseEntity<Object> getUnresponded(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getUnresponded");

		List<UnrespondedDto> unrespondedList = subRequestService.getUnresponded(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(unrespondedList).build();
		log.info("[ReportsController.getUnresponded] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@GetMapping("/ng-getUnrespondedRequestStatus")
	public ResponseEntity<Object> getUnrespondedRequestStatus() {
		log.info("ReportsController :getUnrespondedRequestStatus");

		List<AllRequestStatusDTO> unrespondedStatusList = subRequestService.getUnrespondedReqStatus();

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(unrespondedStatusList).build();
		log.info("[ReportsController.getUnrespondedRequestStatus] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getSharingDataReport")
	public ResponseEntity<Object> getSharingDataReport(@RequestBody RequestDateDTO req) {
		log.info("ReportsController :getSharingDataReport");

		List<SharingDataDto> unrespondedStatusList = subRequestService.getSharingDataReport(req);

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(unrespondedStatusList).build();
		log.info("[ReportsController.getSharingDataReport] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@GetMapping("/ngua-getAllWorklistStatus")
	public ResponseEntity<Object> getAllWorklistStatus() {
		log.info("ReportsController :getAllWorklistStatus");

		List<WorklistStatusDTO> worklistStatus = subRequestService.getWorklistStatus();

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(worklistStatus).build();
		log.info("[ReportsController.getAllWorklistStatus] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
}
