package com.ng.reports.response;

public interface ReqSummaryDto {
	
	public Integer getReqCount();
	public Integer getWatchlistCount();
	public String getStatus();
	public String getFrequency();
	public String getStatusCode();
	public Integer getPoId();
	public String getPoName();
	public String getRaisedBy();
	public String getRoleName();
	public String getUserName();
	public String getReqCategory();
}