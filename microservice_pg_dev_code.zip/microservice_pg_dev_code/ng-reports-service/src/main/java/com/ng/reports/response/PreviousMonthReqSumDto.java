package com.ng.reports.response;

public interface PreviousMonthReqSumDto {
	
	
	public Integer getDayReq();
	public Integer getDayRes();
	public Integer getMonthReq();
	public Integer getMonthRes();
	public String getOrgName();
	public String getOrgAlias();
	public Integer getOrgId();
}
