package com.ng.reports.response;

public interface MonthlyAdminReportDto {
	

	public String getRoleName();
	public String getOrgName();
	public String getCreatedOn();
	public String getDay();
	public String getOrgId();
	public String getReqType();
	
	public Integer getTotalRequests();	
	public Integer getNsRequests();
	public Integer getSRequests();
	public Integer getHsRequests();
	
	public Integer getTotalResponses();	
	public Integer getNsResponses();
	public Integer getSResponses();
	public Integer getHsResponses();
	
	public Integer getTotalError();	
	public Integer getNsError();
	public Integer getSError();
	public Integer getHsError();
		
	public Integer getTotalRejected();	
	public Integer getNsRejected();
	public Integer getSRejected();
	public Integer getHsRejected();	
	
	public Integer getTotalPending();	
	public Integer getNsPending();
	public Integer getSPending();
	public Integer getHsPending();
	
}