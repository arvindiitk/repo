package com.ng.reports.response;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@Getter
@Setter
@ToString
public class UaWiseMonthWiseReport implements Serializable{
	
	private static final long serialVersionUID = -162410863010042945L;
	private List<UaWiseMonthWiseReportDto> uaWiseMonthWise;
	private List<UaWiseMonthWiseReportDto> monthWise;
	private List<UaWiseMonthWiseReportDto> uaWise;
		
}