package com.ng.reports.response;

public interface AllRequestStatusDTO {
	
	public Integer getReqId();
	public String getReqStatus();
}