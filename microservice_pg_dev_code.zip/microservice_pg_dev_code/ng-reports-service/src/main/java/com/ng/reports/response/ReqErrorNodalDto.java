package com.ng.reports.response;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.reports.constants.Constants;

public interface ReqErrorNodalDto {
	
	public Integer getSubReqId();
	public Integer getReqId();
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	public Timestamp getReqDate();
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	public Timestamp getErrorDate();
	public String getRequestor();
	public String getResponder();
	public String getUseCaseDescription();
	public String getReqDescription();
	public String getReqType();
	public String getOrgName();
	public Integer getPoId();
	
}