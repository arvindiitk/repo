package com.ng.reports.response;

public interface ErReqSummaryDto {
	
	public Integer getRespondedReq();
	public Integer getRespondedWithNoDataReq();
	public Integer getReq();
	public String getRaisedBy();
	public String getRaisedOn();

}