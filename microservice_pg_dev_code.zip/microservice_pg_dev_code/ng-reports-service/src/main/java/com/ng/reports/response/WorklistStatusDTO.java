package com.ng.reports.response;

public interface WorklistStatusDTO {
	
	public String getWorklistStatusCode();
	public String getWorklistStatusDesc();
}