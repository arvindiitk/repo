package com.ng.reports.response;

public interface DayWiseReqResReport {

	public String getOrgAlias();
	public String getDate();
	public String getDay();
	public Integer getRequest();
	public Integer getResponse();
	public String getRoleName();
	public String getUaName();
}
