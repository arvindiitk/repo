package com.ng.reports.response;

public interface AdminApprovalReport {
	public String getOrgName();
	public String getOrgAlias();
	public String getRoleName();
	public Integer getOrgId();
	public Integer getTotal();
	public Integer getApproved();
	public Integer getRejected();
	public Integer getPending();
}
