package com.ng.reports.request;

import java.io.Serializable;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.reports.constants.Constants;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Getter
@Setter
@ToString
public class RequestDateDTO implements Serializable {

	private static final long serialVersionUID = 801585230658255543L;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	private Timestamp fromDate;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	private Timestamp toDate;
	
	private String orgId;
	private String pos;
	private Integer poId;
	private Integer reqCount;
	private String statusCode;
	private String reqCategory;
	private String reqType;
	private Integer roleId;
	private String roleName;
	private Integer caseId;
	private Integer subReqId;
	private Integer userId;
	private String caseName;
	private String userName;
	private String userLoginId;
	private String userNameActor;
	private String userLoginIdActor;
	private String roleNameActor;
	private String userStatus;
	private Integer sameQueryExe;
	private Integer martTypeId;
	private String uaType;
}
