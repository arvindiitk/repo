package com.ng.reports.response;

public interface AllCaseStatusDTO {
	
	public String getCaseStatusCode();
	public String getCaseStatusDesc();
}