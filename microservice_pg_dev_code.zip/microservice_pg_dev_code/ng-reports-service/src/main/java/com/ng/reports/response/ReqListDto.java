package com.ng.reports.response;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.reports.constants.Constants;

public interface ReqListDto {
	
	public String getRoleName();
	public String getOrgName();
	public String getCaseName();
	public String getRaisedBy();
	public Integer getRoleId();
	public Integer getPoId();
	public Integer getCaseId();
	public String getCaseNo();
	public String getRequestor();
	public String getReqDescription();
	public String getCaseDescription();
	public String getUseCaseDescription();
	public String getReqType();
	public String getReqCategory();
	public Integer getReqId();
	public Integer getSubReqId();
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	public Timestamp getCreatedOn();
	public String getStatus();
	public String getStatusCode();
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	public Timestamp getUpdatedOn();
}