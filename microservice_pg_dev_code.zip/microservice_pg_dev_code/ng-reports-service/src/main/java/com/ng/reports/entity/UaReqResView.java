package com.ng.reports.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.reports.constants.Constants;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@Entity(name="VW_UA_REQ_RES_SUMMARY")
public class UaReqResView implements Serializable {
	
	private static final long serialVersionUID = 8310499747506330827L;

	@Id
	@Column(name="UA_ID")
	private Integer uaId;
	
	@Column(name="UA_NAME")
	private String uaName;
	
	@Column(name="NUM_OF_REQ")
	private Integer numOfReq;
	
	@Column(name="NUM_OF_RES")
	private Integer numOfRes;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_FORMAT2, timezone = "GMT+5:30")
	@Column(name="CREATED_ON")
	private Timestamp createdOn;
	
}
