package com.ng.reports.response;

import java.util.ArrayList;
import java.util.List;

import com.ng.reports.entity.UserReports;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * The persistent class for the M_PORTAL database table.
 * 
 */
@Getter
@Setter
@AllArgsConstructor
@ToString
public class UserReportList{

		List<UserReports> userReports;
		
		public UserReportList() {
			userReports = new ArrayList<>();
		}


}