package com.ng.reports.response;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.reports.constants.Constants;

public interface CaseListAuthDto {

	public Integer getCaseId();
	public String getCaseNo();
	public String getCaseName();
	public String getCaseDescription();
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	public Timestamp getCreatedOn();
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	public Timestamp getClosedOn();
	public String getStatus();
	public String getStatusCode();
	public Integer getReqCount();
	public Integer getSubReqCount();
	public Integer getWatchlistCount();
	public String getCreator();
	public String getOwner();
	
	public Integer getNsRequests();
	public Integer getSRequests();
	public Integer getHsRequests();
	public Integer getNsWatchlists();
	public Integer getSWatchlists();
	public Integer getHsWatchlists();
}