package com.ng.reports.response;

public interface OrgWiseReqResReport {
	
	public String getOrgName();
	public String getOrgAlias();
	public Integer getRequests();
	public Integer getResponses();
	public Integer getOrgId();
	public String getCategory();
}
