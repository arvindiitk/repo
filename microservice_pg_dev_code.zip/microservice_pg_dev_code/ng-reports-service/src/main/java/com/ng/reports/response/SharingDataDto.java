package com.ng.reports.response;

public interface SharingDataDto {
	
	public String getUaName();
	public String getOrgAlias();
	public Integer getUaId();
	public String getUaCategory();
	public Integer getTotalProfiles();
	public Integer getAgencyMart();
	public Integer getCommonMart();
	
}