package com.ng.reports.response;

public interface UaTopWiseReqResReport {
	
	public String getUaName();
	public String getRoleName();
	public Integer getOrgId();
	public String getOrgAlias();
	public Integer getTotalReqSentPO();
	public Integer getTotalResRec();
	public String getTopQueryExe();
	public String getPoName();
	public String getCategory();
	public Integer getSameQueryExe();

}
