package com.ng.reports.response;

public interface PoWiseMonthWiseReportDto {
	

	public String getOrgName();
	public String getOrgAlias();
	public String getOrgId();
	public String getCreatedOn();
	public String getUaType();
	
	public Integer getTotalRequests();	
	public Integer getNsRequests();
	public Integer getSRequests();
	public Integer getHsRequests();
	
	public Integer getTotalResponses();	
	public Integer getNsResponses();
	public Integer getSResponses();
	public Integer getHsResponses();
	
	public Integer getReqResDiff();
	
}