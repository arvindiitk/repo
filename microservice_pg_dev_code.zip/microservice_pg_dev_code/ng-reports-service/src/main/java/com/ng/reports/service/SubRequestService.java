package com.ng.reports.service;

import java.util.List;

import com.ng.reports.entity.ReportsDetails;
import com.ng.reports.request.RequestDateDTO;
import com.ng.reports.response.AdminApprovalReport;
import com.ng.reports.response.AllCaseStatusDTO;
import com.ng.reports.response.AllRequestStatusDTO;
import com.ng.reports.response.CaseHistoryNodalDto;
import com.ng.reports.response.CaseListDto;
import com.ng.reports.response.CaseMartCommon;
import com.ng.reports.response.CaseOwnerParticipantReport;
import com.ng.reports.response.CaseSummaryReport;
import com.ng.reports.response.CaseTransferNodalDto;
import com.ng.reports.response.DayWiseReqResReport;
import com.ng.reports.response.ErReqSummaryDto;
import com.ng.reports.response.MonthlyAdminReportDto;
import com.ng.reports.response.OrgCategoryReqResReport;
import com.ng.reports.response.OrgWiseReqResReport;
import com.ng.reports.response.PoWiseMonthWiseReport;
import com.ng.reports.response.PreviousMonthReqSumDto;
import com.ng.reports.response.ReqErrorNodalDto;
import com.ng.reports.response.ReqListDto;
import com.ng.reports.response.ReqSummaryDto;
import com.ng.reports.response.SharingDataDto;
import com.ng.reports.response.SubReqHistoryNodalDto;
import com.ng.reports.response.UAWiseDayWiseDto;
import com.ng.reports.response.UaCaseStatisticsReport;
import com.ng.reports.response.UaTopWiseReqResReport;
import com.ng.reports.response.UaWiseMonthWiseReport;
import com.ng.reports.response.UnrespondedDto;
import com.ng.reports.response.UserCaseListDto;
import com.ng.reports.response.UserListDto;
import com.ng.reports.response.WorklistStatusDTO;

public interface SubRequestService {

	public List<OrgWiseReqResReport> uaReqResCount(RequestDateDTO req);

	public List<OrgWiseReqResReport> poReqResCount(RequestDateDTO req);

	public List<OrgWiseReqResReport> categoryWiseReqSummary(RequestDateDTO req);

	public List<UaTopWiseReqResReport> uaTopWiseReqResCount(RequestDateDTO req);

	public List<UaTopWiseReqResReport> poTopWiseReqResCount(RequestDateDTO req);

	public List<ReportsDetails> reportsDetails();

	public List<DayWiseReqResReport> getDayWiseReqRes(RequestDateDTO req);

	public List<AdminApprovalReport> getAdminApprovalReport(RequestDateDTO req);

	public List<PreviousMonthReqSumDto> prevMonthReqSummary(RequestDateDTO req);

	public List<OrgCategoryReqResReport> getPoCatReqRes(RequestDateDTO req);

	public List<UAWiseDayWiseDto> getUaCatReqRes(RequestDateDTO req);

	public List<OrgCategoryReqResReport> getUserCatReq(RequestDateDTO req);

	public List<CaseSummaryReport> getCaseSummaryNodal(RequestDateDTO req);

	public List<CaseListDto> getCaseListNodal(RequestDateDTO req);

	public List<ReqListDto> getReqListNodal(RequestDateDTO req);

	public List<ReqSummaryDto> getReqSummaryNodal(RequestDateDTO req);

	public List<CaseTransferNodalDto> getCaseTransferNodal(RequestDateDTO req);

	public List<CaseHistoryNodalDto> getCaseHistoryNodal(RequestDateDTO req);

	public List<SubReqHistoryNodalDto> getSubReqHistoryNodal(RequestDateDTO req);

	public List<ReqErrorNodalDto> getErrorReqNodal(RequestDateDTO req);

	public List<CaseSummaryReport> getCaseSummaryAuth(RequestDateDTO req);

	public List<CaseListDto> getCaseListAuth(RequestDateDTO req);

	public List<ReqListDto> getReqListAuth(RequestDateDTO req);

	public List<ReqSummaryDto> getReqSummaryAuth(RequestDateDTO req);

	public List<ReqErrorNodalDto> getErrorReqAuth(RequestDateDTO req);

	public List<MonthlyAdminReportDto> monthlySummary(RequestDateDTO req);

	public List<ReqSummaryDto> getWatchlistSummaryAuth(RequestDateDTO req);

	public List<CaseSummaryReport> getCasePendingNodal(RequestDateDTO req);

	public List<CaseOwnerParticipantReport> getCaseOwnerParticipant(RequestDateDTO req);

	public List<CaseListDto> getCaseListOwnerParticipant(RequestDateDTO req);

	public List<ReqSummaryDto> getWatchlistSummaryNodal(RequestDateDTO req);

	public List<CaseMartCommon> getCaseMartCommon(RequestDateDTO req);

	public List<ReqListDto> getCaseMartRequests(RequestDateDTO req);

	public List<UserCaseListDto> getUserCaseListNodal(RequestDateDTO req);

	public List<AllRequestStatusDTO> getAllReqStatus();

	public List<AllCaseStatusDTO> getAllCaseStatus();

	public List<CaseListDto> getCaseListSup(RequestDateDTO req);

	public List<ReqListDto> getCaseRecommendNodal(RequestDateDTO req);

	public List<UserListDto> getUserListDesg(RequestDateDTO req);

	public List<ReqListDto> getReqListSup(RequestDateDTO req);

	public List<ReqSummaryDto> getReqSummarySup(RequestDateDTO req);

	public List<DayWiseReqResReport> getDayWiseErReq(RequestDateDTO req);

	public List<ReqErrorNodalDto> getErrorReqSup(RequestDateDTO req);

	public List<CaseSummaryReport> getCasePendingSup(RequestDateDTO req);

	public List<ReqListDto> getCaseRecommendSup(RequestDateDTO req);

	public List<ReqSummaryDto> getWatchlistSummarySup(RequestDateDTO req);

	public List<ErReqSummaryDto> getErReqSummaryAuth(RequestDateDTO req);

	public List<ErReqSummaryDto> getErReqSummaryNodal(RequestDateDTO req);

	public List<ErReqSummaryDto> getErReqSummarySup(RequestDateDTO req);

	public List<CaseMartCommon> getPendingReqForMart(RequestDateDTO req);

	public List<ReqListDto> getCaseMartRequestsApp(RequestDateDTO req);

	public List<CaseSummaryReport> getCaseSummarySup(RequestDateDTO req);

	public List<UaCaseStatisticsReport> uaCaseStats(RequestDateDTO req);

	public UaWiseMonthWiseReport uaWiseMonthWiseReport(RequestDateDTO req);
	
	public List<UAWiseDayWiseDto> getDayWiseCatReqRes(RequestDateDTO req);
	
	public List<UAWiseDayWiseDto> getUAwiseCatReqRes(RequestDateDTO req);

	public PoWiseMonthWiseReport poWiseMonthWiseReport(RequestDateDTO req);
	
	public List<OrgCategoryReqResReport> getPoDayWiseReqRes(RequestDateDTO req);

	public List<OrgCategoryReqResReport> getPoWiseReqRes(RequestDateDTO req);

	public List<UnrespondedDto> getUnresponded(RequestDateDTO req);

	public List<AllRequestStatusDTO> getUnrespondedReqStatus();

	public List<SharingDataDto> getSharingDataReport(RequestDateDTO req);

	public List<WorklistStatusDTO> getWorklistStatus();

}
