package com.ng.reports.response;

public interface CaseHistoryNodalDto {
	
	public String getCaseId();
	public String getEventDate();
	public String getEventTime();
	public String getActor();
	public String getCaseOwner();
	public String getStatusCode();
	public String getCreator();
	public String getRoleName();
}