package com.ng.reports.response;

public interface UserListDto {
		
	public Integer getUserId();
	public String getUserName();
	public String getEmailId();
	public String getContactNo();
	public String getStatus();
	public String getRole();
	public String getRank();
	public String getRankDesc();
}