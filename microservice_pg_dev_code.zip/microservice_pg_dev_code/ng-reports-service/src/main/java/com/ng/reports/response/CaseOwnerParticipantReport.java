package com.ng.reports.response;

public interface CaseOwnerParticipantReport {
	
	public String getUser();
	public Integer getUserId();
	public Integer getCountCasesOwner();
	public Integer getCountCasesParticipant();
}