package com.ng.reports.response;

public interface SubReqHistoryNodalDto {
	
	public String getCaseId();
	public String getReqId();
	public String getSubReqId();
	public String getEventDate();
	public String getEventTime();
	public String getActor();
	public String getRaisedBy();
	public String getCaseOwner();
	public String getStatusCode();
	
}