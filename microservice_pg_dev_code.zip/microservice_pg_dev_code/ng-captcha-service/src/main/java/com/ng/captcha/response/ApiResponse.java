package com.ng.captcha.response;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;


@Component
public class ApiResponse {
    String message;
    String status;
    List<String> errors;
    Optional<String> captcha;
    
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<String> getErrors() {
		return errors;
	}
	public void setErrors(List<String> errors) {
		this.errors = errors;
	}
	public Optional<String> getCaptcha() {
		return captcha;
	}
	public void setCaptcha(Optional<String> captcha) {
		this.captcha = captcha;
	}
	@Override
	public String toString() {
		return "ApiResponse [message=" + message + ", status=" + status + ", errors=" + errors + ", captcha=" + captcha
				+ "]";
	}
	
    
    
}
