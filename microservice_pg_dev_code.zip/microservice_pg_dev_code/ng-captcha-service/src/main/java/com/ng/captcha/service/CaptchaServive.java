package com.ng.captcha.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

@Service
public interface CaptchaServive {
    public Optional<String> getCaptcha();
}
