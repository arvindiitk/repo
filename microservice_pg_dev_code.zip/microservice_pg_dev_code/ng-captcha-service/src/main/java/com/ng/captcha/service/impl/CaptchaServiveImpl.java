package com.ng.captcha.service.impl;

import java.security.SecureRandom;
import java.util.Optional;

import com.ng.captcha.service.CaptchaServive;

import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class CaptchaServiveImpl implements CaptchaServive {

	@Override
	public Optional<String> getCaptcha() {
		Integer captchaLength = 6;
		StringBuilder captchaStrBuilder = new StringBuilder();
		Optional<String> optional = Optional.of(captchaStrBuilder.toString());
		try {
			String saltChars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ1234567890";
			// AKUD Fix
			SecureRandom rnd = new SecureRandom();
			// build a random captchaLength chars salt
			while (captchaStrBuilder.length() < captchaLength) {
				int index = (int) (rnd.nextFloat() * saltChars.length());
				captchaStrBuilder.append(saltChars.substring(index, index + 1));
			}
			log.error("generateCaptchaTextMethod2   " + captchaStrBuilder.toString());
			optional = Optional.of(captchaStrBuilder.toString());
			return optional;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return optional;
	}
}
