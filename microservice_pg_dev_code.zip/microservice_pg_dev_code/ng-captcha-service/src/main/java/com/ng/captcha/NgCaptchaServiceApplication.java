package com.ng.captcha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgCaptchaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NgCaptchaServiceApplication.class, args);
	}

}
