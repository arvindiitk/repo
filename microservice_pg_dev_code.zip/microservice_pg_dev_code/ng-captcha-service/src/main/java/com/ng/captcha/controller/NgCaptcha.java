package com.ng.captcha.controller;



import java.util.Optional;

import com.ng.captcha.response.ApiResponse;
import com.ng.captcha.service.CaptchaServive;
import com.ng.captcha.util.Constants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/auth")
@CrossOrigin("*")
public class NgCaptcha {

	@Autowired
	public CaptchaServive captchaServive;

	@GetMapping(value = "/getCaptcha", produces = "application/json")
	public ResponseEntity<ApiResponse> getCaptch() {
		Optional<String> optional = captchaServive.getCaptcha();
		ApiResponse apiResponse = new ApiResponse();
				apiResponse.setStatus(String.valueOf(HttpStatus.OK.value()));
				apiResponse.setMessage(Constants.SUCCESS);
				apiResponse.setCaptcha(optional);
		return ResponseEntity.ok().body(apiResponse);
		
	}
}