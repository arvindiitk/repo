package com.ng.org.repository;



import com.ng.org.entity.Org;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface OrgRepository extends JpaRepository<Org, Integer> {
   
	@Query (value = "select count(*) from Org where IS_ACTIVE ='true' ")
	public long count();

	@Modifying
	@Query(value = "UPDATE M_ORG SET IS_ACTIVE=:isActive, REMARKS=:remarks where ORG_ID=:orgId", nativeQuery = true)
	public Integer activateDeactivateOrganization(Integer orgId, Boolean isActive,String remarks);
	

	@Query(value = "SELECT org_type_alias FROM M_ORG_TYPE where ORG_TYPE_ID=:orgTypeId", nativeQuery = true)
	public String getOrgTypeAlias(Integer orgTypeId);
	
	@Query(value = "SELECT org_passcode FROM M_ORG where ORG_ID=:orgId", nativeQuery = true)
	public String getOrgPasscode(Integer orgId);
	
	@Query(value = "SELECT Count(1) FROM ng_ua.public_keys authpublickey "
			+ "INNER JOIN ng_cmp.m_org mOrg ON mOrg.org_id = authpublickey.org_id AND mOrg.is_active='true' "
			+ "INNER JOIN ng_cmp.m_org_type mOrgType ON mOrgType.org_type_id = mOrg.org_type_id "
			+ "WHERE authpublickey.org_id=:orgId AND authpublickey.user_id=:orgId ", nativeQuery = true)
	public Integer getOrgKeyCount(Integer orgId);
}
