package com.ng.org.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.org.constants.Constants;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


/**
 * The persistent class for the M_ROLE database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Valid
@Entity
@Table(name="M_ROLE")

public class Role implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ROLE_ID", unique=true, nullable=false)
	private Integer roleId;

	@Column(name="CREATED_BY", nullable=false,updatable = false)
	private Integer createdBy;
	
	@Column(name="ORG_TYPE_ID", nullable=false)
	private Integer orgTypeId;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT,timezone = "GMT+5:30")
	@Column(name="CREATED_ON", nullable=false,updatable = false)
	private Timestamp createdOn;

	@Column(name="IS_ACTIVE", nullable=false,columnDefinition = "default bit 1")
	private Boolean isActive;

	@Column(name="ROLE_ALIAS", nullable=false)
	private String roleAlias;

	@Column(name="ROLE_DESC")
	private String roleDesc;

	@Column(name="ROLE_LEVEL", nullable=false)
	private Integer roleLevel;

	@Column(name="ROLE_NAME", nullable=false)
	private String roleName;

	//bi-directional many-to-one association to OrgRole
	@JsonBackReference(value = "orgRoles")
	@OneToMany(mappedBy="role",cascade={CascadeType.ALL},fetch=FetchType.LAZY)
	private List<OrgRole> orgRoles;

	//bi-directional many-to-one association to OrgType
	@JsonBackReference(value = "orgType")
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORG_TYPE_ID", nullable=false,insertable = false,updatable = false)
	private OrgType orgType;

}