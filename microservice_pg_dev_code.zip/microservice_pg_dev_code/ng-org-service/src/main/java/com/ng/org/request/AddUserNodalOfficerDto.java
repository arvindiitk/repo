package com.ng.org.request;

import java.io.Serializable;

import javax.validation.Valid;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Valid
public class AddUserNodalOfficerDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer orgId;
	private Integer roleId;
}
