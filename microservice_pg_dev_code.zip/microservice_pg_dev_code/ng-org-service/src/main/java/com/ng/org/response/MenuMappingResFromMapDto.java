package  com.ng.org.response;

import java.io.Serializable;
import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@Getter
@Setter
@ToString
public class MenuMappingResFromMapDto implements Serializable {

	private static final long serialVersionUID = 1L;
    
	private Integer roleId;
	private List<PortalResFromMapDto> portalList;
}
