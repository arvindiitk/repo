package com.ng.org.repository;



import java.util.List;

import com.ng.org.response.RoleResponse;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface OrgRoleRepository extends JpaRepository<RoleResponse, Integer> {
   

		@Query(value= "SELECT DISTINCT mRole.ROLE_ID, mRole.ROLE_NAME, mRole.ROLE_LEVEL FROM M_ORG_ROLE orgRole "
				+ "INNER JOIN M_ROLE mRole ON mRole.ROLE_ID=orgRole.ROLE_ID "
				+ "WHERE orgRole.ORG_ROLE_MAP_ID =:roleMapId AND orgRole.IS_ACTIVE='true' ",nativeQuery = true)
		public RoleResponse getRolePortalId(Integer roleMapId);

		@Query(value= "SELECT DISTINCT mRole.ROLE_ID, mRole.ROLE_NAME, "
				+ "CASE WHEN mRole.ROLE_LEVEL = (SELECT min(ROLE_LEVEL) FROM M_ROLE WHERE ORG_TYPE_ID=:orgTypeId) THEN 1 ELSE 0 END AS ROLE_LEVEL "
				+ "FROM M_ORG_ROLE orgRole "
				+ "INNER JOIN M_ROLE mRole ON mRole.ROLE_ID=orgRole.ROLE_ID "
				+ "WHERE orgRole.ORG_ID =:orgId AND orgRole.IS_ACTIVE='true' AND orgRole.IS_NODAL='false' ",nativeQuery = true)
		public List<RoleResponse> findOrgRole(Integer orgId, Integer orgTypeId);
		
}
