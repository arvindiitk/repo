package com.ng.org.controller;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.Valid;

import com.ng.org.constants.Constants;
import com.ng.org.entity.Org;
import com.ng.org.entity.OrgCase;
import com.ng.org.entity.OrgPortalRoleMenuMap;
import com.ng.org.entity.OrgRole;
import com.ng.org.entity.Rank;
import com.ng.org.exception.ResourceNotFoundException;
import com.ng.org.request.AddUserNodalOfficerDto;
import com.ng.org.request.MenuMapReqDto;
import com.ng.org.request.OrgCaseReqDto;
import com.ng.org.request.OrgPortalRoleMenuMapDto;
import com.ng.org.request.OrgReqDto;
import com.ng.org.request.OrgRoleDto;
import com.ng.org.request.RankReqDto;
import com.ng.org.response.ApiResponse;
import com.ng.org.response.MenuMappingNodalResDto;
import com.ng.org.response.MenuMappingResDto;
import com.ng.org.response.MenuMappingResFromMapDto;
import com.ng.org.response.OrgCountDTO;
import com.ng.org.response.OrgResDto;
import com.ng.org.response.OrganizationBasicDetailsDto;
import com.ng.org.response.PoOrgConfigDetails;
import com.ng.org.response.RoleResponse;
import com.ng.org.service.OrganizationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@RestController
@Slf4j
@RequestMapping("/ng-org")
@Transactional(timeout = 180)
public class OrganizationController {
	@Autowired
	OrganizationService orgService;

	/**
	 * save Organization details
	 */

	@PostMapping(value = "/org/ng-addOrgBasicDetails", consumes = { "application/json" })
	public ResponseEntity<Object> saveUpdateAddOrgBasicDetails(@RequestBody OrgReqDto orgReqDto,@RequestHeader HttpHeaders headers) {
		log.info("OrganizationController: createOrganization ng-addOrgBasicDetails {}", orgReqDto);
		Org orgReq = orgService.saveOrUpdate(orgReqDto,headers);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.ORGANISATION_BASIC_DETAILS_SUCCESS).data(orgReq).build();
		log.info("OrganizationController: createOrganization ng-addOrgBasicDetails response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/org/ng-addOrgRolePortalDetails", consumes = { "application/json" })
	public ResponseEntity<Object> saveUpdateAddOrgRolePortalDetails(@RequestBody OrgRoleDto orgRoleDto) {
		log.info("OrganizationController: create Role ng-addOrgRoleDetails {}", orgRoleDto);
		List<OrgRole> orgRes = orgService.saveOrUpdate(orgRoleDto);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.HIERARCHY_MANAGEMENT_SUCCESS).data(orgRes).build();
		log.info("OrganizationController: create Role ng-addOrgRoleDetails  response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/org/ng-createMenuMappingRoles", consumes = { "application/json" })
	public ResponseEntity<Object> saveUpdateCreateMenuMappingRoles(
			@RequestBody OrgPortalRoleMenuMapDto mOrgPortalRoleMenuMapDto) {
		log.info("OrganizationController: create  ng-createMenuMappingRoles {}", mOrgPortalRoleMenuMapDto);
		List<OrgPortalRoleMenuMap> orgReq = orgService.saveOrUpdate(mOrgPortalRoleMenuMapDto);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.CREATE_MENU_MAP_SUCCESS).data(orgReq).build();
		log.info("OrganizationController: create  ng-createMenuMappingRoles  response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@GetMapping("/org/ng-getAllActiveOrganizationDetails")
	public ResponseEntity<Object> getAllActiveOrganizationDetails() throws ResourceNotFoundException{
		log.info("OrganizationController :getAllActiveOrganizationDetails {} ");

		List<OrgResDto> filteredList = orgService.findAllActiveOrg().stream().filter(OrgResDto::getIsActive)
				.collect(Collectors.toList());
		
//		if(filteredList.isEmpty()) {
//        	throw new ResourceNotFoundException(Constants.LIST_NOT_FOUND);
//        }

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[OrganizationController.getAllActiveOrganizationDetails] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@GetMapping("/org/ng-getAllOrganizationDetails")
	public ResponseEntity<Object> getAllOrganizationDetails() throws ResourceNotFoundException{
		log.info("OrganizationController :getAllOrganizationDetails {} ");

		List<OrgResDto> filteredList = orgService.findAllActiveOrg().stream().collect(Collectors.toList());
		
//		if(filteredList.isEmpty()) {
//        	throw new ResourceNotFoundException(Constants.LIST_NOT_FOUND);
//        }

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[OrganizationController.getAllOrganizationDetails] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@PostMapping("/org/ng-activateDeactivateOrganization") 
	public ResponseEntity<Object> activateDeactivateOrganization(@RequestBody OrgReqDto orgReqDto) {
		log.info("OrganizationController: ng-activateDeactivateOrganization {}", orgReqDto.toString());
		Integer orgId = orgService.activateDeactivateOrganization(orgReqDto.getOrgId(), orgReqDto.getIsActive(),orgReqDto.getRemarks());
		ApiResponse<?> apiResponse = null;
		if (orgId==1) {
			if(Boolean.TRUE.equals(orgReqDto.getIsActive()))
				apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value())).message(Constants.ORG_ACTIVATE).data(orgReqDto.getOrgId()).build();
			else
				apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value())).message(Constants.ORG_DEACTIVATE).data(orgReqDto.getOrgId()).build();
		}
		log.info("UserController: createUsers ng-activateDeactivateOrganization response {}", apiResponse);
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value="/org/ng-getHierarchyDetailsByOrgId", consumes = { "application/json" })
	public ResponseEntity<Object> getHierarchyDetailsByOrgId(@RequestBody OrgReqDto orgReqDto) throws ResourceNotFoundException {
		log.info("OrganizationController :getHierarchyDetailsByOrgId {} ");

		List<OrgRole> filteredList = orgService.findByOrgId(orgReqDto.getOrgId()).stream().collect(Collectors.toList());
		
//		if(filteredList.isEmpty()) {
//        	throw new ResourceNotFoundException("Hierarchy details for orgId " +orgReqDto.getOrgId()+" "+Constants.NOT_FOUND);
//        }

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[OrganizationController.getHierarchyDetailsByOrgId] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}

	@PostMapping(value="/org/ng-getOrganizationBasicDetailsByOrgId", consumes = { "application/json" })
	public ResponseEntity<Object> getOrganizationBasicDetailsByOrgId(@RequestBody OrgReqDto orgReqDto) throws ResourceNotFoundException	{
		log.info("OrganizationController: in method getOrganizationBasicDetailsByOrgId {}", orgReqDto.getOrgId());
		OrganizationBasicDetailsDto organizationBasicDetailsDto = orgService
				.getOrganizationBasicDetailsByOrgId(orgReqDto.getOrgId());
		
		if(organizationBasicDetailsDto == null) {
        	throw new ResourceNotFoundException("Organization details for orgId "+orgReqDto.getOrgId()+" "+Constants.NOT_FOUND);
        }
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(organizationBasicDetailsDto).build();
		log.info("[OrganizationController.getOrganizationBasicDetailsByOrgId] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value="/org/ng-getMenuMappingByOrgRolePortalId", consumes = { "application/json" })
	public ResponseEntity<Object> getMenuMappingByOrgRolePortalId(@RequestBody List<MenuMapReqDto> reqDto) throws ResourceNotFoundException{
		log.info("OrganizationController: in method getMenuMappingByOrgRolePortalId {}");
		
		List<MenuMappingResDto> finalResDto = orgService.getMenuMappingResponse(reqDto);
		
//		if(finalResDto.isEmpty()) {
//        	throw new ResourceNotFoundException(Constants.LIST_NOT_FOUND);
//        }
		finalResDto = finalResDto.stream().collect(Collectors.toList());
		
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(finalResDto).build();
		log.info("[OrganizationController.getMenuMappingByOrgRolePortalId] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value="/org/ng-getMenuMappingFromMapByOrgRolePortalId",consumes = {"application/json"})
    public ResponseEntity<Object> getMenuMappingFromMapByOrgRolePortalId(@RequestBody List<MenuMapReqDto> reqDto) throws ResourceNotFoundException {
        log.info("OrganizationController: in method getMenuMappingByOrgRolePortalId {}");  
        
        List<MenuMappingResFromMapDto> finalResDto = orgService.getMenuMappingResponseFromMap(reqDto);
        		
//        if(finalResDto.isEmpty()) {
//           throw new ResourceNotFoundException(Constants.LIST_NOT_FOUND);
//          }
        finalResDto = finalResDto.stream()
        		.collect(Collectors.toList());
        
        ApiResponse<?> apiResponse = ApiResponse.builder()
                .status(String.valueOf(HttpStatus.OK.value()))
                .message(Constants.SUCCESS)
                .data(finalResDto)
                .build();
        log.info("[OrganizationController.getMenuMappingByOrgRolePortalId] : success response");
        return ResponseEntity.ok().body(apiResponse);
    }
	
	@PostMapping(value="/org/ng-getMenuMappingForUserCreationByOrgRolePortalId",consumes = {"application/json"})
    public ResponseEntity<Object> getMenuMappingForUserCreationByOrgRolePortalId(@RequestBody List<MenuMapReqDto> reqDto) throws ResourceNotFoundException {
        log.info("OrganizationController: in method getMenuMappingForUserCreationByOrgRolePortalId {}");  
        
        List<MenuMappingResFromMapDto> finalResDto = orgService.getMenuMappingForUserCreationByOrgRolePortalId(reqDto);
        finalResDto = finalResDto.stream()
        		.collect(Collectors.toList());
        
        ApiResponse<?> apiResponse = ApiResponse.builder()
                .status(String.valueOf(HttpStatus.OK.value()))
                .message(Constants.SUCCESS)
                .data(finalResDto)
                .build();
        log.info("[OrganizationController.getMenuMappingForUserCreationByOrgRolePortalId] : success response");
        return ResponseEntity.ok().body(apiResponse);
    }
	
	@GetMapping("/org/ng-getAllRank")
	public ResponseEntity<Object> getAllRank() throws ResourceNotFoundException {
		log.info("OrganizationController :getAllRank {} ");

		List<Rank> filteredList = orgService.findAllRank().stream().filter(Rank::getIsActive)
				.collect(Collectors.toList());
//		if(filteredList.isEmpty()) {
//        	throw new ResourceNotFoundException(Constants.LIST_NOT_FOUND);
//        }

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[OrganizationController.getAllRank] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@PostMapping("/org/ng-getAllRankByRoleId")
	public ResponseEntity<Object> getAllRankByRoleId(@RequestBody RankReqDto rankReqDto) throws ResourceNotFoundException {
		log.info("OrganizationController :getAllRankByRoleId {} ");

		List<Rank> filteredList = orgService.getAllRankByRoleId(rankReqDto.getRoleId()).stream().filter(Rank::getIsActive)
				.collect(Collectors.toList());
//		if(filteredList.isEmpty()) {
//        	throw new ResourceNotFoundException(Constants.LIST_NOT_FOUND);
//        }

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[OrganizationController.getAllRankByRoleId] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@PostMapping(value = "/org/ng-addOrgRankDetails", consumes = { "application/json" })
	public ResponseEntity<Object> addOrgRankDetails(@RequestBody RankReqDto rankReqDto) {
		log.info("OrganizationController: createOrganization ng-addOrgRankDetails {}", rankReqDto);
		Rank rankDetails = orgService.saveOrUpdate(rankReqDto);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SAVE_RANK_DETAILS).data(rankDetails).build();
		log.info("OrganizationController: createOrganization ng-addOrgRankDetails response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/org/ng-getOrgNamebyOrgTypeId", consumes = { "application/json" })
	public ResponseEntity<Object> getOrgNamebyOrgTypeId(@RequestBody OrgReqDto orgReqDto)  throws ResourceNotFoundException  {
		log.info("OrganizationController :getOrgNamebyOrgTypeId {} ");
		List<OrgResDto> filteredList = orgService.findAllActiveOrg().stream()
				.filter(e -> Objects.equals(e.getOrgTypeId(), orgReqDto.getOrgTypeId()) && e.getIsActive().equals(true) )
				.collect(Collectors.toList());
		
		if (orgReqDto.getIsState()!= null && orgReqDto.getIsState().equals(true)) {
			filteredList = filteredList.stream().filter(e -> e.getIsState().equals(true)).collect(Collectors.toList());

		} else if (orgReqDto.getIsState()!= null && orgReqDto.getIsState().equals(false)) {
			filteredList = filteredList.stream().filter(e -> e.getIsState().equals(false)).collect(Collectors.toList());
		}
		
		if(filteredList.isEmpty()) {
        	throw new ResourceNotFoundException("Request list for orgTypeId "+orgReqDto.getOrgTypeId()+" "+Constants.NOT_FOUND);
        }
		
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[OrganizationController.getOrgNamebyOrgTypeId] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@GetMapping(value = "/org/ng-getPoOrgNameByOrgTypeId")
	public ResponseEntity<Object> getPoOrgNamebyOrgTypeId()  throws ResourceNotFoundException  {
		log.info("OrganizationController :getPoOrgNamebyOrgTypeId {} ");
		List<PoOrgConfigDetails> filteredList = orgService.getPoOrgNamebyOrgTypeId().stream().collect(Collectors.toList());
//		if(filteredList.isEmpty()) {
//        	throw new ResourceNotFoundException(Constants.NOT_FOUND);
//        }
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[OrganizationController.getPoOrgNamebyOrgTypeId] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	
	@PostMapping(value = "/org/ng-getOrgForCase", consumes = { "application/json" })
	public ResponseEntity<Object> getOrgForCase(@Valid @RequestBody OrgCaseReqDto req)  throws ResourceNotFoundException  {
		log.info("OrganizationController :getOrgForCase {} ", req.getOrgTypeAlias());
		List<OrgCase> filteredList  = orgService.findOrgForCase(req.getOrgTypeAlias(), req.getUaId());
		
		if(filteredList.isEmpty()) {
        	throw new ResourceNotFoundException("Request list for orgTypeAlias "+req.getOrgTypeAlias()+" "+Constants.NOT_FOUND);
        }
		
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[OrganizationController.getOrgForCase] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@GetMapping("/org/ng-getCountOrganizationEnrolled")
	public ResponseEntity<Object> getCountOrganizationEnrolled() throws ResourceNotFoundException{
		log.info("OrganizationController :getCountOrganizationEnrolled");

		long countOrg = orgService.count();
		
		if(countOrg < 1) {
        	throw new ResourceNotFoundException(Constants.LIST_NOT_FOUND);
        }

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(new OrgCountDTO(countOrg)).build();
		log.info("[OrganizationController.getCountOrganizationEnrolled] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
	
	@PostMapping(value="/org/ng-getUserPortalAndMenuForNodal", consumes = { "application/json" })
	public ResponseEntity<Object> getUserPortalAndMenuForNodal(@RequestBody AddUserNodalOfficerDto reqDto) throws ResourceNotFoundException{
		log.info("OrganizationController: in method getUserPortalAndMenuForNodal {}");
		MenuMappingNodalResDto finalResDto = orgService.getUserPortalAndMenuForNodal(reqDto);
		
		if(finalResDto ==null) {
        	throw new ResourceNotFoundException(Constants.LIST_NOT_FOUND);
        }
			
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(finalResDto).build();
		log.info("[OrganizationController.getUserPortalAndMenuForNodal] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping(value = "/org/ng-getOrgRoleByOrgId", consumes = { "application/json" })
	public ResponseEntity<Object> getOrgRoleByOrgId(@Valid @RequestBody OrgReqDto req)  throws ResourceNotFoundException  {
		log.info("OrganizationController :getOrgForCase {} ", req.getOrgId());
		List<RoleResponse> filteredList  = orgService.findOrgRole(req.getOrgId(), req.getOrgTypeId());
		
		if(filteredList.isEmpty()) {
        	throw new ResourceNotFoundException("Request list for orgId "+req.getOrgId()+" "+Constants.NOT_FOUND);
        }
		
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[OrganizationController.getOrgRoleByOrgId] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}
}
