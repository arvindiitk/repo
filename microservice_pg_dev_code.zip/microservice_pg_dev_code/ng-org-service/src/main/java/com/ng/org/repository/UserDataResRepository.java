package com.ng.org.repository;



import java.util.List;

import com.ng.org.response.UserDetailsResDto;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface UserDataResRepository extends JpaRepository<UserDetailsResDto, Integer> {
   
	@Query(value = "SELECT DISTINCT mUser.USER_ID, mUser.USER_LOGIN_ID, mUser.USER_NAME FROM M_USER mUser "
			+ "INNER JOIN M_USER_ORG userOrg ON userOrg.USER_ID=mUser.USER_ID "
			+ "INNER JOIN M_USER_PORTAL_MAP userPortalMap ON userPortalMap.USER_ORG_MAP_ID=userOrg.USER_ORG_MAP_ID "
			+ "INNER JOIN M_USER_PORTAL_ROLE_MAP userPortalRoleMap ON userPortalRoleMap.USER_PORTAL_MAP_ID=userPortalMap.USER_PORTAL_MAP_ID "
			+ "INNER JOIN M_ORG_PORTAL orgPortal ON orgPortal.ORG_PORTAL_MAP_ID=userPortalMap.ORG_PORTAL_MAP_ID "
			+ "INNER JOIN M_ORG_ROLE orgRole ON orgRole.ORG_ID = userOrg.ORG_ID AND orgRole.ROLE_ID= userPortalRoleMap.ROLE_ID "
			+ "WHERE orgRole.ORG_ID=:orgId AND orgRole.ROLE_ID=:roleId AND orgRole.IS_ACTIVE='true' AND mUser.IS_ACTIVE='true' ",nativeQuery = true)
	public List<UserDetailsResDto> getUserDetails(Integer orgId, Integer roleId);
}
