package com.ng.org.response;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class OrganizationBasicDetailsDto implements Serializable {
	
	private static final long serialVersionUID = 1L;
    
	@Id
	@Column(name = "ORG_ID")
	private Integer orgId;
	
	@Column(name = "ORG_NAME")
	private String orgName;
	
	@Column(name = "ORG_ALIAS")
	private String orgAlias;
	
	@Column(name = "ORG_TYPE_ID")
	private Short orgTypeId;
	
	@Column(name = "ORG_ADDR")
	private String orgAddr;
	
	@Column(name = "ORG_CONTACT_NO")
	private BigInteger contactNo;
	
	@Column(name = "ORG_PORTAL_MAP_ID")
	private String orgPortalMapId;	
	
	@Column(name = "IS_STATE")
	private Boolean isState;
	
	@OneToMany(mappedBy="portalId", fetch=FetchType.LAZY,cascade={CascadeType.ALL})
	private List<PortalDetails> portalDetails;
}
