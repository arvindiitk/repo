package com.ng.org.repository;



import com.ng.org.response.PortalResponse;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface OrgPortalRepository extends JpaRepository<PortalResponse, Integer> {
   

		@Query(value= "SELECT DISTINCT portalMenu.PORTAL_ID, portal.PORTAL_NAME FROM M_ORG_ROLE orgRole "
				+ "INNER JOIN M_ORG_ROLE_PORTAL orgRolePortal ON orgRolePortal.ORG_ROLE_MAP_ID=orgRole.ORG_ROLE_MAP_ID AND orgRolePortal.IS_ACTIVE='true' "
				+ "INNER JOIN M_PORTAL_MENU portalMenu ON portalMenu.PORTAL_ID=orgRolePortal.PORTAL_ID "
				+ "INNER JOIN M_PORTAL portal ON portal.PORTAL_ID=orgRolePortal.PORTAL_ID "
				+ "INNER JOIN M_ROLE mRole ON mRole.ROLE_ID=orgRole.ROLE_ID "
				+ "WHERE orgRole.ORG_ROLE_MAP_ID =:roleMapId AND portalMenu.PORTAL_ID =:portalId AND orgRole.IS_ACTIVE='true' ",nativeQuery = true)
		public PortalResponse getRolePortalId(Integer roleMapId, Integer portalId);
}
