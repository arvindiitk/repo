package  com.ng.org.response;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class RankDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	@Id
	private Integer rankId;
	private String rankName;
	private String rankDescription;
}
