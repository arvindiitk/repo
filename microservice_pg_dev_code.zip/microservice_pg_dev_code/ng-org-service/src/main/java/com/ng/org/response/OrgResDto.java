package com.ng.org.response;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.org.constants.Constants;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;


@NoArgsConstructor
@Getter
@ToString
@Entity
public class OrgResDto implements Serializable {
    private static final long serialVersionUID = -9186227101883480430L;
    
    @Id
	@Column(name = "ORG_ID")
	private Integer orgId;

	@Column(name = "ORG_TYPE_ID")
	private Integer orgTypeId;
	
	@Column(name = "ORG_NAME")
	private String orgName;
	
	@Column(name = "ORG_ALIAS")
	private String orgAlias;
	
	@Column(name = "ORG_ADDR")
	private String orgAddr;
	
	@Column(name = "ORG_CONTACT_NO")
	private Long orgContactNo;
	
	@Column(name = "CREATED_BY")
	private Integer createdBy;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	@Column(name = "CREATED_ON")
	private Timestamp createdOn;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;	

	@Column(name = "Remarks")
	private String remarks;
	
	@Column(name = "ORG_TYPE_ALIAS")
	private String orgTypeAlias;
	
	@Column(name = "ORG_TYPE_NAME")
	private String orgTypeName;
	
	@Column(name = "USER_NAME")
	private String createdByName;
	
	@Column(name = "IS_STATE")
	private Boolean isState;
	
	@Column(name = "ORG_PASSCODE")
	private String orgPasscode;
}
