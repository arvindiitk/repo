package  com.ng.org.response;

import java.io.Serializable;
import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@Getter
@Setter
@ToString
public class MenuMappingNodalResDto implements Serializable {

	private static final long serialVersionUID = 1L;
    
	private List<RankDetails> rankList;
	private List<PortalNodalResDto> portalList;
	private List<ReportsToUserRes> userList;
}
