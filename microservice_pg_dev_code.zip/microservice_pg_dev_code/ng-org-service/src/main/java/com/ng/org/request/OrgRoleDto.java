package com.ng.org.request;

import java.util.List;

import com.ng.org.entity.OrgRole;

import lombok.Data;

@Data
public class OrgRoleDto {
	
	
	private List<OrgRole> orgRoleList;

}
