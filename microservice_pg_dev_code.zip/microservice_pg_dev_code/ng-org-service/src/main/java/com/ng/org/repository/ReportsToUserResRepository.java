package com.ng.org.repository;



import java.util.List;

import com.ng.org.response.ReportsToUserRes;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface ReportsToUserResRepository extends JpaRepository<ReportsToUserRes, Integer> {
   
	@Query(value = "SELECT mRole.ROLE_ID, mRole.ROLE_NAME FROM M_ROLE mRole "
			+ "INNER JOIN M_ORG_ROLE orgRole ON orgRole.ROLE_ID = mRole.ROLE_ID "
			+ "INNER JOIN (SELECT mRole.ROLE_LEVEL, mRole.ORG_TYPE_ID FROM M_ORG_ROLE orgRole INNER JOIN M_ROLE mRole ON mRole.ROLE_ID=orgRole.ROLE_ID  "
			+ "WHERE orgRole.ORG_ID=:orgId AND mRole.ROLE_LEVEL < (SELECT mRole.ROLE_LEVEL FROM M_ORG_ROLE orgRole "
			+ "INNER JOIN M_ROLE mRole ON mRole.ROLE_ID=orgRole.ROLE_ID "
			+ "WHERE orgRole.ORG_ID=:orgId AND orgRole.ROLE_ID=:roleId )) joiningTable ON joiningTable.ROLE_LEVEL=mRole.ROLE_LEVEL "
			+ "AND joiningTable.ORG_TYPE_ID=mRole.ORG_TYPE_ID "
			+ "WHERE orgRole.ORG_ID=:orgId AND orgRole.IS_ACTIVE='true' ORDER BY mRole.ROLE_ID ASC ",nativeQuery = true)
	public List<ReportsToUserRes> findUserDetailsByRoleAndOrgId(Integer roleId,Integer orgId);
}
