package com.ng.org.response;

import java.io.Serializable;
import java.util.List;

import com.ng.org.entity.OrgRole;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;


@NoArgsConstructor
@Getter
@ToString
public class OrgRoleResponse implements Serializable {
    private static final long serialVersionUID = -9186227101883480430L;
	private List<OrgRole> orgRole;
}
