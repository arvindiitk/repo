package com.ng.org.repository;



import com.ng.org.response.OrganizationBasicDetailsDto;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface OrgBasicDetRepository extends JpaRepository<OrganizationBasicDetailsDto, Integer> {
   

	@Query(value= "SELECT org.ORG_ID, org.ORG_NAME, org.ORG_ALIAS, org.ORG_TYPE_ID, org.ORG_ADDR, org.ORG_CONTACT_NO, "
			+ " string_agg(CAST(orgPortal.ORG_PORTAL_MAP_ID as varchar),',') as ORG_PORTAL_MAP_ID,org.IS_STATE "
			+ " FROM M_ORG org "
			+ " LEFT JOIN M_ORG_PORTAL orgPortal on orgPortal.ORG_ID=org.ORG_ID where org.ORG_ID =:id "
			+ " GROUP BY org.ORG_ID, org.ORG_NAME, org.ORG_ALIAS, org.ORG_TYPE_ID, org.ORG_ADDR, org.ORG_CONTACT_NO ",nativeQuery = true)
		public OrganizationBasicDetailsDto getOrganizationBasicDetailsByOrgId(Integer id);

}
