package com.ng.org.request;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Valid
public class OrgCaseReqDto implements Serializable {
	private static final long serialVersionUID = 1L;

	@NotEmpty(message = "Org Type Alias cannot be null")
	private String orgTypeAlias;
	
	private Integer uaId;
}
