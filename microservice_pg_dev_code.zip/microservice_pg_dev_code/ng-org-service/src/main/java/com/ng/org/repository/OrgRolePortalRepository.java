package com.ng.org.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ng.org.entity.OrgRole;

@Repository
public interface OrgRolePortalRepository extends JpaRepository<OrgRole, Integer>{
	
	public List<OrgRole> findByOrgIdOrderByRoleIdAsc(Integer orgId);
	
	@Transactional
    @Modifying
	@Query(value = "update ng_cmp.m_user set IS_ACTIVE='false' where user_id in "
			+ "(select userOrgMap.user_id from  ng_cmp.m_user_portal_role_map usrPortRoleMap "
			+ "inner join ng_cmp.m_user_portal_map usrPortMap ON usrPortMap.user_portal_map_id=usrPortRoleMap.user_portal_map_id "
			+ "inner join ng_cmp.m_user_org userOrgMap ON usrPortMap.user_org_map_id=userOrgMap.user_org_map_id "
			+ "inner join ng_cmp.m_org_portal orgPortMap ON orgPortMap.org_portal_map_id = usrPortMap.org_portal_map_id "
			+ "inner join ng_cmp.m_org_role orgRole ON orgRole.org_id = userOrgMap.org_id AND orgRole.ROLE_ID = usrPortRoleMap.ROLE_ID "
			+ "AND orgRole.IS_ACTIVE='false' "
			+ "where orgRole.org_id=:orgId) ", nativeQuery = true)
	void deactiveUserOnRemovedRoles(Integer orgId);
	
	@Transactional
    @Modifying
	@Query(value = "update ng_cmp.m_user_reporting set IS_ACTIVE='false' where user_reporting_user_id in "
			+ "(select userOrgMap.user_id from  ng_cmp.m_user_portal_role_map usrPortRoleMap "
			+ "inner join ng_cmp.m_user_portal_map usrPortMap ON usrPortMap.user_portal_map_id=usrPortRoleMap.user_portal_map_id "
			+ "inner join ng_cmp.m_user_org userOrgMap ON usrPortMap.user_org_map_id=userOrgMap.user_org_map_id "
			+ "inner join ng_cmp.m_org_portal orgPortMap ON orgPortMap.org_portal_map_id = usrPortMap.org_portal_map_id "
			+ "inner join ng_cmp.m_org_role orgRole ON orgRole.org_id = userOrgMap.org_id AND orgRole.ROLE_ID = usrPortRoleMap.ROLE_ID "
			+ "AND orgRole.IS_ACTIVE='false' "
			+ "where orgRole.org_id=:orgId) ", nativeQuery = true)
	void deleteUserReportingOnRemovedRoles(Integer orgId);

}



