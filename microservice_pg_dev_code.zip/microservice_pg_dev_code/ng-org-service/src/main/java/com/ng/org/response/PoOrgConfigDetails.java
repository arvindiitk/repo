package com.ng.org.response;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Data
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class PoOrgConfigDetails implements Serializable {
    private static final long serialVersionUID = -9186227101883480430L;
    
    @Id
    @Column(name = "API_ID")
	private Integer apiId;
    
    @Column(name = "ORG_ID")
	private Integer orgId;
    
    @Column(name = "ORG_NAME")
	private String orgName;
    
    @Column(name = "ORG_ALIAS")
	private String orgAlias;
    


}
