package com.ng.org.repository;



import java.util.List;

import com.ng.org.response.PortalDetails;
import com.ng.org.response.RankDetails;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface PortalMenuDetailsRepository extends JpaRepository<PortalDetails, Integer> {
   
	@Query(value = "select portal.PORTAL_ID,portal.PORTAL_NAME from M_ORG_ROLE_PORTAL mOrgRolePortal "
			+ "INNER JOIN M_PORTAL portal on mOrgRolePortal.PORTAL_ID=portal.PORTAL_ID "
			+ "where ORG_ROLE_MAP_ID IN (select DISTINCT ORG_ROLE_MAP_ID from M_ORG_ROLE orgRole where orgRole.ROLE_ID=:roleId AND orgRole.ORG_ID=:orgId) "
			+ "AND portal.IS_ACTIVE='true' ;",nativeQuery = true)
	public List<RankDetails> findRankDetailsByRoleAndOrgId(Integer roleId,Integer orgId);
}
