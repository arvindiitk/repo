package com.ng.org.service;

import java.util.List;

import com.ng.org.entity.Org;
import com.ng.org.entity.OrgCase;
import com.ng.org.entity.OrgPortalRoleMenuMap;
import com.ng.org.entity.OrgRole;
import com.ng.org.entity.Rank;
import com.ng.org.request.AddUserNodalOfficerDto;
import com.ng.org.request.MenuMapReqDto;
import com.ng.org.request.OrgPortalRoleMenuMapDto;
import com.ng.org.request.OrgReqDto;
import com.ng.org.request.OrgRoleDto;
import com.ng.org.request.RankReqDto;
import com.ng.org.response.MenuMappingNodalResDto;
import com.ng.org.response.MenuMappingResDto;
import com.ng.org.response.MenuMappingResFromMapDto;
import com.ng.org.response.OrgResDto;
import com.ng.org.response.OrganizationBasicDetailsDto;
import com.ng.org.response.PoOrgConfigDetails;
import com.ng.org.response.RoleResponse;

import org.springframework.http.HttpHeaders;


public interface OrganizationService {
   
    public Org saveOrUpdate(OrgReqDto organization, HttpHeaders headers);
    public List<OrgRole> saveOrUpdate(OrgRoleDto orgRoleDto);
    public List<OrgPortalRoleMenuMap> saveOrUpdate(OrgPortalRoleMenuMapDto mOrgPortalRoleMenuMapDto);    
    public List<OrgResDto> findAllActiveOrg();
    public List<OrgRole> findByOrgId(Integer orgId);
    public OrganizationBasicDetailsDto getOrganizationBasicDetailsByOrgId(Integer id);
    public List<Rank> findAllRank();
    public Rank saveOrUpdate(RankReqDto rank);
	public List<MenuMappingResDto> getMenuMappingResponse(List<MenuMapReqDto> reqDto);
	public List<MenuMappingResFromMapDto> getMenuMappingResponseFromMap(List<MenuMapReqDto> reqDto);
	public List<OrgCase> findOrgForCase(String orgTypeAlias,Integer uaId);
	public long count();
	public List<Rank> getAllRankByRoleId(Integer roleId);
	public Integer activateDeactivateOrganization(Integer orgId, Boolean isActive,String remarks);
	public MenuMappingNodalResDto getUserPortalAndMenuForNodal(AddUserNodalOfficerDto reqDto);
	public List<RoleResponse> findOrgRole(Integer orgId, Integer orgTypeId);
	public List<PoOrgConfigDetails> getPoOrgNamebyOrgTypeId();
	public List<MenuMappingResFromMapDto> getMenuMappingForUserCreationByOrgRolePortalId(List<MenuMapReqDto> reqDto);
}
