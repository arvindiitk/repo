package com.ng.org.repository;



import java.util.List;

import com.ng.org.response.PortalDetails;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface OrgPortalDetailsRepository extends JpaRepository<PortalDetails, Integer> {
   

		@Query(value= "SELECT orgPortal.ORG_PORTAL_MAP_ID,orgPortal.PORTAL_ID,orgPortal.IS_ACTIVE "
				+ " FROM M_ORG org "
				+ " LEFT JOIN M_ORG_PORTAL orgPortal on orgPortal.ORG_ID=org.ORG_ID where org.ORG_ID =:id ",nativeQuery = true)
		public List<PortalDetails> getOrganizationPortalByOrgId(Integer id);

}
