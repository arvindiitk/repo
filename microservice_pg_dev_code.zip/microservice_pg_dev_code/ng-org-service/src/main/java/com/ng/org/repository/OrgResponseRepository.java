package com.ng.org.repository;



import java.util.List;

import com.ng.org.response.OrgResDto;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface OrgResponseRepository extends JpaRepository<OrgResDto, Integer> {
   
	@Query (value = "SELECT org.ORG_ID, org.ORG_TYPE_ID, org.ORG_NAME, org.ORG_ALIAS, org.ORG_ADDR, org.ORG_CONTACT_NO, "
			+ "org.CREATED_BY, org.CREATED_ON, org.IS_ACTIVE, org.Remarks, orgType.ORG_TYPE_ALIAS, orgType.ORG_TYPE_NAME, mUser.USER_NAME,org.is_state,org.ORG_PASSCODE "
			+ "FROM M_ORG org "
			+ "INNER JOIN M_ORG_TYPE orgType ON org.ORG_TYPE_ID=orgType.ORG_TYPE_ID "
			+ "INNER JOIN M_USER mUser ON mUser.USER_ID=org.CREATED_BY "
			+ "ORDER BY org.CREATED_ON DESC ", nativeQuery =true)
	public List<OrgResDto> findAllActiveOrg();
}
