package  com.ng.org.response;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class PortalDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	@Id
	@Column(name = "ORG_PORTAL_MAP_ID")
	private Integer orgPortalMapId;
	
	@Column(name = "PORTAL_ID")
	private Integer portalId;
	
	@Column(name = "IS_ACTIVE")
	private Boolean isActive;
}
