package com.ng.org.repository;

import com.ng.org.entity.OrgPortalRoleMenuMap;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrgPortalRoleMenuMapRepository extends JpaRepository<OrgPortalRoleMenuMap, Integer>{

}
