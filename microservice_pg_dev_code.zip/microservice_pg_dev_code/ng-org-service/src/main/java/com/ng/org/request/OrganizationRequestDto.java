package com.ng.org.request;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter

public class OrganizationRequestDto implements Serializable {
    private static final long serialVersionUID = -993948671188135922L;
    private Integer orgId;
    private String orgsName;
    private String alias;
    private Integer orgTypesId;
    private String address;
    private Integer contactNumber;
    private String isActive;
    private String recordCreatedDate;
    private String recordCreatedBy;
    private Integer orgRoleMapId;
    private Integer portalId;  
    
    private transient List<AddOrgBasicPortalTypeDto> portalList;
}
