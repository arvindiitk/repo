package com.ng.org.repository;



import java.util.List;

import com.ng.org.response.MenuResponse;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface OrgMenuRepository extends JpaRepository<MenuResponse, Integer> {
   

		@Query(value= "SELECT orgRolePortal.ORG_ROLE_PORTAL_ID, portalMenu.PORTAL_MENU_ID, mMenu.MENU_SEQ, mMenu.MENU_ID,mMenu.MENU_NAME, mMenu.PARENT_MENU_ID, "
				+ "portalMenu.MENU_ACCESS_READ, portalMenu.MENU_ACCESS_WRITE, portalMenu.MENU_ACCESS_APPROVE, portalMenu.MENU_ACCESS_RECOMMEND, "
				+ "portalMenu.IS_ACTIVE from M_ORG_ROLE_PORTAL orgRolePortal "
				+ "INNER JOIN M_ORG_ROLE orgRole on orgRolePortal.ORG_ROLE_MAP_ID=orgRole.ORG_ROLE_MAP_ID AND orgRole.IS_ACTIVE='true' "
				+ "INNER JOIN M_PORTAL_MENU portalMenu on portalMenu.PORTAL_ID=orgRolePortal.PORTAL_ID AND portalMenu.IS_ACTIVE='true' "
				+ "INNER JOIN M_MENU mMenu on mMenu.MENU_ID=portalMenu.MENU_ID "
				+ "WHERE orgRole.ORG_ROLE_MAP_ID =:roleMapId AND orgRolePortal.IS_ACTIVE='true' AND portalMenu.PORTAL_ID =:portalId ORDER BY mMenu.MENU_SEQ ASC ",nativeQuery = true)
		public List<MenuResponse> getMenuMappingByOrgRolePortalId(Integer roleMapId, Integer portalId);
}
