package  com.ng.org.response;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class PortalResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "PORTAL_ID")
	private Integer portalId;
	
	@Column(name = "PORTAL_NAME")
	private String portalName;
}
