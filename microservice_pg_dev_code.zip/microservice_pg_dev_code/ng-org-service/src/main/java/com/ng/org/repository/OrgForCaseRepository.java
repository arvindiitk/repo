package com.ng.org.repository;



import java.util.List;

import com.ng.org.entity.OrgCase;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface OrgForCaseRepository extends JpaRepository<OrgCase, Integer> {
   

	@Query(value = "select Distinct org.ORG_ID,org.ORG_NAME from M_ORG org "
			+ "inner Join M_USE_CASE useCase on (org.ORG_ID=useCase.ORG_ID_PO) "
			+ "inner Join M_USE_CASE_CONFIG useCaseConf on (useCase.USE_CASE_ID=useCaseConf.USE_CASE_ID) "
			+ "INNER JOIN M_ORG_TYPE orgType on (org.ORG_TYPE_ID=orgType.ORG_TYPE_ID) "
			+ "where orgType.ORG_TYPE_ALIAS=:orgTypeAlias and org.IS_ACTIVE=useCase.IS_ACTIVE "
			+ "and org.IS_ACTIVE='true' and useCaseConf.ORG_ID_UA=:uaId ORDER BY org.ORG_NAME ASC ", nativeQuery = true)
	public List<OrgCase> findOrgForCase(String orgTypeAlias, Integer uaId);
}
