package com.ng.org.request;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.validation.Valid;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Valid
public class RankReqDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer rankId;
	private Integer createdBy;
	private Timestamp createdOn;
	private Boolean isActive;
	private String rankDesc;
	private String rankName;
	private Integer roleId;
}
