package com.ng.org.repository;



import java.util.List;

import com.ng.org.response.PoOrgConfigDetails;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface PoOrgDetailsRepository extends JpaRepository<PoOrgConfigDetails, Integer> {
   
	@Query (value = "SELECT DISTINCT org.ORG_ID,org.ORG_NAME,org.ORG_ALIAS,poApiSumm.API_ID FROM M_ORG org "
			+ "INNER JOIN M_PO_API_SUMMARY poApiSumm ON (org.ORG_ID=poApiSumm.ORG_ID_PO AND poApiSumm.IS_ACTIVE='true') "
			+ "INNER JOIN M_PO_API_CONFIG poApiConfig ON (poApiConfig.API_ID=poApiSumm.API_ID AND poApiConfig.IS_ACTIVE='true') "
			+ "WHERE org.IS_ACTIVE='true' ", nativeQuery = true)
	public List<PoOrgConfigDetails> getPoOrgNamebyOrgTypeId();
}
