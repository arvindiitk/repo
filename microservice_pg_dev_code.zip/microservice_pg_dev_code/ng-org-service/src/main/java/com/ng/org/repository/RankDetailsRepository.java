package com.ng.org.repository;



import java.util.List;

import com.ng.org.response.RankDetails;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface RankDetailsRepository extends JpaRepository<RankDetails, Integer> {
   
	@Query(value = "SELECT mRank.RANK_ID,mRank.RANK_DESCRIPTION,mRank.RANK_NAME FROM M_RANK mRank WHERE CAST(RANK_ID as varchar) IN "
			+ "(SELECT * FROM  unnest(string_to_array((SELECT orgRole.ROLE_RANK_NAME FROM M_ORG_ROLE orgRole "
			+ "WHERE orgRole.ROLE_ID=:roleId AND orgRole.ORG_ID=:orgId),','))) ",nativeQuery = true)
	public List<RankDetails> findRankDetailsByRoleAndOrgId(Integer roleId,Integer orgId);
}
