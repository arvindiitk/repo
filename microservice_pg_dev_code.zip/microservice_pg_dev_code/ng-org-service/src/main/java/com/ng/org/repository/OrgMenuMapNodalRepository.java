package com.ng.org.repository;

import java.util.List;

import com.ng.org.response.OrgRolePortalResDto;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgMenuMapNodalRepository extends JpaRepository<OrgRolePortalResDto, Integer>{
	
	@Query(value= "SELECT portal.PORTAL_ID, portal.PORTAL_NAME, mOrgRolePortal.ORG_ROLE_MAP_ID, orgPortal.ORG_PORTAL_MAP_ID "
			+ "FROM M_ORG_ROLE_PORTAL mOrgRolePortal "
			+ "INNER JOIN M_ORG_ROLE orgRole ON mOrgRolePortal.ORG_ROLE_MAP_ID=orgRole.ORG_ROLE_MAP_ID "
			+ "INNER JOIN M_PORTAL portal on mOrgRolePortal.PORTAL_ID=portal.PORTAL_ID "
			+ "INNER JOIN M_ORG_PORTAL orgPortal ON orgRole.ORG_ID=orgPortal.ORG_ID AND orgPortal.PORTAL_ID=mOrgRolePortal.PORTAL_ID "
			+ "WHERE orgRole.ROLE_ID=:roleId AND orgRole.ORG_ID=:orgId AND portal.IS_ACTIVE='true' AND orgRole.IS_ACTIVE='true' "
			+ "AND mOrgRolePortal.IS_ACTIVE='true' AND orgPortal.IS_ACTIVE='true' ",nativeQuery = true)
    public List<OrgRolePortalResDto> getMenuMappingFromMapByOrgRolePortalId(Integer roleId, Integer orgId);
}



