package com.ng.org.request;

import java.util.List;

import com.ng.org.entity.OrgPortalRoleMenuMap;

import lombok.Data;


@Data
public class OrgPortalRoleMenuMapDto {
	
	private List<OrgPortalRoleMenuMap> orgPortalRoleMenuList;

}
