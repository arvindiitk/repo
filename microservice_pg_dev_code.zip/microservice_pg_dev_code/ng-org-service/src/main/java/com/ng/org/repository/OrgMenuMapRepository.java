package com.ng.org.repository;

import java.util.List;

import com.ng.org.response.MenuResponseFromMap;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgMenuMapRepository extends JpaRepository<MenuResponseFromMap, Integer>{
	
	@Query(value= "SELECT * FROM (SELECT DISTINCT map.ORG_PORTAL_ROLE_MENU_MAP_ID, orgRolePortal.ORG_ROLE_PORTAL_ID, portalMenu.PORTAL_MENU_ID, mMenu.MENU_SEQ, "
			+ "mMenu.MENU_ID, mMenu.MENU_NAME, mMenu.PARENT_MENU_ID, map.MENU_ACCESS_READ, map.MENU_ACCESS_WRITE, map.MENU_ACCESS_APPROVE, map.MENU_ACCESS_RECOMMEND, "
			+ "map.IS_ACTIVE "
			+ "FROM M_ORG_ROLE_PORTAL orgRolePortal "
			+ "INNER JOIN M_ORG_PORTAL_ROLE_MENU_MAP map ON orgRolePortal.ORG_ROLE_PORTAL_ID=map.ORG_ROLE_PORTAL_ID "
			+ "INNER JOIN M_ORG_ROLE orgRole ON orgRolePortal.ORG_ROLE_MAP_ID=orgRole.ORG_ROLE_MAP_ID AND orgRole.IS_ACTIVE='true' "
			+ "INNER JOIN M_PORTAL_MENU portalMenu ON portalMenu.PORTAL_MENU_ID=map.PORTAL_MENU_ID AND portalMenu.IS_ACTIVE='true' "
			+ "INNER JOIN M_MENU mMenu ON mMenu.MENU_ID=portalMenu.MENU_ID "
			+ "WHERE orgRole.ORG_ROLE_MAP_ID =:roleMapId AND orgRolePortal.PORTAL_ID =:portalId AND orgRolePortal.IS_ACTIVE='true' "
			+ "UNION ALL "
			+ "SELECT DISTINCT CAST(NULL as INTEGER) as ORG_PORTAL_ROLE_MENU_MAP_ID, orgRolePortal.ORG_ROLE_PORTAL_ID, portalMenu.PORTAL_MENU_ID, mMenu.MENU_SEQ, "
			+ "mMenu.MENU_ID, mMenu.MENU_NAME, mMenu.PARENT_MENU_ID, portalMenu.MENU_ACCESS_READ, portalMenu.MENU_ACCESS_WRITE, portalMenu.MENU_ACCESS_APPROVE, "
			+ "portalMenu.MENU_ACCESS_RECOMMEND, portalMenu.IS_ACTIVE "
			+ "FROM M_ORG_ROLE_PORTAL orgRolePortal "
			+ "INNER JOIN M_ORG_ROLE orgRole ON orgRolePortal.ORG_ROLE_MAP_ID=orgRole.ORG_ROLE_MAP_ID AND orgRole.IS_ACTIVE='true' "
			+ "INNER JOIN M_PORTAL_MENU portalMenu ON portalMenu.PORTAL_ID=orgRolePortal.PORTAL_ID AND portalMenu.IS_ACTIVE='true' "
			+ "INNER JOIN M_MENU mMenu ON mMenu.MENU_ID=portalMenu.MENU_ID "
			+ "WHERE orgRole.ORG_ROLE_MAP_ID =:roleMapId AND orgRolePortal.PORTAL_ID =:portalId AND orgRolePortal.IS_ACTIVE='true' "
			+ "AND portalMenu.PORTAL_MENU_ID NOT IN (SELECT DISTINCT portalMenu.PORTAL_MENU_ID FROM ng_cmp.M_ORG_ROLE_PORTAL orgRolePortal "
			+ "INNER JOIN ng_cmp.M_ORG_PORTAL_ROLE_MENU_MAP map ON orgRolePortal.ORG_ROLE_PORTAL_ID=map.ORG_ROLE_PORTAL_ID "
			+ "INNER JOIN ng_cmp.M_ORG_ROLE orgRole ON orgRolePortal.ORG_ROLE_MAP_ID=orgRole.ORG_ROLE_MAP_ID AND orgRole.IS_ACTIVE='true' "
			+ "INNER JOIN ng_cmp.M_PORTAL_MENU portalMenu ON portalMenu.PORTAL_MENU_ID=map.PORTAL_MENU_ID AND portalMenu.IS_ACTIVE='true' "
			+ "INNER JOIN ng_cmp.M_MENU mMenu ON mMenu.MENU_ID=portalMenu.MENU_ID WHERE orgRole.ORG_ROLE_MAP_ID =:roleMapId AND orgRolePortal.PORTAL_ID =:portalId "
			+ "AND orgRolePortal.IS_ACTIVE='true')) mainTable ORDER BY mainTable.MENU_SEQ ASC " ,nativeQuery = true)
    public List<MenuResponseFromMap> getMenuMappingFromMapByOrgRolePortalId(Integer roleMapId, Integer portalId);

	@Query(value= "SELECT DISTINCT map.ORG_PORTAL_ROLE_MENU_MAP_ID, orgRolePortal.ORG_ROLE_PORTAL_ID, portalMenu.PORTAL_MENU_ID, mMenu.MENU_SEQ, "
			+ "mMenu.MENU_ID, mMenu.MENU_NAME, mMenu.PARENT_MENU_ID, map.MENU_ACCESS_READ, map.MENU_ACCESS_WRITE, map.MENU_ACCESS_APPROVE, map.MENU_ACCESS_RECOMMEND, "
			+ "map.IS_ACTIVE "
			+ "FROM M_ORG_ROLE_PORTAL orgRolePortal "
			+ "INNER JOIN M_ORG_PORTAL_ROLE_MENU_MAP map ON orgRolePortal.ORG_ROLE_PORTAL_ID=map.ORG_ROLE_PORTAL_ID AND map.IS_ACTIVE='true' "
			+ "INNER JOIN M_ORG_ROLE orgRole ON orgRolePortal.ORG_ROLE_MAP_ID=orgRole.ORG_ROLE_MAP_ID AND orgRole.IS_ACTIVE='true' "
			+ "INNER JOIN M_PORTAL_MENU portalMenu ON portalMenu.PORTAL_MENU_ID=map.PORTAL_MENU_ID AND portalMenu.IS_ACTIVE='true' "
			+ "INNER JOIN M_MENU mMenu ON mMenu.MENU_ID=portalMenu.MENU_ID "
			+ "WHERE orgRole.ORG_ROLE_MAP_ID =:roleMapId AND orgRolePortal.PORTAL_ID =:portalId AND orgRolePortal.IS_ACTIVE='true' ORDER BY mMenu.MENU_SEQ ASC ",nativeQuery = true)
	public List<MenuResponseFromMap> getMenuMappingForUserCreationByOrgRolePortalId(Integer roleMapId, Integer portalId);
}



