package com.ng.org.request;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import com.ng.org.entity.OrgPortal;
import com.ng.org.entity.OrgRole;
import com.ng.org.entity.OrgType;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
public class OrgReqDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer orgId;
	private Integer createdBy;
	private Integer orgTypeId;
	private Timestamp createdOn;
	private Boolean isActive;
	private Boolean isState;
	private String orgAddr;
	private String orgAlias;
	private Long orgContactNo;
	private String orgName;
	private OrgType orgType;
	private List<OrgPortal> orgPortals;
	private List<OrgRole> orgRoles;
	private String remarks;
}
