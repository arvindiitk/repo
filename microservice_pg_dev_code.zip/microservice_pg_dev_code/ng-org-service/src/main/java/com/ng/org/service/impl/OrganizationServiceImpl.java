package com.ng.org.service.impl;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import com.ng.org.entity.Org;
import com.ng.org.entity.OrgCase;
import com.ng.org.entity.OrgPortalRoleMenuMap;
import com.ng.org.entity.OrgRole;
import com.ng.org.entity.Rank;
import com.ng.org.repository.OrgBasicDetRepository;
import com.ng.org.repository.OrgForCaseRepository;
import com.ng.org.repository.OrgMenuMapNodalRepository;
import com.ng.org.repository.OrgMenuMapRepository;
import com.ng.org.repository.OrgMenuRepository;
import com.ng.org.repository.OrgPortalDetailsRepository;
import com.ng.org.repository.OrgPortalRepository;
import com.ng.org.repository.OrgPortalRoleMenuMapRepository;
import com.ng.org.repository.OrgRepository;
import com.ng.org.repository.OrgResponseRepository;
import com.ng.org.repository.OrgRolePortalRepository;
import com.ng.org.repository.OrgRoleRepository;
import com.ng.org.repository.PoOrgDetailsRepository;
import com.ng.org.repository.RankDetailsRepository;
import com.ng.org.repository.RankRepository;
import com.ng.org.repository.ReportsToUserResRepository;
import com.ng.org.repository.UserDataResRepository;
import com.ng.org.repository.UserRepository;
import com.ng.org.request.AddUserNodalOfficerDto;
import com.ng.org.request.MenuMapReqDto;
import com.ng.org.request.OrgPortalRoleMenuMapDto;
import com.ng.org.request.OrgReqDto;
import com.ng.org.request.OrgRoleDto;
import com.ng.org.request.PortalReqDto;
import com.ng.org.request.RankReqDto;
import com.ng.org.request.UserKeyRequestDto;
import com.ng.org.response.ApiResponse;
import com.ng.org.response.MenuMappingNodalResDto;
import com.ng.org.response.MenuMappingResDto;
import com.ng.org.response.MenuMappingResFromMapDto;
import com.ng.org.response.MenuResponse;
import com.ng.org.response.MenuResponseFromMap;
import com.ng.org.response.OrgResDto;
import com.ng.org.response.OrgRolePortalResDto;
import com.ng.org.response.OrganizationBasicDetailsDto;
import com.ng.org.response.PoOrgConfigDetails;
import com.ng.org.response.PortalDetails;
import com.ng.org.response.PortalNodalResDto;
import com.ng.org.response.PortalResDto;
import com.ng.org.response.PortalResFromMapDto;
import com.ng.org.response.PortalResponse;
import com.ng.org.response.RankDetails;
import com.ng.org.response.ReportsToUserRes;
import com.ng.org.response.RoleResponse;
import com.ng.org.response.UserDetailsResDto;
import com.ng.org.service.OrganizationService;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@PropertySource("classpath:/messages/business/uri.properties")
@Service
@Transactional
public class OrganizationServiceImpl implements OrganizationService {
    @Autowired
    private OrgRepository orgRepository;
    
    @Autowired
    private OrgResponseRepository orgResponseRepository;
    
    @Autowired
    private OrgRolePortalRepository orgRoleRepository;
  
    @Autowired
    private OrgPortalRoleMenuMapRepository orgPortalRoleMenuMapRepository;
    
    @Autowired
    private OrgMenuRepository orgMenuRepo;
    
    @Autowired
    private OrgMenuMapRepository orgMenuMapRepo;
    
    @Autowired
    private OrgPortalRepository orgPortalRepo;
    
    @Autowired
    private OrgRoleRepository orgRoleRepo;
    
    @Autowired
    private OrgBasicDetRepository orgBasicDet;
    
    @Autowired
    private RankRepository rankRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private OrgPortalDetailsRepository orgPortalRepository;
    
    
    @Autowired
    private OrgForCaseRepository orgForCaseRepository;
    
    @Autowired
    private OrgMenuMapNodalRepository orgMenuMapNodalRepository;
    
    @Autowired
    private RankDetailsRepository rankDetailsRepository;
  
    @Autowired
    private ReportsToUserResRepository reportsToUserResRepository;
    
    @Autowired
    PoOrgDetailsRepository poOrgDetailsRepository;
    
    @Autowired
    UserDataResRepository userDataResRepository;
    
    @Value("${get.user.key.service}")
	private String restUrl;
    
	@Autowired
	RestTemplate restTemplate;
    
    @Override
	public Org saveOrUpdate(OrgReqDto orgReqDto,HttpHeaders headers) {
    	String encode=null;
    	Org org=new Org();
    	BeanUtils.copyProperties(orgReqDto, org);

    	String orgPassCode=null;
    		if(orgReqDto.getOrgId() !=null && orgReqDto.getOrgId()>0)
    		{
    		orgPassCode=orgRepository.getOrgPasscode(orgReqDto.getOrgId());
    		}
    		encode =orgPassCode!=null ? orgPassCode : RandomStringUtils.randomAlphanumeric(12);    	
    		org.setOrgPasscode(encode);

    	org.getOrgPortals().forEach(d -> d.setOrg(org));
    	Org orgSaved=orgRepository.save(org);

    	int keyCheck=orgRepository.getOrgKeyCount(orgSaved.getOrgId());
    	if (keyCheck==0 && orgSaved.getOrgId()>0) {
    		
			UserKeyRequestDto userKeyReq = new UserKeyRequestDto();
			userKeyReq.setUserId(orgSaved.getOrgId());
			userKeyReq.setCreatedBy(orgSaved.getCreatedBy());
			userKeyReq.setEncriptedPasscode(encode);
			userKeyReq.setOrgId(orgSaved.getOrgId());
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			List<String> headerAuth = headers.get("Authorization");

			if (headerAuth != null) {
				httpHeaders.set("Authorization", headerAuth.get(0));
			}
			HttpEntity<Object> httpEntity = new HttpEntity<>(userKeyReq, httpHeaders);

			restTemplate.postForEntity(restUrl, httpEntity, ApiResponse.class);
		}	
    	return orgSaved;
	}

    @Override
    public List<OrgRole> saveOrUpdate(OrgRoleDto orgRoleDto) {
    	List<OrgRole> responseList=new ArrayList<>();
    	for(int i=0; i<orgRoleDto.getOrgRoleList().size();i++)
    	{
    		OrgRole orgRole;
    		orgRole=orgRoleDto.getOrgRoleList().get(i);
    		if(orgRole !=null)
    		{
    			orgRole.getOrgRolePortals().forEach(d -> d.setOrgRole(orgRole));
    			responseList.add(orgRoleRepository.save(orgRole));    			
    		}
    	} 
    	if(orgRoleDto.getOrgRoleList() !=null && orgRoleDto.getOrgRoleList().get(0).getOrgId() !=null) {
    		orgRoleRepository.deactiveUserOnRemovedRoles(orgRoleDto.getOrgRoleList().get(0).getOrgId());
			orgRoleRepository.deleteUserReportingOnRemovedRoles(orgRoleDto.getOrgRoleList().get(0).getOrgId());
    	}
    	return responseList;
   	}
	
    @Override
   	public List<OrgPortalRoleMenuMap> saveOrUpdate(OrgPortalRoleMenuMapDto mOrgPortalRoleMenuMapDto) {
    	List<OrgPortalRoleMenuMap> responseList=new ArrayList<>();
    	for(int i=0; i<mOrgPortalRoleMenuMapDto.getOrgPortalRoleMenuList().size();i++)
    	{
    		OrgPortalRoleMenuMap orgPortalRoleMenuMap;
    	    orgPortalRoleMenuMap=mOrgPortalRoleMenuMapDto.getOrgPortalRoleMenuList().get(i);
    	    orgPortalRoleMenuMap=orgPortalRoleMenuMapRepository.save(orgPortalRoleMenuMap); 
    	    responseList.add(orgPortalRoleMenuMap);
    	    
    	}
    	return responseList;
   	}
    
    @Override
    public List<OrgResDto> findAllActiveOrg() {
        return orgResponseRepository.findAllActiveOrg();
    }
    
    @Override
    @Transactional
	public Integer activateDeactivateOrganization(Integer orgId, Boolean isActive,String remarks) {
		Integer organizationId=null;
		if (orgId != null && orgId > 0) {
			organizationId = orgRepository.activateDeactivateOrganization(orgId, isActive,remarks);
		}
		return organizationId;
	}
    
   
    @Override
    public List<OrgRole> findByOrgId(Integer orgId) {
        return orgRoleRepository.findByOrgIdOrderByRoleIdAsc(orgId);
    }
    
	@Override
	public OrganizationBasicDetailsDto getOrganizationBasicDetailsByOrgId(Integer id) {
		OrganizationBasicDetailsDto orgBasicDetails=orgBasicDet.getOrganizationBasicDetailsByOrgId(id);
		List<PortalDetails> portalDetails=orgPortalRepository.getOrganizationPortalByOrgId(id);
		orgBasicDetails.setPortalDetails(portalDetails);
		return orgBasicDetails;
	}

	@Override
	public List<Rank> findAllRank() {
		return rankRepository.findAllRank();
	}

	@Override
	public Rank saveOrUpdate(RankReqDto rankReqDto) {
		Rank rank = new Rank();
		BeanUtils.copyProperties(rankReqDto, rank);
		return rankRepository.save(rank);
	}

	@Override
	public List<MenuMappingResDto> getMenuMappingResponse(List<MenuMapReqDto> reqDto) {
		List<MenuMappingResDto> finalResList = new ArrayList<>();		
		for(MenuMapReqDto menuMapReqDto : reqDto) {
			MenuMappingResDto mapDto = new MenuMappingResDto();
			RoleResponse roleRes= orgRoleRepo.getRolePortalId(menuMapReqDto.getOrgRoleMapId());
			List<PortalResDto> portalResDtoList = new ArrayList<>();
			for (PortalReqDto portReqDto : menuMapReqDto.getPortalList()) {
				PortalResDto portalResDto = new PortalResDto();
				PortalResponse portalRes= orgPortalRepo.getRolePortalId(menuMapReqDto.getOrgRoleMapId(), portReqDto.getPortalId());			
				List<MenuResponse> menuRes=orgMenuRepo.getMenuMappingByOrgRolePortalId(menuMapReqDto.getOrgRoleMapId(), portReqDto.getPortalId());
				portalResDto.setPortalName(portalRes !=null ? portalRes.getPortalName() : "");
				portalResDto.setMenuList(menuRes);
				portalResDtoList.add(portalResDto);
			}
			mapDto.setRoleId(roleRes !=null ? roleRes.getRoleId() : null);
			mapDto.setPortalList(portalResDtoList);
			finalResList.add(mapDto);
		}
		return finalResList;
	}
	
	@Override
	public List<MenuMappingResFromMapDto> getMenuMappingResponseFromMap(List<MenuMapReqDto> reqDto) {
		List<MenuMappingResFromMapDto> finalResList = new ArrayList<>();		
		for(MenuMapReqDto menuMapReqDto : reqDto) {
			MenuMappingResFromMapDto mapDto = new MenuMappingResFromMapDto();
			RoleResponse roleRes= orgRoleRepo.getRolePortalId(menuMapReqDto.getOrgRoleMapId());
			List<PortalResFromMapDto> portalResFromMapDtoList = new ArrayList<>();
			for (PortalReqDto portReqDto : menuMapReqDto.getPortalList()) {
				PortalResFromMapDto portalResDto = new PortalResFromMapDto();
				PortalResponse portalRes= orgPortalRepo.getRolePortalId(menuMapReqDto.getOrgRoleMapId(), portReqDto.getPortalId());			
				List<MenuResponseFromMap> menuRes=orgMenuMapRepo.getMenuMappingFromMapByOrgRolePortalId(menuMapReqDto.getOrgRoleMapId(), portReqDto.getPortalId());
				portalResDto.setPortalName(portalRes !=null ? portalRes.getPortalName() : "");
				portalResDto.setMenuList(menuRes);
				portalResFromMapDtoList.add(portalResDto);
			}
			mapDto.setRoleId(roleRes !=null ? roleRes.getRoleId() : null);
			mapDto.setPortalList(portalResFromMapDtoList);
			finalResList.add(mapDto);
		}
		return finalResList;
	}
	
	@Override
	public List<MenuMappingResFromMapDto> getMenuMappingForUserCreationByOrgRolePortalId(List<MenuMapReqDto> reqDto) {
		List<MenuMappingResFromMapDto> finalResList = new ArrayList<>();		
		for(MenuMapReqDto menuMapReqDto : reqDto) {
			MenuMappingResFromMapDto mapDto = new MenuMappingResFromMapDto();
			RoleResponse roleRes= orgRoleRepo.getRolePortalId(menuMapReqDto.getOrgRoleMapId());
			List<PortalResFromMapDto> portalResFromMapDtoList = new ArrayList<>();
			for (PortalReqDto portReqDto : menuMapReqDto.getPortalList()) {
				PortalResFromMapDto portalResDto = new PortalResFromMapDto();
				PortalResponse portalRes= orgPortalRepo.getRolePortalId(menuMapReqDto.getOrgRoleMapId(), portReqDto.getPortalId());			
				List<MenuResponseFromMap> menuRes=orgMenuMapRepo.getMenuMappingForUserCreationByOrgRolePortalId(menuMapReqDto.getOrgRoleMapId(), portReqDto.getPortalId());
				portalResDto.setPortalName(portalRes !=null ? portalRes.getPortalName() : "");
				portalResDto.setMenuList(menuRes);
				portalResFromMapDtoList.add(portalResDto);
			}
			mapDto.setRoleId(roleRes !=null ? roleRes.getRoleId() : null);
			mapDto.setPortalList(portalResFromMapDtoList);
			finalResList.add(mapDto);
		}
		return finalResList;
	}
	
	@Override
	public List<OrgCase> findOrgForCase(String orgTypeAlias, Integer uaId) {
		return orgForCaseRepository.findOrgForCase(orgTypeAlias,uaId);
	} 
	
	@Override
	public long count(){
		return orgRepository.count();
	}

	@Override
	public List<Rank> getAllRankByRoleId(Integer roleId) {
		return rankRepository.findRankByRoleId(roleId);
	}

	@Override
	public MenuMappingNodalResDto getUserPortalAndMenuForNodal(AddUserNodalOfficerDto reqDto) {
		List<PortalNodalResDto> menuResList = new ArrayList<>();
		List<ReportsToUserRes> userResList = new ArrayList<>();
		MenuMappingNodalResDto menuMapingNodal=new MenuMappingNodalResDto();
		List<RankDetails> rankDetails= rankDetailsRepository.findRankDetailsByRoleAndOrgId(reqDto.getRoleId(),reqDto.getOrgId());
		List<ReportsToUserRes> userDetails= reportsToUserResRepository.findUserDetailsByRoleAndOrgId(reqDto.getRoleId(),reqDto.getOrgId());
		List<OrgRolePortalResDto> orgPortalDetails= orgMenuMapNodalRepository.getMenuMappingFromMapByOrgRolePortalId(reqDto.getRoleId(),reqDto.getOrgId());
		for (OrgRolePortalResDto orgPortalRes : orgPortalDetails)
		{
			PortalNodalResDto portalDetails=new PortalNodalResDto();
			List<MenuResponseFromMap> menuRes=orgMenuMapRepo.getMenuMappingForUserCreationByOrgRolePortalId(orgPortalRes.getOrgRoleMapId(), orgPortalRes.getPortalId());
			portalDetails.setPortalId(orgPortalRes.getPortalId());
			portalDetails.setPortalName(orgPortalRes.getPortalName());
			portalDetails.setOrgPortalMapId(orgPortalRes.getOrgPortalMapId());
			portalDetails.setMenuList(menuRes);
			menuResList.add(portalDetails);
		}
		for(ReportsToUserRes reportToUserRoleList : userDetails) {
			ReportsToUserRes resDto = new ReportsToUserRes();
			List<UserDetailsResDto> userData = userDataResRepository.getUserDetails(reqDto.getOrgId(),reportToUserRoleList.getRoleId());
			resDto.setRoleId(reportToUserRoleList.getRoleId());
			resDto.setRoleName(reportToUserRoleList.getRoleName());
			resDto.setRoleWiseUsersList(userData);
			userResList.add(resDto);
		}
		menuMapingNodal.setPortalList(menuResList);
		menuMapingNodal.setRankList(rankDetails);
		menuMapingNodal.setUserList(userResList);
		
		return menuMapingNodal;
	}

	@Override
	public List<RoleResponse> findOrgRole(Integer orgId, Integer orgTypeId) {
		return orgRoleRepo.findOrgRole(orgId, orgTypeId);
	}

	@Override
	public List<PoOrgConfigDetails> getPoOrgNamebyOrgTypeId() {
		return poOrgDetailsRepository.getPoOrgNamebyOrgTypeId();
	}
	
	public static String generateRandomString()
	{
		String rand=null;
		try {
			rand= SecureRandom.getInstanceStrong().ints(33, 123).filter(num -> (num!=34) && (num<39 || num>47) && (num<58 || num>64) && (num<91 || num>96) ).limit(12).mapToObj(c -> (char)c).collect(StringBuffer::new, StringBuffer::append, StringBuffer::append).toString();
		}
		catch(NoSuchAlgorithmException ex)
		{
			log.info("Error in generating Randon Number");
		}
		return rand;
	}
	
}
