package com.ng.org.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.org.constants.Constants;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;


/**
 * The persistent class for the M_USER database table.
 * 
 */
@Data
@RequiredArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Valid
@Entity
@Table(name="M_USER")

public class User implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="USER_ID", unique=true, nullable=false)
	private Integer userId;
	
	@Column(name="USER_LOGIN_ID", nullable=false)
	private String userLoginId;

	@Column(name="USER_NAME", nullable=false)
	private String userName;

	@Column(name="USER_ADDRESS")
	private String userAddress;	

	@Column(name="USER_EMAIL_ID")
	private String userEmailId;
	
	@Column(name="USER_CONTACT_NO")
	private Long userContactNo;

	@Column(name="CREATED_BY", nullable=false,updatable = false)
	private Integer createdBy;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT,timezone = "GMT+5:30")
	@Column(name="CREATED_ON", nullable=false,updatable = false)
	private Timestamp createdOn;

	@Column(name="IS_ACTIVE", nullable=false,columnDefinition = "default bit 1")
	private Boolean isActive;
}