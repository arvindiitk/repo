package com.ng.org.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.org.constants.Constants;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The persistent class for the M_ORG database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Valid
@Entity
@Table(name = "M_ORG")

public class Org implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ORG_ID", unique = true, nullable = false)
	private Integer orgId;

	@Column(name = "CREATED_BY", nullable = false, updatable = false)
	private Integer createdBy;

	@Column(name = "ORG_TYPE_ID", nullable = false)
	private Integer orgTypeId;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	@Column(name = "CREATED_ON", nullable = false, updatable = false)
	private Timestamp createdOn;

	@Column(name = "IS_ACTIVE", nullable = false, columnDefinition = "default bit 1")
	private Boolean isActive;

	@Column(name = "ORG_ADDR")
	private String orgAddr;

	@Column(name = "ORG_ALIAS", nullable = false)
	private String orgAlias;

	@Column(name = "ORG_CONTACT_NO")
	private Long orgContactNo;

	@Column(name = "ORG_NAME", nullable = false)
	private String orgName;

	@Column(name = "Remarks")
	private String remarks;
	
	@Column(name = "IS_STATE", nullable = false, columnDefinition = "default bit 1")
	private Boolean isState;
	
	@Column(name = "ORG_PASSCODE")
	private String orgPasscode;

	// bi-directional many-to-one association to OrgType
	@JsonBackReference(value = "orgType")
	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.ALL }, optional = false)
	@JoinColumn(name = "ORG_TYPE_ID", nullable = false, updatable = false, insertable = false)
	private OrgType orgType;

	// bi-directional many-to-one association to OrgPortal

	@JsonBackReference(value = "orgPortals")
	@OneToMany(mappedBy = "org", fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
	private List<OrgPortal> orgPortals;

	// bi-directional many-to-one association to OrgRole

	@JsonBackReference(value = "orgRoles")
	@OneToMany(mappedBy = "org", fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
	private List<OrgRole> orgRoles;

}