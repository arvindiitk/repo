package com.ng.keycloak.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ng.keycloak.model.entity.MUser;
import com.ng.keycloak.model.entity.User;
import com.ng.keycloak.model.entity.UserAudit;

@Service
public interface CaptchaServive {
	
	public Optional<String> getCaptcha();

	public void updateCaptcha(String userName, String captcha);
	
	public void updateIsPAsswordFlag(String userName, Boolean isPasswordFlag);
	
	public List<MUser> findByLoginId(String userName, String roleAlias);

	public User getUserDetail(String username);

	public void saveProfileAudit(UserAudit audit);
}
