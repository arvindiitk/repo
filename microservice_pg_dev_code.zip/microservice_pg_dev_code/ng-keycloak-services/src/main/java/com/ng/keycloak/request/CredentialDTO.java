package com.ng.keycloak.request;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CredentialDTO implements Serializable{

	private static final long serialVersionUID = 2038055100313337778L;
	
	private String type;
  	private String value;
  	private Boolean temporary;
  	
}
