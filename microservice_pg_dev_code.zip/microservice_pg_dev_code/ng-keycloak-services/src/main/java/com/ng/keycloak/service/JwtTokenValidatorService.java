package com.ng.keycloak.service;

import com.ng.keycloak.exception.InvalidTokenException;

public interface JwtTokenValidatorService {
	public String validateToken(String accessToken) throws InvalidTokenException ;
}
