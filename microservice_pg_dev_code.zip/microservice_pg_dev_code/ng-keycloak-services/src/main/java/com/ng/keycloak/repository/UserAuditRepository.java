package com.ng.keycloak.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ng.keycloak.model.entity.UserAudit;


@Repository
public interface UserAuditRepository extends JpaRepository<UserAudit, Integer> {

	
}
