package com.ng.keycloak.model.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.keycloak.constants.Constants;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The persistent class for the M_USER database table.
 * 
 */
@Data
@ToString
@Entity
@Table(name="M_USER_AUDIT")

public class UserAudit implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_audit_id", unique = true, nullable = false)
	private Integer userAuditId;

	@Column(name = "updated_user_id" )
	private Integer userId;

	@Column(name = "updated_login_id" )
	private String userLoginId;

	@Column(name = "updated_user_name")
	private String userName;

	@Column(name = "updated_user_address")
	private String userAddress;

	@Column(name = "updated_email_id")
	private String userEmailId;

	@Column(name = "updated_contact_no")
	private Long userContactNo;

	@Column(name = "profile_update_remarks")
	private String profileUpdateRemarks;

	@Column(name = "created_by")
	private Integer createdBy;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	@Column(name = "created_on", nullable = false, updatable = false)
	private Timestamp createdOn;
	
	@Column(name = "status")
	private Boolean isActive;

	@Column(name = "updated_password" )
	private Boolean updatedPassword;
	
	@Column(name = "action")
	private Boolean action;

}