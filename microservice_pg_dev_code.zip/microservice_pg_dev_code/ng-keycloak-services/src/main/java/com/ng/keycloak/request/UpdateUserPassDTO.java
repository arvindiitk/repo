package com.ng.keycloak.request;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UpdateUserPassDTO implements Serializable{
	private static final long serialVersionUID = 1L;

	private String username;
	private String currentPassword;
	private String newPassword;
	private String confirmPassword;
	private Boolean isPasswordFlag=false;

}
