package com.ng.keycloak.service.impl;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.ng.keycloak.exception.InvalidTokenException;
import com.ng.keycloak.service.JwtTokenValidatorService;

@Component
@RefreshScope
public class JwtTokenValidatorServiceImpl implements JwtTokenValidatorService{

	public String validateToken(String accessToken) throws InvalidTokenException {
	    DecodedJWT decodedJWT = decodeToken(accessToken);
        return verifyPayload(decodedJWT);
	}

	private DecodedJWT decodeToken(String accessToken) throws InvalidTokenException {

		try {
			return JWT.decode(accessToken);
		} catch (Exception ex) {
			throw new InvalidTokenException("Token is InvalidTokenException ", ex);
		}
	}
	private String verifyPayload(DecodedJWT decodedJWT) throws InvalidTokenException {
		JsonObject payloadAsJson = decodeTokenPayloadToJsonObject(decodedJWT);
		return payloadAsJson.get("sub").toString();
	}

	private JsonObject decodeTokenPayloadToJsonObject(DecodedJWT decodedJWT) throws InvalidTokenException {
		try {
			String payloadAsString = decodedJWT.getPayload();
			return new Gson().fromJson(new String(Base64.getDecoder().decode(payloadAsString), StandardCharsets.UTF_8),
					JsonObject.class);
		} catch (RuntimeException exception) {
			throw new InvalidTokenException("Invalid JWT or JSON format of each of the jwt parts", exception);
		}
	}
}
