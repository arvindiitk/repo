package com.ng.keycloak.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ng.keycloak.model.entity.User;


@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

	 @Query(value = "SELECT * FROM ng_ua.vw_get_user_details vw where vw.user_login_id = :username ", nativeQuery = true)
    User getUserDetail(String username);

	
}
