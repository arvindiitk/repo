package com.ng.keycloak.service.impl;

import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.keycloak.model.entity.MUser;
import com.ng.keycloak.model.entity.User;
import com.ng.keycloak.model.entity.UserAudit;
import com.ng.keycloak.repository.OrgUserRepo;
import com.ng.keycloak.repository.UserAuditRepository;
import com.ng.keycloak.repository.UserRepository;
import com.ng.keycloak.service.CaptchaServive;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class CaptchaServiveImpl implements CaptchaServive {

	@Autowired
	private OrgUserRepo orgUserRepo;
	
	@Autowired
	private UserAuditRepository auditRepository;  
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public Optional<String> getCaptcha() {
		Integer captchaLength = 6;
		StringBuilder captchaStrBuffer = new StringBuilder();
		Optional<String> optional = Optional.of(captchaStrBuffer.toString());
		try {
			String saltChars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ1234567890";
			SecureRandom rnd = new SecureRandom();
			while (captchaStrBuffer.length() < captchaLength) {
				int index = (int) (rnd.nextFloat() * saltChars.length());
				captchaStrBuffer.append(saltChars.substring(index, index + 1));
			}
			log.info("generateCaptchaTextMethod2   " + captchaStrBuffer.toString());
			optional = Optional.of(captchaStrBuffer.toString());
			return optional;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return optional;
	}

	public void updateCaptcha(String loginId, String captcha) {
		orgUserRepo.insertCaptcha(loginId, captcha);
	}

	@Override
	public List<MUser> findByLoginId(String userName, String roleAlias) {
		if(roleAlias !=null && !"".equalsIgnoreCase(roleAlias)) {
			return orgUserRepo.findAdminById(userName, roleAlias);
		} else {
			return orgUserRepo.findByLoginId(userName);
		}
		
	}

	@Override
	public void updateIsPAsswordFlag(String loginId, Boolean isPasswordFlag) {
		orgUserRepo.updateIsPAsswordFlag(loginId, isPasswordFlag);
		
	}

	@Override
	public User getUserDetail(String username) {
		return userRepository.getUserDetail(username);
	}

	@Override
	public void saveProfileAudit(UserAudit audit) {
		auditRepository.save(audit);
		
	}

	
}
