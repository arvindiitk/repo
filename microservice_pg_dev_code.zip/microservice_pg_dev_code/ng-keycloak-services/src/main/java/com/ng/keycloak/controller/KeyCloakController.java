package com.ng.keycloak.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ng.keycloak.exception.InvalidTokenException;
import com.ng.keycloak.model.entity.MUser;
import com.ng.keycloak.model.entity.User;
import com.ng.keycloak.model.entity.UserAudit;
import com.ng.keycloak.request.CreateUserDTO;
import com.ng.keycloak.request.KeyCloakReqType;
import com.ng.keycloak.request.ResponseApi;
import com.ng.keycloak.request.UpdateUserPassDTO;
import com.ng.keycloak.response.ApiResponse;
import com.ng.keycloak.service.CaptchaServive;
import com.ng.keycloak.service.JwtTokenValidatorService;
import com.ng.keycloak.service.KeyCloakAPIRequest;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/ng-keyCloak-type")
@Transactional(timeout = 180)
public class KeyCloakController {

	@Value("${keycloak.token-uri}")
	private String keycloakToken;

	@Value("${keycloak.client-id}")
	private String clientId;

	@Value("${keycloak.client-secret}")
	private String clientSecret;

	@Value("${keycloak.authorization-grant-type}")
	private String grantType;

	@Value("${keycloak.client.grant-type}")
	private String keycloakClientGrantType;

	@Value("${keycloak.admin.client-id}")
	private String clientAdminId;

	@Value("${keycloak.admin.client-secret}")
	private String clientAdminSecret;

	@Value("${keycloak.admin.token-uri}")
	private String keycloakAdminTokenUri;

	@Value("${keycloak.create-updatepassword-user-uri}")
	private String keycloakCreateUpdatePasswordUserUri;

	
	@Value("${keycloak.create-updatepassword-masteruser-uri}")
	private String keycloakCreateUpdatePasswordMasteruserUri;
	
	
	@Value("${keycloak.create-updatepassword-master-uri}")
	private String keycloakUpdatePasswordMasteruserUri;
	
	private RestTemplate restTemplate = new RestTemplate();

	@Autowired
	private CaptchaServive captchaServive;
	
	@Autowired
	private KeyCloakAPIRequest keyCloakAPIRequest;

	@Autowired
	private JwtTokenValidatorService jwtTokenValidatorService;

	//@Value("${keycloak.create-createUser-ad-uri}")
	//private String keycloakCreateUserADURI;
	
	//@Value("${keycloak.create-updatepassword-ad-uri}")
	//private String keycloakUpdatePasswdUserADURI;
	
	@Value("${keycloak.ad-uri}")
	private String keycloakToADURI;
	
	@Value("${DN_PRINCIPAL}")
	private String dn_principal;
	
	
	

	@PostMapping(value = "keyCloak/ng-keyCloak", consumes = { "application/json" })
	public ResponseEntity<Object> getToken(@RequestBody KeyCloakReqType cloakReqType) {
		
		com.ng.keycloak.response.ApiResponse<?> apiResponse = null;
		String username=cloakReqType.getUsername();
		System.out.println("username===>>>"+username);
		if(cloakReqType.getUsername().contains(dn_principal))
			username=username;
		else
			username=username+dn_principal;
		System.out.println("username===>>>"+username+" role "+cloakReqType.getRoleAlias());
		
		// validate userId from Database 	
		List<MUser> list = captchaServive.findByLoginId(username, cloakReqType.getRoleAlias());
		if(list.isEmpty())
			list = captchaServive.findByLoginId(username.replaceAll(dn_principal, ""), cloakReqType.getRoleAlias());
		System.out.println("username===>>>"+list.size());
		if (list.isEmpty()) {
			apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.errors(com.ng.keycloak.constants.Constants.NOT_FOUND)
					.message("User Id is temporarily unavailable. Please contact the Admin Helpline No for help.")
					.build();
			return ResponseEntity.ok().body(apiResponse);
		}
		// validate userId from KeyCloak.
		try {
			ResponseApi response = keyCloakAPIRequest.userTokenKeyCloakAPI(null,clientSecret, username,cloakReqType.getPassword(),
				keycloakToken);
			apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.message(com.ng.keycloak.constants.Constants.SUCCESS).data(response).build();

		} catch (Exception e) {
			apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.message(com.ng.keycloak.constants.Constants.NOT_FOUND).data("Password is incorrect.").build();
		}

		log.info("OrgTypesController: createOrgTypes ng-saveUpdateOrgTypes response");

		return ResponseEntity.ok().body(apiResponse);

	}

	@PostMapping(value = "keyCloak/ng-createUser", consumes = { "application/json" })
	public ResponseEntity<Object> createUserUsingToken(@RequestBody CreateUserDTO createUserDTO) {
		// added by Arvind Pal
		log.info("OrgTypesController: createOrgTypes ng-saveUpdateOrgTypes response");
		com.ng.keycloak.response.ApiResponse<?> apiResponse = null;
		ResponseEntity<String> responseAPI = keyCloakAPIRequest.restTemplateToAD(createUserDTO,keycloakToADURI+"/ng-keyCloak-type/keyCloak/ng-createUser");
		apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(com.ng.keycloak.constants.Constants.SUCCESS).data(responseAPI).build();
		log.info("OrgTypesController: createOrgTypes ng-saveUpdateOrgTypes response");
		return ResponseEntity.ok().body(apiResponse);
	}

	

	@PostMapping(value = "keyCloak/ng-updateUserPasswod", consumes = { "application/json" })
	public ResponseEntity<Object> updateUserPasswod(@RequestBody UpdateUserPassDTO updateUserPassDTO)
			throws InvalidTokenException {
		log.info("OrgTypesController: updateUserPasswod ng-updateUserPasswod response");
		String username=updateUserPassDTO.getUsername();
		// added by Arvind Pal
		if(updateUserPassDTO.getUsername().contains(dn_principal))
                        username=username;
                else
                        username=username+dn_principal;
		updateUserPassDTO.setUsername(updateUserPassDTO.getUsername().replaceAll(dn_principal,""));
		ResponseEntity<String> responseAPI = keyCloakAPIRequest.restTemplateToAD(updateUserPassDTO,keycloakToADURI+"/ng-keyCloak-type/keyCloak/ng-updatePassword");
		String resp=responseAPI.getBody();
		if(resp.equals("SUCCESS")) {
			ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(com.ng.keycloak.constants.Constants.SUCCESS).data("Password Updated").build();
			if(apiResponse.getErrors()==null)
			{
				captchaServive.updateIsPAsswordFlag(username,updateUserPassDTO.getIsPasswordFlag());
			}
			return ResponseEntity.ok().body(apiResponse);
		} else {
			ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.message(com.ng.keycloak.constants.Constants.ERROR).data("Password Update failed !!").build();
			return ResponseEntity.ok().body(apiResponse);
		}
	}
	
}
