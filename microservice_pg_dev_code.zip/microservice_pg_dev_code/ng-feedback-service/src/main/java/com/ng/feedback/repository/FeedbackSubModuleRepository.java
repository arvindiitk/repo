package com.ng.feedback.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ng.feedback.entity.FeedbackSubModule;

@Repository
public interface FeedbackSubModuleRepository extends JpaRepository<FeedbackSubModule, Integer> {

	List<FeedbackSubModule> findAllByFeedbackModuleId(Integer feedbackModuleId);

 
}
