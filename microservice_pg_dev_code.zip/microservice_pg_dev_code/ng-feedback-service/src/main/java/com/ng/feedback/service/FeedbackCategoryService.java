package com.ng.feedback.service;

import java.util.List;

import com.ng.feedback.entity.FeedbackCategory;
import com.ng.feedback.request.FeedbackCategoryReqDto;
import com.ng.feedback.response.FeedbackCategoryResDto;

public interface FeedbackCategoryService {

	public List<FeedbackCategoryResDto> findAll();

	public FeedbackCategory saveOrUpdate(FeedbackCategoryReqDto feedbackCategoryReqDto);

}
