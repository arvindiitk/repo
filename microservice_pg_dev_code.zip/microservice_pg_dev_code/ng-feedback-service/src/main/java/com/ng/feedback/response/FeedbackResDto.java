package com.ng.feedback.response;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.feedback.constants.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Entity
public class FeedbackResDto implements Serializable {

	private static final long serialVersionUID = 3754628787538427335L;

	@Id
	@Column(name = "FEEDBACK_ID")
	private Integer feedbackId;

	@Column(name = "TYPE_ID")
	private Integer typeId;

	@Column(name = "FEEDBACK_TYPE_NAME")
	private String feedbackTypeName;

	@Column(name = "CATEGORY_ID")
	private Integer categoryId;

	@Column(name = "FEEDBACK_CATEGORY")
	private String feedbackCateoryName;
	
	@Column(name = "FEEDBACK_SUB_MODULE_ID")
	private Integer subModuleId;

	@Column(name = "FEEDBACK_SUB_MODULE")
	private String subModuleName;

	@Column(name = "SUBJECT")
	private String subject;

	@Column(name = "DESCRIPTION")
	private String desccription;

	@Column(name = "CREATED_BY")
	private Integer createdBy;
	
	@Column(name = "USER_NAME")
	private String createdByName;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT_TIMESTAMP)
	@Column(name = "CREATED_ON")
	private Timestamp createdOn;

	@Column(name = "RESPONSE_BY")
	private Integer responseBy;

	@Column(name = "IS_READ")
	private Boolean isRead;

	@Column(name = "READ_BY")
	private String readBy;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT_TIMESTAMP)
	@Column(name = "READ_ON")
	private Timestamp readAt;

	@Column(name = "FEEDBACK_RESPONSE")
	private String feedbackRes;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	@Column(name = "RESPONSE_ON")
	private Timestamp responseOn;
	
	@Column(name = "org_id")
	private Integer orgId;
	
	@Column(name = "org_name")
	private String orgName;

}