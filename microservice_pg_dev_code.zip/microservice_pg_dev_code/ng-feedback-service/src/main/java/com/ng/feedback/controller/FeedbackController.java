package com.ng.feedback.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ng.feedback.constants.Constants;
import com.ng.feedback.entity.Feedback;
import com.ng.feedback.entity.FeedbackCategory;
import com.ng.feedback.entity.FeedbackSubModule;
import com.ng.feedback.entity.FeedbackType;
import com.ng.feedback.exception.ResourceNotFoundException;
import com.ng.feedback.request.FeedbackCategoryReqDto;
import com.ng.feedback.request.FeedbackFilterReqDto;
import com.ng.feedback.request.FeedbackReqDto;
import com.ng.feedback.request.FeedbackSubModuleReqDto;
import com.ng.feedback.request.FeedbackTypeReqDto;
import com.ng.feedback.response.ApiResponse;
import com.ng.feedback.response.FeedbackCategoryResDto;
import com.ng.feedback.response.FeedbackResDto;
import com.ng.feedback.response.FeedbackTypeResDto;
import com.ng.feedback.service.FeedbackCategoryService;
import com.ng.feedback.service.FeedbackService;
import com.ng.feedback.service.FeedbackSubModuleService;
import com.ng.feedback.service.FeedbackTypeService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/ng-feedback")
@Transactional(timeout = 180)
public class FeedbackController {

	@Autowired
	FeedbackTypeService feedbackTypeService;

	@Autowired
	FeedbackCategoryService feedbackCategoryService;

	@Autowired
	FeedbackService feedbackService;
	
	@Autowired
	FeedbackSubModuleService feedbackSubModuleService;

	@GetMapping("/ng-getAllFeedbackType")
	public ResponseEntity<Object> getAllFeedbackType() throws ResourceNotFoundException {
		log.info("FeedbackController :getAllFeedbackType ");
		List<FeedbackTypeResDto> feedbackTypeList = feedbackTypeService.findAll();
		
//		if (feedbackTypeList.isEmpty()) {
//			throw new ResourceNotFoundException("Feedback type list not found");
//		}
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(feedbackTypeList).build();
		log.info("[FeedbackController.getAllFeedbackType] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ng-createFeedbackType", consumes = { "application/json" })
	public ResponseEntity<Object> createFeedbackType(@Valid @RequestBody FeedbackTypeReqDto feedbackTypeReqDto) {
		log.info("FeedbackController: createFeedbackType {}", feedbackTypeReqDto.toString());

		FeedbackType feedbackType = feedbackTypeService.saveOrUpdate(feedbackTypeReqDto);
		String returnMsg = "";
		if(feedbackTypeReqDto.getFeedbackTypeId() !=null) {
			returnMsg = Constants.CREATE_SUCCESS_UPDATE_TYPE; 
		} else {
			returnMsg = Constants.CREATE_SUCCESS_TYPE;
		}
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(returnMsg).data(feedbackType).build();
		log.info("FeedbackController: ng-createFeedbackType response {}", apiResponse);
		return ResponseEntity.ok().body(apiResponse);

	}

	@GetMapping("/ng-getAllFeedbackCategory")
	public ResponseEntity<Object> getAllFeedbackCategory() throws ResourceNotFoundException {
		log.info("FeedbackController :getAllFeedbackCategory ");
		List<FeedbackCategoryResDto> feedbackTypeList = feedbackCategoryService.findAll();
//		if (feedbackTypeList.isEmpty()) {
//			throw new ResourceNotFoundException("Feedback category list not found");
//		}
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(feedbackTypeList).build();
		log.info("[FeedbackController.getAllFeedbackCategory] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ng-createFeedbackCategory", consumes = { "application/json" })
	public ResponseEntity<Object> createFeedbackCategory(@Valid @RequestBody FeedbackCategoryReqDto feedbackCategoryReqDto) {
		log.info("FeedbackController: createFeedbackType {}", feedbackCategoryReqDto.toString());

		FeedbackCategory feedbackCategory = feedbackCategoryService.saveOrUpdate(feedbackCategoryReqDto);
		String returnMsg = "";
		if(feedbackCategoryReqDto.getFeedbackCategoryId() !=null) {
			returnMsg = Constants.CREATE_SUCCESS_CATEGORY_UPDATE_TYPE; 
		} else {
			returnMsg = Constants.CREATE_SUCCESS_CATEGORY_TYPE;
		}
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(returnMsg).data(feedbackCategory).build();
		log.info("FeedbackController: ng-createFeedbackCategory response {}", apiResponse);
		return ResponseEntity.ok().body(apiResponse);

	}

	@PostMapping(value = "/ng-createFeedback", consumes = { "application/json" })
	public ResponseEntity<Object> createFeedback(@Valid @RequestBody FeedbackReqDto feedbackReqDto) {
		log.info("FeedbackController: createFeedback {}", feedbackReqDto.toString());

		Feedback feedback = feedbackService.saveOrUpdate(feedbackReqDto);
		String returnMsg = "";
		if(feedbackReqDto.getFeedbackId() !=null) {
			returnMsg = Constants.CREATE_SUCCESS_UPDATE_FEEDBACK; 
		} else {
			returnMsg = Constants.CREATE_SUCCESS_FEEDBACK;
		}
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(returnMsg).data(feedback).build();
		log.info("FeedbackController: ng-createFeedback response {}", apiResponse);
		return ResponseEntity.ok().body(apiResponse);

	}

	@GetMapping("/ng-getAllFeedback")
	public ResponseEntity<Object> getAllFeedback() throws ResourceNotFoundException {
		log.info("FeedbackController :getAllFeedback ");
		List<FeedbackResDto> feedbackList = feedbackService.findAll();
//		if (feedbackList.isEmpty()) {
//			throw new ResourceNotFoundException("Feedback list not found");
//		}
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(feedbackList).build();
		log.info("[FeedbackController.getAllFeedback] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getAllFeedbackFilter")
	public ResponseEntity<Object> getAllFeedbackFilter(@RequestBody FeedbackFilterReqDto req) throws ResourceNotFoundException {
		log.info("FeedbackController :getAllFeedbackFilter ");
		List<FeedbackResDto> feedbackListFilter = feedbackService.findAllByFilters(req);
				
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(feedbackListFilter).build();
		log.info("[FeedbackController.getAllFeedbackFilter] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping("/ng-getFeedbackResponseById")
	public ResponseEntity<Object> getFeedbackResponseById(@RequestBody FeedbackReqDto feedbackReqDto)
			throws ResourceNotFoundException {
		log.info("FeedbackController :getFeedbackResponseById ");
		Feedback feedbackList = feedbackService.findById(feedbackReqDto.getFeedbackId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid feedback id"));

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(feedbackList).build();
		log.info("[FeedbackController.getFeedbackResponseById] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}
	
	@PostMapping("/ng-getFeedbackSubModule")
	public ResponseEntity<Object> getFeedbackSubModule(@RequestBody FeedbackSubModuleReqDto feedbackSubModuleReqDto) throws ResourceNotFoundException {
		log.info("FeedbackController :getFeedbackSubModule ");
		List<FeedbackSubModule> feedbackSubModule = feedbackSubModuleService.findAllByFeedbackModuleId(feedbackSubModuleReqDto.getFeedbackModuleId());
		if (feedbackSubModule.isEmpty()) {
			throw new ResourceNotFoundException("Feedback sub module list not found");
		}
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(feedbackSubModule).build();
		log.info("[FeedbackController.getFeedbackSubModule] : success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/ng-createFeedbackSubModule", consumes = { "application/json" })
	public ResponseEntity<Object> createFeedbackSubModule(@Valid @RequestBody FeedbackSubModuleReqDto feedbackSubModuleReqDto) {
		log.info("FeedbackController: createFeedbackSubModule {}", feedbackSubModuleReqDto.toString());

		FeedbackSubModule feedbackSubModule = feedbackSubModuleService.saveOrUpdate(feedbackSubModuleReqDto);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(feedbackSubModule).build();
		log.info("FeedbackController: ng-createFeedbackSubModule response {}", apiResponse);
		return ResponseEntity.ok().body(apiResponse);

	}
}
