package com.ng.feedback.service;

import java.util.List;

import com.ng.feedback.entity.FeedbackSubModule;
import com.ng.feedback.exception.ResourceNotFoundException;
import com.ng.feedback.request.FeedbackSubModuleReqDto;

public interface FeedbackSubModuleService {

	public List<FeedbackSubModule> findAll();

	public FeedbackSubModule saveOrUpdate(FeedbackSubModuleReqDto feedbackSubModuleReqDto);
	
	public List<FeedbackSubModule> findAllByFeedbackModuleId(Integer feedbackModuleId) throws ResourceNotFoundException;

}
