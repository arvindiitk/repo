package com.ng.feedback.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.feedback.entity.FeedbackCategory;
import com.ng.feedback.repository.FeedbackCategoryRepository;
import com.ng.feedback.repository.FeedbackCategoryResRepository;
import com.ng.feedback.request.FeedbackCategoryReqDto;
import com.ng.feedback.response.FeedbackCategoryResDto;
import com.ng.feedback.service.FeedbackCategoryService;

@Service
@Transactional
public class FeedbackCategoryServiceImpl implements FeedbackCategoryService {

	@Autowired
	private FeedbackCategoryRepository feedbackCategoryRepository;

	@Autowired
	private FeedbackCategoryResRepository feedbackCategoryResRepository;

	@Override
	public List<FeedbackCategoryResDto> findAll() {
		return feedbackCategoryResRepository.findAllFeedbackCategory();

	}

	@Override

	public FeedbackCategory saveOrUpdate(FeedbackCategoryReqDto feedbackCategoryReqDto) {
		FeedbackCategory feedbackCategory = new FeedbackCategory();
		BeanUtils.copyProperties(feedbackCategoryReqDto, feedbackCategory);
		return feedbackCategoryRepository.save(feedbackCategory);

	}

}
