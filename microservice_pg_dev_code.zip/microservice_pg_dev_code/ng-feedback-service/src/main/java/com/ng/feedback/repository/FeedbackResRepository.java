package com.ng.feedback.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ng.feedback.response.FeedbackResDto;

@Repository
public interface FeedbackResRepository extends JpaRepository<FeedbackResDto, Integer> {

	@Query(value = " select feedback.FEEDBACK_ID,feedback.TYPE_ID,feedbackType.FEEDBACK_TYPE_NAME,feedback.CATEGORY_ID,feedbackCat.FEEDBACK_CATEGORY,"
			+ " feedbackSubModule.FEEDBACK_SUB_MODULE_ID,feedbackSubModule.FEEDBACK_SUB_MODULE,feedback.SUBJECT,feedback.DESCRIPTION,feedback.CREATED_BY,muser.USER_NAME ,feedback.CREATED_ON, "
			+ " feedback.FEEDBACK_RESPONSE,feedback.IS_READ,feedback.READ_ON,feedback.READ_BY,feedback.RESPONSE_ON,feedback.RESPONSE_BY, "
			+ " orgid.ORG_ID,orgid.ORG_NAME "
			+ " from FEEDBACK feedback "
			+ " INNER JOIN M_USER muser on  muser.USER_ID=feedback.CREATED_BY AND muser.IS_ACTIVE='true' "
			+ " INNER JOIN FEEDBACK_CATEGORY feedbackCat on feedbackCat.FEEDBACK_CATEGORY_ID=feedback.CATEGORY_ID and feedbackCat.IS_ACTIVE='true' "
			+ " INNER JOIN FEEDBACK_TYPE feedbackType on feedbackType.FEEDBACK_TYPE_ID=feedback.TYPE_ID and feedbackType.IS_ACTIVE='true' "
			+ " INNER JOIN FEEDBACK_SUB_MODULE feedbackSubModule on feedbackSubModule.FEEDBACK_SUB_MODULE_ID=feedback.SUB_MODULE_ID and feedbackSubModule.IS_ACTIVE='true' "
			+ " INNER JOIN M_ORG orgid on orgid.ORG_ID=feedback.UA_ID ", nativeQuery = true)

	public List<FeedbackResDto> findAllFeedback();

	
	@Query(value = " select feedback.FEEDBACK_ID,feedback.TYPE_ID,feedbackType.FEEDBACK_TYPE_NAME,feedback.CATEGORY_ID,feedbackCat.FEEDBACK_CATEGORY,"
			+ " feedbackSubModule.FEEDBACK_SUB_MODULE_ID,feedbackSubModule.FEEDBACK_SUB_MODULE,feedback.SUBJECT,feedback.DESCRIPTION,feedback.CREATED_BY,muser.USER_NAME ,feedback.CREATED_ON, "
			+ " feedback.FEEDBACK_RESPONSE,feedback.IS_READ,feedback.READ_ON,feedback.READ_BY,feedback.RESPONSE_ON,feedback.RESPONSE_BY, "
			+ " orgid.ORG_ID,orgid.ORG_NAME "
			+ " from FEEDBACK feedback "
			+ " INNER JOIN M_USER muser on  muser.USER_ID=feedback.CREATED_BY AND muser.IS_ACTIVE='true' "
			+ " INNER JOIN FEEDBACK_CATEGORY feedbackCat on feedbackCat.FEEDBACK_CATEGORY_ID=feedback.CATEGORY_ID and feedbackCat.IS_ACTIVE='true' "
			+ " INNER JOIN FEEDBACK_TYPE feedbackType on feedbackType.FEEDBACK_TYPE_ID=feedback.TYPE_ID and feedbackType.IS_ACTIVE='true' "
			+ " INNER JOIN FEEDBACK_SUB_MODULE feedbackSubModule on feedbackSubModule.FEEDBACK_SUB_MODULE_ID=feedback.SUB_MODULE_ID and feedbackSubModule.IS_ACTIVE='true' "
			+ " INNER JOIN M_ORG orgid on orgid.ORG_ID=feedback.UA_ID "
			+ " WHERE feedback.CREATED_ON >= :fromDate "
			+ " and feedback.CREATED_ON < :toDate ", nativeQuery = true)

	public List<FeedbackResDto> findAllFeedbackFilterDate(@Param("fromDate") Timestamp fromDate, @Param("toDate") Timestamp toDate);
}
