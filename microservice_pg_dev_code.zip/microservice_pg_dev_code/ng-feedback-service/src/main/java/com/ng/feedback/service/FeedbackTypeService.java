package com.ng.feedback.service;

import java.util.List;

import com.ng.feedback.entity.FeedbackType;
import com.ng.feedback.request.FeedbackTypeReqDto;
import com.ng.feedback.response.FeedbackTypeResDto;

public interface FeedbackTypeService {
	
	public List<FeedbackTypeResDto> findAll();

	public FeedbackType saveOrUpdate(FeedbackTypeReqDto feedbackTypeReqDto);

}
