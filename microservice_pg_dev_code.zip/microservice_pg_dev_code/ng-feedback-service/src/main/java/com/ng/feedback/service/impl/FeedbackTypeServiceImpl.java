package com.ng.feedback.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.feedback.entity.FeedbackType;
import com.ng.feedback.repository.FeedbackTypeRepository;
import com.ng.feedback.repository.FeedbackTypeResRepository;
import com.ng.feedback.request.FeedbackTypeReqDto;
import com.ng.feedback.response.FeedbackTypeResDto;
import com.ng.feedback.service.FeedbackTypeService;

@Service
@Transactional
public class FeedbackTypeServiceImpl implements FeedbackTypeService {

	@Autowired
	private FeedbackTypeRepository feedbackTypeRepository;
	
	@Autowired
	private FeedbackTypeResRepository feedbackTypeResRepository;

	@Override
	public List<FeedbackTypeResDto> findAll() {
		return feedbackTypeResRepository.findAllFeedbackType();

	}

	@Override

	public FeedbackType saveOrUpdate(FeedbackTypeReqDto feedbackTypeReqDto) {
		FeedbackType feedbackType = new FeedbackType();
		BeanUtils.copyProperties(feedbackTypeReqDto, feedbackType);
		return feedbackTypeRepository.save(feedbackType);

	}

}
