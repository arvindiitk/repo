package com.ng.feedback.response;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.feedback.constants.Constants;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Entity
public class FeedbackCategoryResDto implements Serializable {

	private static final long serialVersionUID = -3485037871213959912L;

	@Id
	@Column(name = "FEEDBACK_CATEGORY_ID")
	private Integer feedbackCategoryId;

	@Column(name = "FEEDBACK_CATEGORY")
	private String feedbackCate;

	@Column(name = "CREATED_BY")
	private Integer createdBy;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT)
	@Column(name = "CREATED_ON")
	private Timestamp createdOn;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;

	@Column(name = "USER_NAME")
	private String createdByName;
}
