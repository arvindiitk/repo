package com.ng.feedback.service;

import java.util.List;
import java.util.Optional;

import com.ng.feedback.entity.Feedback;
import com.ng.feedback.exception.ResourceNotFoundException;
import com.ng.feedback.request.FeedbackFilterReqDto;
import com.ng.feedback.request.FeedbackReqDto;
import com.ng.feedback.response.FeedbackResDto;

public interface FeedbackService {
	
	public List<FeedbackResDto> findAll() throws ResourceNotFoundException;
	
	public Feedback saveOrUpdate(FeedbackReqDto feedbackReqDto);

	public Optional<Feedback> findById(Integer id) throws ResourceNotFoundException;

	public List<FeedbackResDto> findAllByFilters(FeedbackFilterReqDto req) throws ResourceNotFoundException;

}
