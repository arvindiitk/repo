package com.ng.feedback.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.feedback.entity.FeedbackCategory;
import com.ng.feedback.entity.FeedbackSubModule;
import com.ng.feedback.exception.ResourceNotFoundException;
import com.ng.feedback.repository.FeedbackCategoryRepository;
import com.ng.feedback.repository.FeedbackSubModuleRepository;
import com.ng.feedback.request.FeedbackSubModuleReqDto;
import com.ng.feedback.service.FeedbackSubModuleService;

@Service
public class FeedbackSubModuleServiceImpl implements FeedbackSubModuleService {

	@Autowired
	private FeedbackSubModuleRepository feedbackSubModuleRepository;
	
	@Autowired
	private FeedbackCategoryRepository feedbackCategoryRepository;


	@Override
	public List<FeedbackSubModule> findAll() {
		return feedbackSubModuleRepository.findAll();
	}

	@Override
	@Transactional
	public FeedbackSubModule saveOrUpdate(FeedbackSubModuleReqDto feedbackSubModuleReqDto) {
		FeedbackSubModule feedbackSubModule=new FeedbackSubModule();
		BeanUtils.copyProperties(feedbackSubModuleReqDto, feedbackSubModule);
		return feedbackSubModuleRepository.save(feedbackSubModule);

	}

	@Override
	public List<FeedbackSubModule> findAllByFeedbackModuleId(Integer feedbackModuleId) throws ResourceNotFoundException  {
		List<FeedbackSubModule> feedbackSubModule = feedbackSubModuleRepository.findAllByFeedbackModuleId(feedbackModuleId);
		FeedbackCategory feedbackCategory = new FeedbackCategory();
				
		for(FeedbackSubModule subModule : feedbackSubModule) {
			feedbackCategory = feedbackCategoryRepository.findById(subModule.getFeedbackModuleId()).orElseThrow(() -> new ResourceNotFoundException("Invalid FeedbackCate id"));
			subModule.setFeedbackModule(feedbackCategory.getFeedbackCate());
		}
		
		return feedbackSubModule;
	}

}
