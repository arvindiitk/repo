package com.ng.feedback.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ng.feedback.response.FeedbackCategoryResDto;

@Repository
public interface FeedbackCategoryResRepository extends JpaRepository<FeedbackCategoryResDto, Integer> {

	@Query(value = "select feedbackCat.FEEDBACK_CATEGORY_ID,feedbackCat.FEEDBACK_CATEGORY,feedbackCat.CREATED_BY,muser.USER_NAME  ,feedbackCat.CREATED_ON,feedbackCat.IS_ACTIVE "
			+ " from FEEDBACK_CATEGORY feedbackCat "
			+ " INNER JOIN M_USER muser on  muser.USER_ID=feedbackCat.CREATED_BY AND muser.IS_ACTIVE='true' ", nativeQuery = true)

	public List<FeedbackCategoryResDto> findAllFeedbackCategory();
}
