package com.ng.feedback.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.feedback.constants.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Valid
@Entity
@Table(name = "FEEDBACK")
public class Feedback implements Serializable {

	private static final long serialVersionUID = 3754628787538427335L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FEEDBACK_ID", unique = true, nullable = false)
	private Integer feedbackId;

	@Column(name = "TYPE_ID", unique = true, nullable = false)
	private Integer typeId;

	@Transient
	private String feedbackType;

	@Column(name = "CATEGORY_ID", unique = true, nullable = false)
	private Integer categoryId;

	@Transient
	private String subModule;
	
	@Column(name = "SUB_MODULE_ID", unique = true, nullable = false)
	private Integer subModuleId;

	@Transient
	private String category;

	@Column(name = "SUBJECT", nullable = false)
	private String subject;

	@Column(name = "DESCRIPTION", nullable = false)
	private String desccription;

	@Column(name = "CREATED_BY", nullable = false)
	private Integer createdBy;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	@Column(name = "CREATED_ON", nullable = false, updatable = false)
	private Timestamp createdOn;


//	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
//	@Column(name = "UPDATED_ON", updatable = false)
//	private Timestamp updatedOn;

	@Column(name = "IS_READ")
	private Boolean isRead;

	@Column(name = "READ_BY")
	private Integer readBy;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	@Column(name = "READ_ON", nullable = false, updatable = false)
	private Timestamp readAt;

	@Column(name = "FEEDBACK_RESPONSE")
	private String feedbackRes;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT, timezone = "GMT+5:30")
	@Column(name = "RESPONSE_ON", updatable = false)
	private Timestamp responseOn;
	
	@Column(name = "RESPONSE_By")
	private Integer responseBy;

	@Column(name = "ua_id")
	private Integer uaId;
	
}