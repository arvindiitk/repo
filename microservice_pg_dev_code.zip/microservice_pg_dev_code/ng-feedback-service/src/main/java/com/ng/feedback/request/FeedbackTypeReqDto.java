package com.ng.feedback.request;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Data
@Getter
@Setter
public class FeedbackTypeReqDto implements Serializable {
	
	private static final long serialVersionUID = -3485037871213959912L;

	private Integer feedbackTypeId;
	
	@NotBlank(message="Feedback Type Name cannot be blank")
	@Size(min=1, max=80, message="Feedback Type Name field length must be 1-80 characters")
	private String feedbackTypeName;

	private Integer createdBy;

	private Boolean isActive;
}
