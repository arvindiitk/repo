package com.ng.feedback.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.feedback.entity.Feedback;
import com.ng.feedback.entity.FeedbackCategory;
import com.ng.feedback.entity.FeedbackSubModule;
import com.ng.feedback.entity.FeedbackType;
import com.ng.feedback.exception.ResourceNotFoundException;
import com.ng.feedback.repository.FeedbackCategoryRepository;
import com.ng.feedback.repository.FeedbackRepository;
import com.ng.feedback.repository.FeedbackResRepository;
import com.ng.feedback.repository.FeedbackSubModuleRepository;
import com.ng.feedback.repository.FeedbackTypeRepository;
import com.ng.feedback.request.FeedbackFilterReqDto;
import com.ng.feedback.request.FeedbackReqDto;
import com.ng.feedback.response.FeedbackResDto;
import com.ng.feedback.service.FeedbackService;

@Service
@Transactional
public class FeedbackServiceImpl implements FeedbackService {

	@Autowired
	private FeedbackRepository feedbackRepository;

	@Autowired
	private FeedbackTypeRepository feedbackTypeRepository;

	@Autowired
	private FeedbackCategoryRepository feedbackCategoryRepository;
	
	@Autowired
	private FeedbackResRepository feedbackResRepository;
	
	@Autowired
	private FeedbackSubModuleRepository feedbackSubModuleRepository;

	@Override
	public List<FeedbackResDto> findAll() throws ResourceNotFoundException {
	
		return feedbackResRepository.findAllFeedback();
	}
	
	@Override
	public List<FeedbackResDto> findAllByFilters(FeedbackFilterReqDto req) throws ResourceNotFoundException {
		
		List<FeedbackResDto> feedbackListFilter = feedbackResRepository.findAllFeedback();

		if (req.getFromDate() != null) {
			feedbackListFilter = feedbackResRepository.findAllFeedbackFilterDate(req.getFromDate(), req.getToDate());
		}
			
		if (req.getModule() != null && !req.getModule().equals("")) {
			feedbackListFilter = feedbackListFilter.stream()
					.filter(e -> e.getFeedbackCateoryName().equals(req.getModule()))
					.collect(Collectors.toList());

		} 
		if (req.getSubModule() != null && !req.getSubModule().equals("")) {
			feedbackListFilter = feedbackListFilter.stream()
					.filter(e -> e.getSubModuleName().equals(req.getSubModule()))
					.collect(Collectors.toList());
			
		} 
		if (req.getFeedbackType() != null && !req.getFeedbackType().equals("")) {
			feedbackListFilter = feedbackListFilter.stream()
					.filter(e -> e.getFeedbackTypeName().equals(req.getFeedbackType()))
					.collect(Collectors.toList());
		}
		if (req.getUaId() != null && !req.getUaId().equals("")) {
			feedbackListFilter = feedbackListFilter.stream()
					.filter(e -> e.getOrgId().equals(req.getUaId()))
					.collect(Collectors.toList());
		}

		return feedbackListFilter;
	}
	

	@Override
	public Feedback saveOrUpdate(FeedbackReqDto feedbackDto) {
		Feedback feedback = new Feedback();
		BeanUtils.copyProperties(feedbackDto, feedback);
		return feedbackRepository.save(feedback);

	}

	@Override
	public Optional<Feedback> findById(Integer id) throws ResourceNotFoundException {
		Optional<Feedback> feedback = feedbackRepository.findById(id);
		if (!feedback.isEmpty()) {
			FeedbackType feedbackType = feedbackTypeRepository.findById(feedback.get().getTypeId())
					.orElseThrow(() -> new ResourceNotFoundException("Invalid FeedbackType id"));
			FeedbackCategory feedbackCategory = feedbackCategoryRepository.findById(feedback.get().getCategoryId())
					.orElseThrow(() -> new ResourceNotFoundException("Invalid FeedbackCate id"));
			FeedbackSubModule feedbackSubModule = feedbackSubModuleRepository.findById(feedback.get().getSubModuleId())
					.orElseThrow(() -> new ResourceNotFoundException("Invalid FeedbackSubModule id"));
			feedback.get().setFeedbackType(feedbackType.getFeedbackTypeName());
			feedback.get().setCategory(feedbackCategory.getFeedbackCate());
			feedback.get().setSubModule(feedbackSubModule.getFeedbackSubModule());
		}
		return feedback;

	}
}
