package com.ng.feedback.request;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Data
@Getter
@Setter
public class FeedbackSubModuleReqDto implements Serializable {

	private static final long serialVersionUID = -3485037871213959912L;

	private Integer feedbackSubModuleId;

	@NotBlank(message="Feedback SubModule cannot be blank")
	@Size(min=1, max=100, message="Feedback SubModule field length must be 1-100 characters")
	private String feedbackSubModule;

	private Integer createdBy;

	private Boolean isActive;
	
	private Integer feedbackModuleId;
}
