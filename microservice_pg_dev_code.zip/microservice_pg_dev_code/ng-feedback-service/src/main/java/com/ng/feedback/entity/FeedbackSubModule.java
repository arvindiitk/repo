package com.ng.feedback.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.feedback.constants.Constants;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Entity
@Table(name="FEEDBACK_SUB_MODULE")
public class FeedbackSubModule implements Serializable {

	private static final long serialVersionUID = -6494745982813085171L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="FEEDBACK_SUB_MODULE_ID")
	private Integer feedbackSubModuleId;
	
	@Column(name="FEEDBACK_SUB_MODULE")
	private String feedbackSubModule;
	
	@Column(name="FEEDBACK_MODULE_ID", nullable=false)
	private Integer feedbackModuleId;
	
	@Transient
	private String feedbackModule;	

	@Column(name="CREATED_BY", nullable=false,updatable = false)
	private Integer createdBy;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT)
	@Column(name="CREATED_ON", nullable=false,updatable = false)
	private Timestamp createdOn;

	@Column(name="IS_ACTIVE", nullable=false,columnDefinition = "default bit 1")
	private Boolean isActive;
}
