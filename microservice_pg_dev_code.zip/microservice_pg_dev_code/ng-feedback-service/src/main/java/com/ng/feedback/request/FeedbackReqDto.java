package com.ng.feedback.request;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class FeedbackReqDto implements Serializable {
	
	private static final long serialVersionUID = -3610223066039089361L;

	private Integer feedbackId;

	private Integer typeId;

	private Integer categoryId;
	
	private Integer subModuleId;

	@Size(max=200, message="Subject field length must be less than 200 characters")
	private String subject;

	@NotBlank(message="Description cannot be blank")
	private String desccription;

	private Integer createdBy;

	private Integer updatedBy;

	private Boolean isRead;

	private String readBy;

	private Timestamp readAt;

	private String feedbackRes;

	private Timestamp responseOn;
	
	private Integer uaId;

}
