package com.ng.feedback.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ng.feedback.response.FeedbackTypeResDto;

@Repository
public interface FeedbackTypeResRepository extends JpaRepository<FeedbackTypeResDto, Integer> {

	@Query(value = "select feedbackType.FEEDBACK_TYPE_ID,feedbackType.FEEDBACK_TYPE_NAME,feedbackType.CREATED_BY,muser.USER_NAME  ,feedbackType.CREATED_ON,feedbackType.IS_ACTIVE "
			+ " from FEEDBACK_TYPE feedbackType "
			+ " INNER JOIN M_USER muser on  muser.USER_ID=feedbackType.CREATED_BY AND muser.IS_ACTIVE='true' ", nativeQuery = true)

	public List<FeedbackTypeResDto> findAllFeedbackType();

}
