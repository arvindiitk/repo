package com.ng.keycloak.service.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.ng.keycloak.request.CreateUserDTO;
import com.ng.keycloak.request.ResponseApi;
import com.ng.keycloak.request.SMSRequestDto;
import com.ng.keycloak.request.UpdateUserPassDTO;
import com.ng.keycloak.request.UpdateUserPasswordKeycloakDto;
import com.ng.keycloak.service.KeyCloakAPIRequest;

@Service
public class KeyCloakAPIRequestImpl implements KeyCloakAPIRequest {

	private RestTemplate restTemplate = new RestTemplate();

	@Override
	public String masterTokenKeyCloakAPI(String clientAdminId, String clientAdminSecret, String keycloakClientGrantType,
			String url) {
		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add("client_id", clientAdminId);
		map.add("client_secret", clientAdminSecret);
		map.add("grant_type", keycloakClientGrantType);

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(map, null);
		ResponseApi response = restTemplate.postForObject(url, request, ResponseApi.class);
		String accessToken = "";
		if (response != null) {
			accessToken = response.getAccess_token();
		}
		return accessToken;
	}

	@Override
	public ResponseApi userTokenKeyCloakAPI(String clientSecret, String username, String grantType,	String url) {
		
		MultiValueMap<String, String> kmap = new LinkedMultiValueMap<>();
		kmap.add("client_id", "springboot-auth");
		kmap.add("client_secret", clientSecret);
		kmap.add("grant_type", grantType);
		kmap.add("username", username);
		
		HttpEntity<MultiValueMap<String, String>> krequest = new HttpEntity<>(kmap, null);
		ResponseApi responseApi = restTemplate.postForObject(url, krequest, ResponseApi.class);
		return responseApi;
	}

	@Override
	public ResponseEntity<String> createUserRestTemplate(CreateUserDTO createUserDTO, String accessToken, String url) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + accessToken);
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<CreateUserDTO> entity = new HttpEntity<>(createUserDTO, headers);
		return restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
	}

	@Override
	public ResponseEntity<String> restTemplateToAD(CreateUserDTO createUserDTO,String url) {
		HttpHeaders headers = new HttpHeaders();
		
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<CreateUserDTO> entity = new HttpEntity<>(createUserDTO, headers);
		return restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
	}
	@Override
	public ResponseEntity<String> restTemplateToAD(UpdateUserPassDTO updateUserPassDTO,String url) {
		HttpHeaders headers = new HttpHeaders();
		
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<UpdateUserPassDTO> entity = new HttpEntity<>(updateUserPassDTO, headers);
		return  restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
	}
	
	@Override
	public String updatePasswordRestTemplate(String accessToken, String newpassword, String url) {
		try {
			UpdateUserPasswordKeycloakDto userpss = new UpdateUserPasswordKeycloakDto();
			userpss.setType("password");
			userpss.setTemporary(false);
			userpss.setValue(newpassword);

			MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
			headers.add("Authorization", "Bearer " + accessToken);
			HttpEntity<Object> httpEntity = new HttpEntity<>(userpss, headers);
			restTemplate.put(url, httpEntity, ResponseApi.class);
			return "SUCCESS";
		} catch (Exception e) {
			return "FAILED";
		}
	}

	@Override
	public String getAllUsers(String accessToken, String username, String password, String url) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + accessToken);
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(null, headers);
		ResponseEntity<Object[]> resp = restTemplate.exchange(url, HttpMethod.GET, entity, Object[].class);
		Object[] obj = resp.getBody();
		for (Object object : obj) {

			Map map = (LinkedHashMap) object;
			if ((map.get("username").toString()).equalsIgnoreCase(username))
				return map.get("id").toString();
		}
		return null;
	}

	@Override
	public ResponseEntity<String> restTemplateToSendOtp(List smsRequestDto,String url) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<List> entity = new HttpEntity<>(smsRequestDto, headers);
		return restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
	}
	
	@Override
	public Integer generateOTP(int length) {  
	    String numbers = "0123456789";  
	    Random rndm_method = new Random();  
	    char[] otp = new char[length];  
	    for (int i = 0; i < length; i++) {  
	        otp[i] = numbers.charAt(rndm_method.nextInt(numbers.length()));  
	    }  
	    return Integer.parseInt(new String(otp)); 
	}  
}
