package com.ng.keycloak.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class Attributes {
	@JsonProperty("id")
    String[] LDAP_ENTRY_DN;
	@JsonProperty("username")
    String[] createTimestamp;
}
