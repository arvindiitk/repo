package com.ng.keycloak.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@ToString
public class ResponseApi {
	String access_token;
	String expires_in;
	String refresh_token;
	String token_type;
	String session_state;
}
