package com.ng.keycloak.service.impl;

import java.security.SecureRandom;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.keycloak.model.entity.MUser;
import com.ng.keycloak.model.entity.TemplateIdMobileNo;
import com.ng.keycloak.repository.OrgUserRepo;
import com.ng.keycloak.repository.UserOtpDetailsRepo;
import com.ng.keycloak.service.UserLoginOTP;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class UserLoginOTPImpl implements UserLoginOTP {

	@Autowired
	private OrgUserRepo orgUserRepo;
	
	@Autowired
	private UserOtpDetailsRepo userOtpDetailsRepo;

	@Override
	public List<MUser> findByLoginId(String userName, String roleAlias) {
		if(roleAlias !=null && !"".equalsIgnoreCase(roleAlias)) {
			return orgUserRepo.findAdminById(userName, roleAlias);
		} else {
			return orgUserRepo.findByLoginId(userName);
		}
		
	}

	@Override
	public void updateIsPAsswordFlag(String loginId, Boolean isPasswordFlag) {
		orgUserRepo.updateIsPAsswordFlag(loginId, isPasswordFlag);
		
	}
	
	@Override
	public void sendOtp(String loginId, Integer otp) {
		userOtpDetailsRepo.insertOtp(loginId, otp);
		
	}

	
	@Override
	public TemplateIdMobileNo getTemplateIdMobileNo(String userId) {
		return userOtpDetailsRepo.getTemplateIdMobileNo(userId);
		
	}
	
	@Override
	public Optional<String> validateOTP(Integer login_otp,String userId) {
		return userOtpDetailsRepo.validateOTP(login_otp,userId);
		
	}
}
