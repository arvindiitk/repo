package com.ng.keycloak.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ng.keycloak.model.entity.MUser;



@Repository
public interface OrgUserRepo extends JpaRepository<MUser, Integer> {

	
	@Query(value = "SELECT DISTINCT usr.* from M_USER usr "
			+ "INNER JOIN M_USER_ORG userOrg ON (usr.USER_ID=userOrg.USER_ID AND userOrg.IS_ACTIVE='true' ) "
			+ "INNER JOIN M_ORG org ON (org.ORG_ID=userOrg.ORG_ID AND org.IS_ACTIVE='true' ) "
			+ "INNER JOIN M_ORG_ROLE orgRole ON (org.ORG_ID = orgRole.ORG_ID AND orgRole.IS_ACTIVE='true') "
			+ "INNER JOIN M_ROLE mRole ON mRole.ROLE_ID=orgRole.ROLE_ID "			
			+ "WHERE USER_LOGIN_ID=:loginId AND usr.IS_ACTIVE='true' AND mRole.ROLE_ALIAS !='NGADM' ", nativeQuery = true)
	List<MUser> findByLoginId(String loginId);
	
	@Query(value = "SELECT DISTINCT usr.* from M_USER usr "
			+ "INNER JOIN M_USER_ORG userOrg ON (usr.USER_ID=userOrg.USER_ID AND userOrg.IS_ACTIVE='true' ) "
			+ "INNER JOIN M_ORG org ON (org.ORG_ID=userOrg.ORG_ID AND org.IS_ACTIVE='true' ) "
			+ "INNER JOIN M_ORG_ROLE orgRole ON (org.ORG_ID = orgRole.ORG_ID AND orgRole.IS_ACTIVE='true') "
			+ "INNER JOIN M_ROLE mRole ON mRole.ROLE_ID=orgRole.ROLE_ID "			
			+ "WHERE USER_LOGIN_ID=:loginId AND usr.IS_ACTIVE='true' AND mRole.ROLE_ALIAS=:roleAlias ", nativeQuery = true)
	List<MUser> findAdminById(String loginId, String roleAlias);

    @Transactional
    @Modifying
	@Query(value = "UPDATE  M_USER SET CAPTCHA =?2 WHERE USER_LOGIN_ID =?1", nativeQuery = true)
	void insertCaptcha(String loginId, String captcha);
    
    @Transactional
    @Modifying
	@Query(value = "UPDATE  M_USER SET IS_PASSWORD_FLAG =?2 WHERE USER_LOGIN_ID =?1", nativeQuery = true)
	void updateIsPAsswordFlag(String loginId, Boolean isPasswordFlag);

}
