package com.ng.keycloak.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ng.keycloak.request.CreateUserDTO;
import com.ng.keycloak.request.ResponseApi;
import com.ng.keycloak.request.UpdateUserPassDTO;

@Service
public interface KeyCloakAPIRequest<T> {
	
	public String masterTokenKeyCloakAPI(String clientAdminId,String clientAdminSecret,String keycloakClientGrantType,String url);
	public ResponseApi userTokenKeyCloakAPI(String clientSecret, String username, String grantType,String url);
	public ResponseEntity<String> createUserRestTemplate(CreateUserDTO createUserDTO,String accessToken,String url);
	public String updatePasswordRestTemplate(String accessToken,String newpassword,String url);
	public String getAllUsers(String accessToken,String username,String password,String url);
	public ResponseEntity<String> restTemplateToAD(CreateUserDTO createUserDTO, String url);
	public ResponseEntity<String> restTemplateToAD(UpdateUserPassDTO updateUserPassDTO, String url);
	public ResponseEntity<String> restTemplateToSendOtp(List cloakReqType, String url);
	public Integer generateOTP(int length);

}
