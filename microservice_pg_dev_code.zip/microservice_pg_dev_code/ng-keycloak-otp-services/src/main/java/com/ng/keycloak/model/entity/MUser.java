package com.ng.keycloak.model.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;
import lombok.ToString;

/**
 * The persistent class for the M_USER database table.
 * 
 */
@Data
@ToString
@Entity
@Table(name="M_USER")
public class MUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="USER_ID", unique=true, nullable=false)
	private Integer userId;

	@Column(name="CREATED_BY", nullable=false,updatable = false)
	private Integer createdBy;

	@CreationTimestamp
	@Column(name="CREATED_ON", nullable=false,updatable = false)
	private Timestamp createdOn;

	@Column(name="IS_ACTIVE", nullable=false)
	private Boolean isActive;

	@Column(name="USER_ADDRESS")
	private String userAddress;

	@Column(name="USER_CONTACT_NO")
	private Long userContactNo;

	@Column(name="USER_EMAIL_ID")
	private String userEmailId;

	@Column(name="USER_LOGIN_ID", nullable=false)
	private String userLoginId;

}