package com.ng.keycloak.request;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class SMSRequestDto {
	String contactNo;
	String desc;
	String templateId;
}
