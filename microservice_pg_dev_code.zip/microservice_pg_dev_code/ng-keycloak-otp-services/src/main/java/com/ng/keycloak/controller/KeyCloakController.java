package com.ng.keycloak.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ng.keycloak.exception.InvalidTokenException;
import com.ng.keycloak.model.entity.MUser;
import com.ng.keycloak.model.entity.TemplateIdMobileNo;
import com.ng.keycloak.request.CreateUserDTO;
import com.ng.keycloak.request.KeyCloakReqType;
import com.ng.keycloak.request.ResponseApi;
import com.ng.keycloak.request.SMSRequestDto;
import com.ng.keycloak.request.UpdateUserPassDTO;
import com.ng.keycloak.response.ApiResponse;
import com.ng.keycloak.service.UserLoginOTP;
import com.ng.keycloak.service.JwtTokenValidatorService;
import com.ng.keycloak.service.KeyCloakAPIRequest;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/ng-keyCloak-otp")
@Transactional(timeout = 180)
public class KeyCloakController {

	@Value("${keycloak.token-uri}")
	private String keycloakToken;

	@Value("${keycloak.client-id}")
	private String clientId;

	@Value("${keycloak.client-secret}")
	private String clientSecret;

	@Value("${keycloak.authorization-grant-type}")
	private String grantType;

	@Value("${keycloak.client.grant-type}")
	private String keycloakClientGrantType;

	@Value("${keycloak.admin.client-id}")
	private String clientAdminId;

	@Value("${keycloak.admin.client-secret}")
	private String clientAdminSecret;

	@Value("${keycloak.admin.token-uri}")
	private String keycloakAdminTokenUri;

	@Value("${keycloak.create-updatepassword-user-uri}")
	private String keycloakCreateUpdatePasswordUserUri;

	
	@Value("${keycloak.create-updatepassword-masteruser-uri}")
	private String keycloakCreateUpdatePasswordMasteruserUri;
	
	
	@Value("${keycloak.create-updatepassword-master-uri}")
	private String keycloakUpdatePasswordMasteruserUri;
	
	private RestTemplate restTemplate = new RestTemplate();

	@Autowired
	private UserLoginOTP userLoginOTP;
	
	@Autowired
	private KeyCloakAPIRequest keyCloakAPIRequest;

	@Autowired
	private JwtTokenValidatorService jwtTokenValidatorService;

	@Value("${keycloak.ad-uri}")
	private String keycloakToADURI;
	
	@Value("${DN_PRINCIPAL}")
	private String dn_principal;
	
	
	@Value("${SMS_URL}")
	private String sms_url;
	
	
	@PostMapping(value = "keyCloak/ng-createUser", consumes = { "application/json" })
	public ResponseEntity<Object> createUserUsingToken(@RequestBody CreateUserDTO createUserDTO) {
		
		log.info("OrgTypesController: createOrgTypes ng-saveUpdateOrgTypes response");
		com.ng.keycloak.response.ApiResponse<?> apiResponse = null;
		ResponseEntity<String> responseAPI = keyCloakAPIRequest.restTemplateToAD(createUserDTO,keycloakToADURI+"/ng-keyCloak-type/keyCloak/ng-createUser");
		apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(com.ng.keycloak.constants.Constants.SUCCESS).data(responseAPI).build();
		log.info("OrgTypesController: createOrgTypes ng-saveUpdateOrgTypes response");
		return ResponseEntity.ok().body(apiResponse);
	}

	

	@PostMapping(value = "keyCloak/ng-updateUserPasswod", consumes = { "application/json" })
	public ResponseEntity<Object> updateUserPasswod(@RequestBody UpdateUserPassDTO updateUserPassDTO)
			throws InvalidTokenException {
		log.info("OrgTypesController: updateUserPasswod ng-updateUserPasswod response");
		String username=updateUserPassDTO.getUsername();
		
		updateUserPassDTO.setUsername(updateUserPassDTO.getUsername());
		ResponseEntity<String> responseAPI = keyCloakAPIRequest.restTemplateToAD(updateUserPassDTO,keycloakToADURI+"/ng-keyCloak-type/keyCloak/ng-updatePassword");
		String resp=responseAPI.getBody();
		if(resp.equals("SUCCESS")) {
			ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(com.ng.keycloak.constants.Constants.SUCCESS).data("Password Updated").build();
			if(apiResponse.getErrors()==null)
			{
				userLoginOTP.updateIsPAsswordFlag(username,updateUserPassDTO.getIsPasswordFlag());
			}
			return ResponseEntity.ok().body(apiResponse);
		} else {
			ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.message(com.ng.keycloak.constants.Constants.ERROR).data("Password Update failed !!").build();
			return ResponseEntity.ok().body(apiResponse);
		}
	}
	
	@PostMapping(value = "keyCloak/ng-deActivateUser", consumes = { "application/json" })
	public ResponseEntity<Object> deActivateUser(@RequestBody UpdateUserPassDTO updateUserPassDTO)
			throws InvalidTokenException {
		log.info("OrgTypesController: updateUserPasswod ng-updateUserPasswod response");
		String username=updateUserPassDTO.getUsername();
		
		updateUserPassDTO.setUsername(updateUserPassDTO.getUsername());
		ResponseEntity<String> responseAPI = keyCloakAPIRequest.restTemplateToAD(updateUserPassDTO,keycloakToADURI+"keyCloak/ng-deActivateUser");
		String resp=responseAPI.getBody();
		if(resp.equals("SUCCESS")) {
			ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(com.ng.keycloak.constants.Constants.SUCCESS).data("Password Updated").build();
			if(apiResponse.getErrors()==null)
			{
				userLoginOTP.updateIsPAsswordFlag(username,updateUserPassDTO.getIsPasswordFlag());
			}
			return ResponseEntity.ok().body(apiResponse);
		} else {
			ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.message(com.ng.keycloak.constants.Constants.ERROR).data("Password Update failed !!").build();
			return ResponseEntity.ok().body(apiResponse);
		}
	}
	
	@PostMapping(value = "keyCloak/ng-sendOtp", consumes = { "application/json" })
	public ResponseEntity<Object> createSendOtp(@RequestBody KeyCloakReqType cloakReqType) {
		log.info("OrgTypesController: createOrgTypes ng-saveUpdateOrgTypes response");
		Integer otp = keyCloakAPIRequest.generateOTP(6);
		List<MUser> list = userLoginOTP.findByLoginId(cloakReqType.getUsername(), cloakReqType.getRoleAlias());
		
		com.ng.keycloak.response.ApiResponse<?> apiResponse = null;
		if(list.isEmpty()) {
			apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.errors(com.ng.keycloak.constants.Constants.userNotExists)
					.message("User does not exists. Please contract to Administrator !!")
					.build();
		} else {
			// insert otp data in database
			userLoginOTP.sendOtp(cloakReqType.getUsername(), otp);
			
			TemplateIdMobileNo templateIdMobileNo = userLoginOTP.getTemplateIdMobileNo(cloakReqType.getUsername());
			
			SMSRequestDto smsRequestDto =new SMSRequestDto();
			
			List smsRequestDtoList = new ArrayList<SMSRequestDto>();
			
			smsRequestDtoList.add(smsRequestDto);
			
			smsRequestDto.setContactNo(templateIdMobileNo.getMobileNo());
			smsRequestDto.setDesc(templateIdMobileNo.getNotifContent().replace("<<Login/Password Reset/Forgot Password>>","Login").replace("<<OTP>>", ""+otp));
			smsRequestDto.setTemplateId(templateIdMobileNo.getTemplateId());
			
			
			ResponseEntity<String> responseAPI = keyCloakAPIRequest.restTemplateToSendOtp(smsRequestDtoList,sms_url);
			String resp=responseAPI.getBody();
			apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(com.ng.keycloak.constants.Constants.SUCCESS).data(smsRequestDto).build();
		}
		log.info("OrgTypesController: createOrgTypes ng-saveUpdateOrgTypes response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "keyCloak/ng-keyCloak", consumes = { "application/json" })
	public ResponseEntity<Object> getTokenWithoutPassword(@RequestBody KeyCloakReqType cloakReqType) {
		
		com.ng.keycloak.response.ApiResponse<?> apiResponse = null;
		Optional<String> otpValue = userLoginOTP.validateOTP(cloakReqType.getOtp(), cloakReqType.getUsername());
		
		if (otpValue.isEmpty()) {
			apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.errors(com.ng.keycloak.constants.Constants.otp_inValid)
					.message("The provided OTP has either expired or is invalid")
					.build();
			return ResponseEntity.ok().body(apiResponse);
		}
		
		try {
			ResponseApi response = keyCloakAPIRequest.userTokenKeyCloakAPI(clientSecret, cloakReqType.getUsername(),keycloakClientGrantType,keycloakToken);
			apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.message(com.ng.keycloak.constants.Constants.SUCCESS).data(response).build();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("message ===>>> "+e.getMessage());
			apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.message(com.ng.keycloak.constants.Constants.NOT_FOUND).data("Password is incorrect OR KeyCloak API is down !! ").build();
		}

		log.info("OrgTypesController: createOrgTypes ng-saveUpdateOrgTypes response");

		return ResponseEntity.ok().body(apiResponse);

	}
	
	@PostMapping(value = "keyCloak/ng-tokenSudarshan", consumes = { "application/json" })
	public ResponseEntity<Object> getTokenWithoutPasswordSudharsan(@RequestBody KeyCloakReqType cloakReqType) {
		
		com.ng.keycloak.response.ApiResponse<?> apiResponse = null;
		
		try {
			ResponseApi response = keyCloakAPIRequest.userTokenKeyCloakAPI(clientSecret, cloakReqType.getUsername(),keycloakClientGrantType,keycloakToken);
			apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.message(com.ng.keycloak.constants.Constants.SUCCESS).data(response).build();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("message ===>>> "+e.getMessage());
			apiResponse = com.ng.keycloak.response.ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
					.message(com.ng.keycloak.constants.Constants.NOT_FOUND).data("Password is incorrect OR KeyCloak API is down !! ").build();
		}

		return ResponseEntity.ok().body(apiResponse);

	}
	
}
