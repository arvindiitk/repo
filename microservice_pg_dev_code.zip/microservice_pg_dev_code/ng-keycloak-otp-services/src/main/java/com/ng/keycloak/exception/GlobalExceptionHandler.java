package com.ng.keycloak.exception;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.ng.keycloak.constants.Constants;
import com.ng.keycloak.response.ApiResponse;
import com.ng.keycloak.response.ValidationResponse;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Object> resourceNotFoundException(ResourceNotFoundException ex, WebRequest request) {
    	ApiResponse<?> errorResponse = ApiResponse.builder()
                .status(String.valueOf(HttpStatus.NOT_FOUND))
                .message(ex.getMessage())
                .errors(Arrays.asList(ex.getLocalizedMessage()))
                .build();
        log.error("[CustomErrorHandler.handleAllExceptions] : error response {}", errorResponse);
        
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({ Exception.class, RuntimeException.class })
	public ResponseEntity<Object> globleExcpetionHandler(Exception ex, WebRequest request) {
		ApiResponse<?> errorResponse = null;
		if(ex.getMessage().contains("Required request body is missing")) {
			errorResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_REQUEST))
					.message("Required request body is missing").errors(Arrays.asList(ex.getLocalizedMessage())).build();
		}else if(ex.getMessage().contains("DateTimeParseException")) {
			errorResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.BAD_REQUEST))
					.message("Incorrect date format").errors(Arrays.asList(ex.getLocalizedMessage())).build();
		}else {
		errorResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR))
				.message(ex.getMessage()).errors(Arrays.asList(ex.getLocalizedMessage())).build();
		log.error("[GlobalExceptionHandler.globleExcpetionHandler] : error response {}", errorResponse);
		}
		return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
    
    @ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Object> handleValidationExceptions(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getAllErrors().forEach(error -> {
			String fieldName = ((FieldError) error).getField();
			String errorMessage = error.getDefaultMessage();
			errors.put(fieldName, errorMessage);
		});

		ValidationResponse<?> errorResponse = ValidationResponse.builder()
				.status(String.valueOf(HttpStatus.BAD_REQUEST)).message("Validation failed for argument(s)")
				.errors(errors).build();
		log.error("[GlobalExceptionHandler:handleValidationExceptions] : error response {}", errorResponse);
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}
    
    @ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<Object> dataIntegrityViolationException(DataIntegrityViolationException ex) throws NullPointerException {
		Throwable cause = ex.getRootCause();
		ApiResponse<?> errorResponse = null;
		if (cause instanceof ConstraintViolationException) {
			ConstraintViolationException causeConstraint = (ConstraintViolationException) cause;
			errorResponse = ApiResponse.builder().status(Constants.CONSTRAINT_SQL_ERROR)
					.message(Constants.E002627).errors(Arrays.asList(causeConstraint.getMessage())).build();
			log.error("[GlobalExceptionHandler.constraintViolationException] : error response {}", errorResponse);
			return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
		}
		else if(cause!=null && cause.getMessage().contains("duplicate key value violates unique constraint")) {
			errorResponse = ApiResponse.builder().status(Constants.UNIQUE_KEY_CONSTRAINT_ERROR).message(Constants.E002629)
					.errors(Arrays.asList(cause.getMessage())).build();
			log.error("[GlobalExceptionHandler.dataIntegrityViolationException] : error response {}", errorResponse);
			return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
		}
		errorResponse = ApiResponse.builder().status(Constants.SQL_ERROR).message(Constants.E002628)
				.errors(Arrays.asList(cause!=null ? cause.getMessage() : Constants.E002628)).build();
		log.error("[GlobalExceptionHandler.dataIntegrityViolationException] : error response {}", errorResponse);
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}
}