package com.ng.keycloak.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ng.keycloak.model.entity.MUser;
import com.ng.keycloak.model.entity.TemplateIdMobileNo;

@Service
public interface UserLoginOTP {
	
	public void updateIsPAsswordFlag(String userName, Boolean isPasswordFlag);
	
	public List<MUser> findByLoginId(String userName, String roleAlias);

	public void sendOtp(String loginId, Integer otp);

	public TemplateIdMobileNo getTemplateIdMobileNo(String userId);
	
	public Optional<String> validateOTP(Integer login_otp,String userId);
}
