package com.ng.keycloak.model.entity;

public interface TemplateIdMobileNo {
	public String getTemplateId();

	public String getMobileNo();
	
	public String getNotifContent();
	



}