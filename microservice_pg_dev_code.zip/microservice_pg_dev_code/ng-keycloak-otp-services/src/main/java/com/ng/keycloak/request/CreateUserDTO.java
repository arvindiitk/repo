package com.ng.keycloak.request;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CreateUserDTO implements Serializable{
	private static final long serialVersionUID = 1L;

	private String username;
	private String firstName;
	private String lastName;
	private String email;
	private Boolean enabled;
	private Boolean emailVerified;
	private List<CredentialDTO> credentials;
	
	private List<String> requiredActions;
	


      
}
