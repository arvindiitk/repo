package com.ng.keycloak.repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ng.keycloak.model.entity.TemplateIdMobileNo;
import com.ng.keycloak.model.entity.UserOtpDetails;

@Repository
public interface UserOtpDetailsRepo extends JpaRepository<UserOtpDetails, Integer> {

	@Transactional
	@Modifying
	@Query(value = "INSERT INTO ng_cmp.user_otp_details (user_id, login_otp) VALUES (:user_id, :login_otp) "
			+ "	ON CONFLICT (user_id) DO UPDATE SET login_otp = :login_otp, created_on = localtimestamp;", nativeQuery = true)
	void insertOtp(String user_id, Integer login_otp);
	
	@Query(value = "SELECT template_id as templateId, user_contact_no as mobileNo,notif_content as notifContent FROM ng_cmp.m_notification ,ng_cmp.m_user "
			+ "	where notification_id=103 and user_login_id=:userId", nativeQuery = true)
	TemplateIdMobileNo getTemplateIdMobileNo(String userId);

	@Query(value = "SELECT login_otp from ng_cmp.user_otp_details where user_id=:userId and "+
			"login_otp=:login_otp and created_on >= localtimestamp -interval'5 minutes' ", nativeQuery = true)
	Optional<String> validateOTP(Integer login_otp,String userId);
}
