package com.ng.common.request;

public class DecryptDataResDto {

	String outputData;

	public String getOutputData() {
		return outputData;
	}

	public void setOutputData(String outputData) {
		this.outputData = outputData;
	}
}
