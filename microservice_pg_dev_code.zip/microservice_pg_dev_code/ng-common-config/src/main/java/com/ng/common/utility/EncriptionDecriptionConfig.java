package com.ng.common.utility;

import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ng.common.constant.Constants;
import com.ng.common.request.DecryptDataResDto;
import com.ng.common.request.EncryptDataRequestDto;
import com.ng.common.request.GenerateKeyPairReqDto;
import com.ng.common.response.ApiResponse;
import com.ng.common.response.DecryptDataRequestDto;
import com.ng.common.response.EncryptDataResDto;
import com.ng.common.response.GenerateKeyPairsResDto;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EncriptionDecriptionConfig {
	

	public GenerateKeyPairsResDto generateKeyPairsByOrgIdAndUser(String restUrlEnc,RestTemplate restTemplate,HttpHeaders headers,GenerateKeyPairReqDto keyPairsRequest)
			{
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		List<String> headerAuth=headers.get(Constants.AUTHORIZATION);
		
		if (headerAuth != null) {
			httpHeaders.set(Constants.AUTHORIZATION, headerAuth.get(0));
		}
		HttpEntity<Object> httpEntityEnc = new HttpEntity<>(keyPairsRequest, httpHeaders);
		@SuppressWarnings("rawtypes")
		ResponseEntity<ApiResponse> responseEntityEnc = restTemplate
				.postForEntity(restUrlEnc + "/generateKeyPairsByOrgIdAndUser", httpEntityEnc, ApiResponse.class);
		ApiResponse<?> apiResponseEnc = responseEntityEnc.getBody();
		GenerateKeyPairsResDto authuserSymentricKeys = new GenerateKeyPairsResDto();
		try {
			if (apiResponseEnc != null) {
				authuserSymentricKeys = new ObjectMapper().convertValue(apiResponseEnc.getData(),
						new TypeReference<GenerateKeyPairsResDto>() {
						});
			}
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
		
		return authuserSymentricKeys;
	}
	
	public GenerateKeyPairsResDto getPublicKeyByOrgIdAndUser(String restUrlEnc,RestTemplate restTemplate,HttpHeaders headers,GenerateKeyPairReqDto keyPairsRequest)
			{
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		List<String> headerAuth=headers.get(Constants.AUTHORIZATION);
		
		if (headerAuth != null) {
			httpHeaders.set(Constants.AUTHORIZATION, headerAuth.get(0));
		}
		HttpEntity<Object> httpEntityEnc = new HttpEntity<>(keyPairsRequest, httpHeaders);
		@SuppressWarnings("rawtypes")
		ResponseEntity<ApiResponse> responseEntityEnc = restTemplate
				.postForEntity(restUrlEnc + "/getPublicKeyByOrgIdAndUser", httpEntityEnc, ApiResponse.class);
		ApiResponse<?> apiResponseEnc = responseEntityEnc.getBody();
		GenerateKeyPairsResDto authuserSymentricKeys = new GenerateKeyPairsResDto();
		try {
			if (apiResponseEnc != null) {
				authuserSymentricKeys = new ObjectMapper().convertValue(apiResponseEnc.getData(),
						new TypeReference<GenerateKeyPairsResDto>() {
						});
			}
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
		
		return authuserSymentricKeys;
	}
	
	public GenerateKeyPairsResDto generateSymmetricKeyByOrgIdAndUser(String restUrlEnc,RestTemplate restTemplate,HttpHeaders headers,GenerateKeyPairReqDto keyPairsRequest)
			{
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		List<String> headerAuth=headers.get(Constants.AUTHORIZATION);
		
		if (headerAuth != null) {
			httpHeaders.set(Constants.AUTHORIZATION, headerAuth.get(0));
		}
		HttpEntity<Object> httpEntityEnc = new HttpEntity<>(keyPairsRequest, httpHeaders);
		@SuppressWarnings("rawtypes")
		ResponseEntity<ApiResponse> responseEntityEnc = restTemplate
				.postForEntity(restUrlEnc + "/generateSymmetricKeyByOrgIdUserAndPublicKey", httpEntityEnc, ApiResponse.class);
		ApiResponse<?> apiResponseEnc = responseEntityEnc.getBody();
		GenerateKeyPairsResDto authuserSymentricKeys = new GenerateKeyPairsResDto();
		try {
			if (apiResponseEnc != null) {
				authuserSymentricKeys = new ObjectMapper().convertValue(apiResponseEnc.getData(),
						new TypeReference<GenerateKeyPairsResDto>() {
						});
			}
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
		
		return authuserSymentricKeys;
	}
	
	public GenerateKeyPairsResDto getSymmetricKeyUsersByOrgIdUserAndPublicKeys(String restUrlEnc,RestTemplate restTemplate,HttpHeaders headers,GenerateKeyPairReqDto keyPairsRequest)
			{
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		List<String> headerAuth=headers.get(Constants.AUTHORIZATION);
		
		if (headerAuth != null) {
			httpHeaders.set(Constants.AUTHORIZATION, headerAuth.get(0));
		}
		
		HttpEntity<Object> httpEntityEnc = new HttpEntity<>(keyPairsRequest, httpHeaders);
		@SuppressWarnings("rawtypes")
		ResponseEntity<ApiResponse> responseEntityEnc = restTemplate
				.postForEntity(restUrlEnc + "/getSymmetricKeyUsersByOrgIdUserAndPublicKeys", httpEntityEnc, ApiResponse.class);
		ApiResponse<?> apiResponseEnc = responseEntityEnc.getBody();
		GenerateKeyPairsResDto authuserSymentricKeys = new GenerateKeyPairsResDto();
		try {
			if (apiResponseEnc != null) {
				authuserSymentricKeys = new ObjectMapper().convertValue(apiResponseEnc.getData(),
						new TypeReference<GenerateKeyPairsResDto>() {
						});
			}
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
		
		return authuserSymentricKeys;
	}
	
	public EncryptDataResDto generateEncryptedData(String restUrlEnc,RestTemplate restTemplate,HttpHeaders headers,EncryptDataRequestDto encRequest)
			{
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		List<String> headerAuth=headers.get(Constants.AUTHORIZATION);
		
		if (headerAuth != null) {
			httpHeaders.set(Constants.AUTHORIZATION, headerAuth.get(0));
		}
		HttpEntity<Object> httpEntityEnc = new HttpEntity<>(encRequest, httpHeaders);
		@SuppressWarnings("rawtypes")
		ResponseEntity<ApiResponse> responseEntityEnc = restTemplate
				.postForEntity(restUrlEnc + "/generateEncryptedData", httpEntityEnc, ApiResponse.class);
		ApiResponse<?> apiResponseEnc = responseEntityEnc.getBody();
		EncryptDataResDto encryptDataResponse = new EncryptDataResDto();
		try {
			if (apiResponseEnc != null) {
				encryptDataResponse = new ObjectMapper().convertValue(apiResponseEnc.getData(),
						new TypeReference<EncryptDataResDto>() {
						});
			}
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
		
		return encryptDataResponse;
	}
	
	public DecryptDataResDto generateDecryptedData(String restUrlEnc,RestTemplate restTemplate,HttpHeaders headers,DecryptDataRequestDto decRequest)
			{
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		List<String> headerAuth=headers.get(Constants.AUTHORIZATION);
		
		if (headerAuth != null) {
			httpHeaders.set(Constants.AUTHORIZATION, headerAuth.get(0));
		}
		HttpEntity<Object> httpEntityDec = new HttpEntity<>(decRequest, httpHeaders);
		@SuppressWarnings("rawtypes")
		ResponseEntity<ApiResponse> responseEntityDec = restTemplate
				.postForEntity(restUrlEnc + "/generateDecryptedData", httpEntityDec, ApiResponse.class);
		ApiResponse<?> apiResponseEnc = responseEntityDec.getBody();
		DecryptDataResDto decryptDataResponse = new DecryptDataResDto();
		try {
			if (apiResponseEnc != null) {
				decryptDataResponse = new ObjectMapper().convertValue(apiResponseEnc.getData(),
						new TypeReference<DecryptDataResDto>() {
						});
			}
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
		
		return decryptDataResponse;
	}
	public EncryptDataResDto generateEncryptedDataWithRandomSymmetricKey(String restUrlEnc,RestTemplate restTemplate,HttpHeaders headers,EncryptDataRequestDto encRequest)
	{
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		List<String> headerAuth=headers.get(Constants.AUTHORIZATION);
		
		if (headerAuth != null) {
			httpHeaders.set(Constants.AUTHORIZATION, headerAuth.get(0));
		}
		HttpEntity<Object> httpEntityEnc = new HttpEntity<>(encRequest, httpHeaders);
		@SuppressWarnings("rawtypes")
		ResponseEntity<ApiResponse> responseEntityEnc = restTemplate
				.postForEntity(restUrlEnc + "/generateEncryptedDataWithRandomSymmetricKey", httpEntityEnc, ApiResponse.class);
		ApiResponse<?> apiResponseEnc = responseEntityEnc.getBody();
		EncryptDataResDto encryptDataResponse = new EncryptDataResDto();
		try {
			if (apiResponseEnc != null) {
				encryptDataResponse = new ObjectMapper().convertValue(apiResponseEnc.getData(),
						new TypeReference<EncryptDataResDto>() {
						});
			}
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
		
		return encryptDataResponse;
}

public DecryptDataResDto generateDecryptedDataWithRandomSymmetricKey(String restUrlEnc,RestTemplate restTemplate,HttpHeaders headers,DecryptDataRequestDto decRequest)
	{
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		List<String> headerAuth=headers.get(Constants.AUTHORIZATION);
		
		if (headerAuth != null) {
			httpHeaders.set(Constants.AUTHORIZATION, headerAuth.get(0));
		}
		HttpEntity<Object> httpEntityDec = new HttpEntity<>(decRequest, httpHeaders);
		@SuppressWarnings("rawtypes")
		ResponseEntity<ApiResponse> responseEntityDec = restTemplate
				.postForEntity(restUrlEnc + "/generateDecryptedDataWithRandomSymmetricKey", httpEntityDec, ApiResponse.class);
		ApiResponse<?> apiResponseEnc = responseEntityDec.getBody();
		DecryptDataResDto decryptDataResponse = new DecryptDataResDto();
		try {
			if (apiResponseEnc != null) {
				decryptDataResponse = new ObjectMapper().convertValue(apiResponseEnc.getData(),
						new TypeReference<DecryptDataResDto>() {
						});
			}
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
		
		return decryptDataResponse;
		}
}
