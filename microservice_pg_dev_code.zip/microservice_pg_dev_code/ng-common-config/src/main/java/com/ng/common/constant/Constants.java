package com.ng.common.constant;

public final class Constants {
	
	
	private Constants() {
		super();
	} 

    public static final String SUCCESS = "SUCCESS";
    public static final String MENUCREATE = "Portal menu created successfuly.";
    public static final String ERROR = "error";
    public static final String DATE_FORMAT = "dd/MM/yyyy";
    public static final String DATE_TIME_FORMAT = "dd-MM-yyyy HH:mm";
	public static final String AUTHORIZATION = "Authorization";

}
