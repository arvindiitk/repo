package com.ng.common;

/**
 * Hello world!
 *
 */
public interface App 
{}
