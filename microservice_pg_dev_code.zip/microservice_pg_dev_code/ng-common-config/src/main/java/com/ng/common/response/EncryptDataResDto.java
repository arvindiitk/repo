package com.ng.common.response;

public class EncryptDataResDto {
	
	String outputData;

	public String getOutputData() {
		return outputData;
	}

	public void setOutputData(String outputData) {
		this.outputData = outputData;
	}
}
