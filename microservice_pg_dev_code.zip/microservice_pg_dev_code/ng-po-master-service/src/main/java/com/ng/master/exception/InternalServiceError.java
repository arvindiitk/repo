package com.ng.master.exception;

public class InternalServiceError extends RuntimeException {
	
    private static final long serialVersionUID = 1L;

	public InternalServiceError(String message) {
        super(message);
    }
}
