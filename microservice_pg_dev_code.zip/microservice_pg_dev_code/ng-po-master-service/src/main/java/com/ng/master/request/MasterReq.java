package com.ng.master.request;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class MasterReq implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String tableName;
	//private String key;
	//private String value;	
	private Map<String, String> key = new HashMap<String, String>();
}
