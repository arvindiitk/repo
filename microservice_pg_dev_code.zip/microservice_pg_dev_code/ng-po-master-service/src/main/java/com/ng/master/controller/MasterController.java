package com.ng.master.controller;

import java.util.List;

import com.ng.master.constants.Constants;
import com.ng.master.exception.ResourceNotFoundException;
import com.ng.master.request.MasterReq;
import com.ng.master.response.ApiResponse;
import com.ng.master.response.MasterTableRes;
import com.ng.master.service.MasterTableService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@RequestMapping("/ng-master")
@Transactional(timeout = 180)
public class MasterController {
	
    @Autowired
    MasterTableService masterTableService;

    @PostMapping("/po/ng-po-master")
    public ResponseEntity<Object> getMasterData(@RequestBody MasterReq masterReq)throws ResourceNotFoundException {
        log.info("MasterController :getMasterData {} ");
        List<MasterTableRes> masterTableRes=null;
        if(masterReq.getKey()!=null)
        {
        	masterTableRes = masterTableService.findByTableNameAndKey(masterReq.getTableName(),masterReq.getKey());
        }
        else
        {
        	masterTableRes = masterTableService.findByTableName(masterReq.getTableName());
        }
        
        if(masterTableRes.isEmpty()) {
        	throw new ResourceNotFoundException("Request list"+" "+Constants.NOT_FOUND);
        }
       
               ApiResponse<?> apiResponse = ApiResponse.builder()
                .status(String.valueOf(HttpStatus.OK.value()))
                .message(Constants.SUCCESS)
                .data(masterTableRes)
                .build();
        log.info("[MasterController.getMasterData] : success response");
        return ResponseEntity.ok().body(apiResponse);

    }
    
}