package com.ng.master.configuration;

import java.util.Properties;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
/**
 * configure message properties
 */
@EnableTransactionManagement
@Configuration
public class PropertyConfigure {

	
	
	@Value("${spring.datasource.username}")
	String dbUserName;
	
	@Value("${spring.datasource.password}")
	String dbPass;
	
	@Value("${spring.datasource.url}")
	String dbUrl;
	
	@Value("${spring.jpa.properties.hibernate.dialect}")
	String springJpaHibernateDialect;
	
	
	@Value("${spring.datasource.driver-class-name}")
	String springDatasourceDriverClassName;
	
	
	
    /**
     * configure message source
     * @return
     */
    @Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasename("classpath:messages");
        messageSource.setDefaultEncoding("UTF-8");
        return messageSource;
    }
    
	@Bean(name="entityManagerFactory")
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		LocalContainerEntityManagerFactoryBean lcemfb = new LocalContainerEntityManagerFactoryBean();
		lcemfb.setJpaVendorAdapter(getJpaVendorAdapter());
		lcemfb.setDataSource(getDataSource());
		lcemfb.setPersistenceUnitName("potPersistenceUnit");
		lcemfb.setPackagesToScan("com.ng.master.dao","com.ng.master.response");
		lcemfb.setJpaProperties(jpaProperties());
		return lcemfb;
	}
	
	 @Bean
		public BasicDataSource getDataSource() {
		    BasicDataSource dataSource = new BasicDataSource();
		    dataSource.setDriverClassName(springDatasourceDriverClassName);
		    dataSource.setUrl(dbUrl);
		    dataSource.setUsername(dbUserName);
		    dataSource.setPassword(dbPass);
		    return  dataSource;
		}
	 
	 private Properties jpaProperties() {
	        return new Properties();        
	   }	
	 
	
	@Bean
	public JpaVendorAdapter getJpaVendorAdapter() {
		return new HibernateJpaVendorAdapter();
	}

    /**
     * configure validator
     * @return
     */
    @Bean
    public LocalValidatorFactoryBean validator() {
        LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
        bean.setValidationMessageSource(messageSource());
        return bean;
    }
}
