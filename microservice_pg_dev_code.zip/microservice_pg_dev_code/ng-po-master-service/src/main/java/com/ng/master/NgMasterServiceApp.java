package com.ng.master;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgMasterServiceApp {
	public static void main(String[] args) {
		SpringApplication.run(NgMasterServiceApp.class, args);
	}

}
