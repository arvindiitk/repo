package com.ng.master.dao;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.persistence.Query;

import com.ng.master.configuration.AbstractJpaDAO;
import com.ng.master.response.MasterTableRes;

import org.hibernate.Session;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class MasterDao extends AbstractJpaDAO<MasterTableRes> {

	@PostConstruct
	public void init() {
		super.setClazz(MasterTableRes.class);
	}

	@SuppressWarnings("deprecation")
	public List<MasterTableRes> getMasterData(String tableName) {
		Session session = getSession();
		String sqlQuery = getMasterQuery(tableName).trim() + " order by description asc";
		@SuppressWarnings("unchecked")
		NativeQuery<MasterTableRes> query = session.createNativeQuery(sqlQuery);
		query.setResultTransformer(Transformers.aliasToBean(MasterTableRes.class));
		return query.getResultList();
	}
	
	@SuppressWarnings("deprecation")
	public List<MasterTableRes> getMasterDataId(String masterTableName,Map<String, String> map) {
		Session session = getSession();
		StringBuilder whereCondition= new StringBuilder();
		for (Map.Entry<String, String> entry : map.entrySet()) {
		    if(whereCondition.length()==0)
		    {
		    whereCondition.append(entry.getKey() + " = '" + entry.getValue()+"'");
		    }
		    else
		    {
		    	whereCondition.append(" AND ");
		    	whereCondition.append(entry.getKey() + " = '" + entry.getValue()+"'");
		    }		    	
		}		
		String sqlQuery = getMasterQuery(masterTableName).trim()+" WHERE "+whereCondition+" order by description asc";
		@SuppressWarnings("unchecked")
		NativeQuery<MasterTableRes> query = session.createNativeQuery(sqlQuery);
		query.setResultTransformer(Transformers.aliasToBean(MasterTableRes.class));
		return query.getResultList();
	}

	public String getMasterQuery(String tableName) {
		Session session = getSession();
		tableName = tableName.toLowerCase().trim();
		String sqlQuery = "SELECT CAST(SQL_QUERY as varchar(5000)) SQL_QUERY from QUERY_MASTER_MAPPING WHERE TABLE_NAME='"+tableName+"'";
		Query query = session.createSQLQuery(sqlQuery);
		if(null != query.getResultList() && query.getResultList().size() >0)
			return query.getResultList().get(0).toString();
		return null;
	}

	
}
