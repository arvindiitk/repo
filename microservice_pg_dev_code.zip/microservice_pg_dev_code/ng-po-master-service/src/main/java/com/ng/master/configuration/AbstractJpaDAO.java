package com.ng.master.configuration;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;

@Repository
@ComponentScan(basePackages = { "com.ng.master" })
@Transactional
@SuppressWarnings("unchecked")
public abstract class AbstractJpaDAO <T extends Serializable> extends CommonSessionFactory {

	private static final Logger LOGGER = LoggerFactory.getLogger(AbstractJpaDAO.class);

	private Class<T> clazz;

	@PersistenceContext(type = PersistenceContextType.TRANSACTION, unitName = "potPersistenceUnit")
	 EntityManager entityManagerDao;

	public  void setClazz(Class<T> clazzToSet) {
		this.clazz = clazzToSet;
	}

	public T findOne(long id) {
		return entityManagerDao.find(clazz, id);
	}

	
	public List<T> findAll() {
		LOGGER.debug(clazz.getName());
		StringBuilder sb =new StringBuilder();
		sb.append("select c from ");
		sb.append(clazz.getSimpleName());
		sb.append(" c");
		return entityManagerDao.createQuery(sb.toString()).getResultList();
	}


	public List<T> findAllPaginated(int pageNumber, int pageSize) {
		LOGGER.debug(clazz.getName());
		StringBuilder sb =new StringBuilder();
		sb.append("select c from ");
		sb.append(clazz.getSimpleName());
		sb.append(" c");
		Query query = entityManagerDao.createQuery(sb.toString());
		query.setFirstResult((pageNumber - 1) * pageSize);
		query.setMaxResults(pageSize);
		return query.getResultList();
	}

	public void create(T entity) {
		entityManagerDao.persist(entity);
	}

	public T update(T entity) {
		Session ses = getSession();
		if(ses.contains(entity))
			ses.update(entity);
		else
			ses.merge(entity);
	
		return entity;
	}


	public void delete(T entity) {
		entityManagerDao.remove(entity);
	}

	public void deleteById(long entityId) {
		T entity = findOne(entityId);
		delete(entity);
	}
}
