package com.ng.master.configuration;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class CommonSessionFactory {

	@PersistenceContext(type = PersistenceContextType.TRANSACTION, unitName = "potPersistenceUnit")
	public EntityManager entityManager;
	
	private Session currentSession;
	
		public void closeCurrentSession() {
			currentSession.close();
		}

		public Session getCurrentSession() {
			return currentSession;
		}

		public void setCurrentSession(Session currentSession) {
			this.currentSession = currentSession;
		}

		public Session getSession() {
			Session ses = null;
			if (null != getCurrentSession()) {
				ses = getCurrentSession();
			} else {
				ses = (Session)entityManager.getDelegate();
			}
			
			return ses;
		}
}
