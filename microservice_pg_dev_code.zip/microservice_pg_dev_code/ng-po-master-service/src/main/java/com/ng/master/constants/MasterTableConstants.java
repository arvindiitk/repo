package com.ng.master.constants;

public final class MasterTableConstants {
	
	
	private MasterTableConstants() {
		super();
	}
	// NCRB Master Constants 
	
}
