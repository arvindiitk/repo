package com.ng.menu.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ng.menu.constants.Constants;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


/**
 * The persistent class for the M_PORTAL_MENU database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Valid
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name="M_PORTAL_MENU")

public class PortalMenu implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PORTAL_MENU_ID", unique=true, nullable=false)
	private Integer portalMenuId;

	@Column(name="CREATED_BY", nullable=false,updatable = false)
	private Integer createdBy;
	
	@Column(name="MENU_ID", nullable=false)
	private Integer menuId;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT,timezone = "GMT+5:30")
	@Column(name="CREATED_ON", nullable=false,updatable = false)
	private Timestamp createdOn;

	@Column(name="IS_ACTIVE", nullable=false,columnDefinition = "default bit 1")
	private Boolean isActive;

	@Column(name="MENU_ACCESS_APPROVE", nullable=false,columnDefinition = "default bit 1")
	private Boolean menuAccessApprove;

	@Column(name="MENU_ACCESS_READ", nullable=false,columnDefinition = "default bit 1")
	private Boolean menuAccessRead;

	@Column(name="MENU_ACCESS_RECOMMEND", nullable=false,columnDefinition = "default bit 1")
	private Boolean menuAccessRecommend;

	@Column(name="MENU_ACCESS_WRITE", nullable=false,columnDefinition = "default bit 1")
	private Boolean menuAccessWrite;

	//bi-directional many-to-one association to Menu
	@JsonBackReference(value = "menu")
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MENU_ID", nullable=false,insertable = false,updatable = false)
	private Menu menu;

	//bi-directional many-to-one association to Portal
	@JsonBackReference(value = "portal")
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PORTAL_ID", nullable=false)
	private Portal portal;

}