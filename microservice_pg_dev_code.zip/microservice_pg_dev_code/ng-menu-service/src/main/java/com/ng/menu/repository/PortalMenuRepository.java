package com.ng.menu.repository;

import com.ng.menu.entity.PortalMenu;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface PortalMenuRepository extends JpaRepository<PortalMenu, Integer>{

}



