package com.ng.menu.controller;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.Valid;

import com.ng.menu.constants.Constants;
import com.ng.menu.entity.Menu;
import com.ng.menu.entity.MenuPortalResponse;
import com.ng.menu.entity.Portal;
import com.ng.menu.exception.ResourceNotFoundException;
import com.ng.menu.request.PortalReq;
import com.ng.menu.response.ApiResponse;
import com.ng.menu.service.MenusService;
import com.ng.menu.service.PortalsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@RestController
@Slf4j
@RequestMapping("/ng-menu")
@Transactional(timeout = 180)
public class MenuController {
    @Autowired
    MenusService menuService;
    PortalsService portalService;

    @GetMapping(value="/menu/ng-getAllMenus")
    public ResponseEntity<Object> getAllMenus() throws ResourceNotFoundException {
        log.info("MenuController :getAllMenus {} ");

        List<Menu> filteredList = menuService.findAll();
        
//        if(filteredList.isEmpty()) {
//        	throw new ResourceNotFoundException("Request list not found");
//        }
        filteredList = filteredList.stream()
                .filter(Menu::getIsActive )
                .collect(Collectors.toList());

        ApiResponse<?> apiResponse = ApiResponse.builder()
                .status(String.valueOf(HttpStatus.OK.value()))
                .message(Constants.SUCCESS)
                .data(filteredList)
                .build();
        log.info("[MenusController.getAllMenus] : success response");
        return ResponseEntity.ok().body(apiResponse);

    }
    
    @PostMapping(value="/menu/ng-getPortalWiseMenu",consumes = {"application/json"})
    public ResponseEntity<Object>  getMenusByPortalId(@Valid @RequestBody PortalReq portalReq) throws ResourceNotFoundException {
        log.info("MenuController: ng-getMenusByPortalId {}");        
        List<MenuPortalResponse> filteredList = menuService.getMenusByPortalId().stream()
        		.filter(e -> Objects.equals(e.getPortalId(), portalReq.getPortalId()))
        		.collect(Collectors.toList());
        
//        if(filteredList.isEmpty()) {
//        	throw new ResourceNotFoundException("Request list for portal id " +portalReq.getPortalId()+" "+Constants.NOT_FOUND);
//        }
        
        ApiResponse<?> apiResponse = ApiResponse.builder()
                .status(String.valueOf(HttpStatus.OK.value()))
                .message(Constants.SUCCESS)
                .data(filteredList)
                .build();
        log.info("MenuController: ng-getMenusByPortalId response");
        return ResponseEntity.ok().body(apiResponse);
    }
       
    @PostMapping(value="/menu/ng-saveUpdateMenuForPortal",consumes = {"application/json"})
    public ResponseEntity<Object>  saveUpdateMenuForPortal(@Valid @RequestBody PortalReq req){
        log.info("MenuController: createMenu ng-saveUpdateMenuForPortal {}",req);
        Portal portal = new Portal(req.getPortalId(), req.getCreatedBy(), req.getCreatedOn(), req.getIsActive(), req.getPortalAlias(), req.getPortalDesc(), req.getPortalName(),   req.getPortalMenus());
        
        Portal menuPortalResponse= portalService.saveOrUpdate(portal);
        ApiResponse<?> apiResponse = ApiResponse.builder()
        		.status(String.valueOf(HttpStatus.OK.value()))
                .message(Constants.MENUCREATE)
                .data(menuPortalResponse)
                .build();
        log.info("MenuController: createMenu ng-saveUpdateMenuForPortal response");
        return ResponseEntity.ok().body(apiResponse);
    }
}
