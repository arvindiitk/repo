package com.ng.menu.service;

import java.util.List;

import com.ng.menu.entity.Menu;
import com.ng.menu.entity.MenuPortalResponse;

public interface MenusService {
    public List<Menu> findAll();
	public List<MenuPortalResponse> getMenusByPortalId();

}
