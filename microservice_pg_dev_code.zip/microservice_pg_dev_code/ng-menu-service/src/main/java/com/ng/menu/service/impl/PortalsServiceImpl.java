package com.ng.menu.service.impl;

import javax.transaction.Transactional;

import com.ng.menu.entity.Portal;
import com.ng.menu.repository.PortalsRepository;
import com.ng.menu.service.PortalsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
@Transactional
public class PortalsServiceImpl implements PortalsService {
    @Autowired
    private PortalsRepository portalsRepository;
    
    @Override
    public Portal saveOrUpdate(Portal portal) {
    	portal.getPortalMenus().forEach(d -> d.setPortal(portal));    	
    	return portalsRepository.save(portal);
    }
}
