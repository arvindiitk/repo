package com.ng.menu.service;

import com.ng.menu.entity.Portal;

public interface PortalsService {
    public Portal saveOrUpdate(Portal portal);
    
}
