package com.ng.menu.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class MenuPortalResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
    
	@Id
	@Column(name = "PORTAL_MENU_ID")
	private Integer portalMenuId;
	
	@Column(name = "PORTAL_ID")
	private Integer portalId;
		
	@Column(name = "MENU_ID")
	private Integer menuId;
	
	@Column(name = "MENU_NAME")
	private String menuName;

	@Column(name = "PARENT_MENU_ID")
	private Integer parentMenuId;

	@Column(name = "MENU_SEQ")
	private Integer menuSeq;

	@Column(name = "MENU_ACCESS_READ")
	private Boolean menuAccessRead;
	
	@Column(name = "MENU_ACCESS_WRITE")
    private Boolean menuAccessWrite;
	
	@Column(name = "MENU_ACCESS_APPROVE")
    private Boolean menuAccessApprove;
	
	@Column(name = "MENU_ACCESS_RECOMMEND")
    private Boolean menuAccessRecommend;
	
	@Column(name = "IS_ACTIVE")
    private Boolean isActive;
}
