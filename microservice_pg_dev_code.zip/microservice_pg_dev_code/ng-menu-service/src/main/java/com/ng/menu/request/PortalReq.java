package com.ng.menu.request;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

import com.ng.menu.entity.PortalMenu;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Data
public class PortalReq implements Serializable {
    private static final long serialVersionUID = -993948671188135922L;
    
    @NotNull(message = "New portal cannot be created. Please add portal Id in request")
    @Range(min = 0l, max = 2147483647, message = "Portal id should be between 1 to 11 digits")
    private Integer portalId;

	private Integer createdBy;

	private Timestamp createdOn;

	private Boolean isActive;

	@Size(min =2, max=10, message = "Portal alias should be between 2 to 10 characters")
	private String portalAlias;

	@Size(min = 10, max=200, message = "Portal description should be between 10 to 200 characters")
	private String portalDesc;

	@Size(min = 1, max=80, message = "Portal name should be between 1 to 80 characters")
	private String portalName;

	private List<PortalMenu> portalMenus;

}
