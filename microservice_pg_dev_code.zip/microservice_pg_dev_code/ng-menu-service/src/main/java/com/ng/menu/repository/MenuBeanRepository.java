package com.ng.menu.repository;

import java.util.List;

import com.ng.menu.entity.MenuPortalResponse;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
@Repository
public interface MenuBeanRepository extends JpaRepository<MenuPortalResponse, Integer>{
	
	@Query(value="select pm.PORTAL_MENU_ID, pm.PORTAL_ID, m.MENU_ID, m.MENU_NAME, m.PARENT_MENU_ID, m.MENU_SEQ, "
			+ "pm.MENU_ACCESS_READ, pm.MENU_ACCESS_WRITE, pm.MENU_ACCESS_APPROVE, pm.MENU_ACCESS_RECOMMEND, pm.IS_ACTIVE "
			+ "from M_MENU m "
			+ "inner join M_PORTAL_MENU pm on pm.MENU_ID = m.MENU_ID and m.IS_ACTIVE = 'true' ORDER BY m.MENU_SEQ ASC ",nativeQuery = true)
    public List<MenuPortalResponse> getMenusByPortalId();
	
}



