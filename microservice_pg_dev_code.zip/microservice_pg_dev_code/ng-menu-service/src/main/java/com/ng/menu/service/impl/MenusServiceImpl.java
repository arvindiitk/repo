package com.ng.menu.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import com.ng.menu.entity.Menu;
import com.ng.menu.entity.MenuPortalResponse;
import com.ng.menu.entity.User;
import com.ng.menu.repository.MenuBeanRepository;
import com.ng.menu.repository.MenuRepository;
import com.ng.menu.repository.UserRepository;
import com.ng.menu.service.MenusService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
@Transactional
public class MenusServiceImpl implements MenusService {
    @Autowired
    private MenuBeanRepository menusRepository;
    private MenuRepository menuRepository;
    private UserRepository userRepository;


    @Override
    public List<Menu> findAll() {
    	List<Menu> menus=menuRepository.findAll();
    	getNameList(menus);
        return menus;
    }


	@Override
	public List<MenuPortalResponse> getMenusByPortalId() {
		return menusRepository.getMenusByPortalId();
	}
    
	public List<Menu> getNameList(List<Menu> menues) {
		for (Menu menu : menues) {
			List<User>  user = userRepository.findById(menu.getCreatedBy()).stream().collect(Collectors.toList());
			menu.setCreatedByName(!user.isEmpty() ? user.get(0).getUserName() : null);			
		}
		return menues;
	} 
	
}
