package com.ng.menu.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.menu.constants.Constants;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


/**
 * The persistent class for the M_MENU database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Valid
@Entity
@Table(name="M_MENU")
public class Menu implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="MENU_ID", unique=true, nullable=false)
	private Integer menuId;

	@Column(name="CREATED_BY", nullable=false,updatable = false)
	private Integer createdBy;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT,timezone = "GMT+5:30")
	@Column(name="CREATED_ON", nullable=false,updatable = false)
	private Timestamp createdOn;

	@Column(name="IS_ACTIVE", nullable=false,columnDefinition = "default bit 1")
	private Boolean isActive;

	@Column(name="MENU_NAME", nullable=false)
	private String menuName;

	@Column(name="MENU_SEQ", nullable=false)
	private Integer menuSeq;

	@Column(name="MENU_URL", nullable=false)
	private String menuUrl;

	@Column(name="PARENT_MENU_ID", nullable=false)
	private Integer parentMenuId;

	//bi-directional many-to-one association to PortalMenu
	
	@JsonBackReference(value = "portalMenus")
	@OneToMany(mappedBy="menu",cascade={CascadeType.PERSIST},fetch=FetchType.LAZY)
	private List<PortalMenu> portalMenus;
	
	@Transient
	public String createdByName;

	
}