cd ng-auth-service
mvn install
nohup java -jar target/ng-auth-service-0.0.1-SNAPSHOT.jar > ng-auth-service.out &

cd ../ng-common-config
mvn install
nohup java -jar target/ng-common-config-0.0.1-SNAPSHOT.jar > ng-common-config.out &

cd ../ng-encryption-decryption-service
mvn install
nohup java -jar target/ng-encryption-decryption-service-0.0.1-SNAPSHOT.jar > ng-encryption-decryption-service.out &

cd ../ng-feedback-service
mvn install
nohup java -jar target/ng-feedback-service-0.0.1-SNAPSHOT.jar > ng-feedback-service.out &

cd ../ng-keycloak-services
mvn install
nohup java -jar target/ng-keycloak-services-0.0.1-SNAPSHOT.jar > ng-keycloak-services.out &

cd ../ng-menu-service
mvn install
nohup java -jar target/ng-menu-service-0.0.1-SNAPSHOT.jar > ng-menu-service.out &

cd ../ng-notificationflow-service
mvn install
nohup java -jar target/ng-notificationflow-service-0.0.1-SNAPSHOT.jar > ng-notificationflow-service.out &

cd ../ng-notification-service
mvn install
nohup java -jar target/ng-notification-service-0.0.1-SNAPSHOT.jar > ng-notification-service.out &

cd ../ng-org-service
mvn install
nohup java -jar target/ng-org-service-0.0.1-SNAPSHOT.jar > ng-org-service.out &

cd ../ng-org-type-service
mvn install
nohup java -jar target/ng-org-type-service-0.0.1-SNAPSHOT.jar > ng-org-type-service.out &

cd ../ng-po-master-service
mvn install
nohup java -jar target/ng-po-master-service-0.0.1-SNAPSHOT.jar > ng-po-master-service.out &

cd ../ngpo-portal-service
mvn install
nohup java -jar target/ngpo-portal-service-0.0.1-SNAPSHOT.jar > ngpo-portal-service.out &

cd ../ng-portal-service
mvn install
nohup java -jar target/ng-portal-service-0.0.1-SNAPSHOT.jar > ng-portal-service.out &

cd ../ng-reports-service
mvn install
nohup java -jar target/ng-reports-service-0.0.1-SNAPSHOT.jar > ng-reports-service.out &

cd ../ng-request-status-service
mvn install
nohup java -jar target/ng-request-status-service-0.0.1-SNAPSHOT.jar > ng-request-status-service.out &

cd ../ng-restricted-entity-service
mvn install
nohup java -jar target/ng-restricted-entity-service-0.0.1-SNAPSHOT.jar > ng-restricted-entity-service.out &

cd ../ng-role-service
mvn install
nohup java -jar target/ng-role-service-0.0.1-SNAPSHOT.jar > ng-role-service.out &

cd ../ng-sms-service
mvn install
nohup java -jar target/ng-sms-service-0.0.1-SNAPSHOT.jar > ng-sms-service.out &

cd ../ngua-audit-service
mvn install
nohup java -jar target/ngua-audit-service-0.0.1-SNAPSHOT.jar > ngua-audit-service.out &

cd ../ngua-case-archive-service
mvn install
nohup java -jar target/ngua-case-archive-service-0.0.1-SNAPSHOT.jar > ngua-case-archive-service.out &

cd ../ngua-case-close-service
mvn install
nohup java -jar target/ngua-case-close-service-0.0.1-SNAPSHOT.jar > ngua-case-close-service.out &

cd ../ngua-case-note-service
mvn install
nohup java -jar target/ngua-case-note-service-0.0.1-SNAPSHOT.jar > ngua-case-note-service.out &

cd ../ngua-case-participant-service
mvn install
nohup java -jar target/ngua-case-participant-service-0.0.1-SNAPSHOT.jar > ngua-case-participant-service.out &

cd ../ngua-case-reopen-service
mvn install
nohup java -jar target/ngua-case-reopen-service-0.0.1-SNAPSHOT.jar > ngua-case-reopen-service.out &

cd ../ngua-case-request-service
mvn install
nohup java -jar target/ngua-case-request-service-0.0.1-SNAPSHOT.jar > ngua-case-request-service.out &

cd ../ngua-case-request-udc-service
mvn install
nohup java -jar target/ngua-case-request-udc-service-0.0.1-SNAPSHOT.jar > ngua-case-request-udc-service.out &

cd ../ngua-case-revoke-service
mvn install
nohup java -jar target/ngua-case-revoke-service-0.0.1-SNAPSHOT.jar > ngua-case-revoke-service.out &

cd ../ngua-case-service
mvn install
nohup java -jar target/ngua-case-service-0.0.1-SNAPSHOT.jar > ngua-case-service.out &

cd ../ngua-case-transfer-service
mvn install
nohup java -jar target/ngua-case-transfer-service-0.0.1-SNAPSHOT.jar > ngua-case-transfer-service.out &

cd ../ngua-entity-resolution-service
mvn install
nohup java -jar target/ngua-entity-resolution-service-0.0.1-SNAPSHOT.jar > ngua-entity-resolution-service.out &

cd ../ngua-mart-service
mvn install
nohup java -jar target/ngua-mart-service-0.0.1-SNAPSHOT.jar > ngua-mart-service.out &

cd ../ngua-notification-service
mvn install
nohup java -jar target/ngua-notification-service-0.0.1-SNAPSHOT.jar > ngua-notification-service.out &

cd ../ngua-po-watchlist-service
mvn install
nohup java -jar target/ngua-po-watchlist-service-0.0.1-SNAPSHOT.jar > ngua-po-watchlist-service.out &

cd ../ngua-user-activity-service
mvn install
nohup java -jar target/ngua-user-activity-service-0.0.1-SNAPSHOT.jar > ngua-user-activity-service.out &

cd ../ngua-user-keys-service
mvn install
nohup java -jar target/ngua-user-keys-service-0.0.1-SNAPSHOT.jar > ngua-user-keys-service.out &

cd ../ngua-watchlist-service
mvn install
nohup java -jar target/ngua-watchlist-service-0.0.1-SNAPSHOT.jar > ngua-watchlist-service.out &

cd ../ngua-workflow-service
mvn install
nohup java -jar target/ngua-workflow-service-0.0.1-SNAPSHOT.jar > ngua-workflow-service.out &

cd ../ng-usecase-configuration-service
mvn install
nohup java -jar target/ng-usecase-configuration-service-0.0.1-SNAPSHOT.jar > ng-usecase-configuration-service.out &

cd ../ng-user-mgmt-service
mvn install
nohup java -jar target/ng-user-mgmt-service-0.0.1-SNAPSHOT.jar > ng-user-mgmt-service.out &

cd ../ng-user-status-service
mvn install
nohup java -jar target/ng-user-status-service-0.0.1-SNAPSHOT.jar > ng-user-status-service.out &

cd ../ng-workflow-service
mvn install
nohup java -jar target/ng-workflow-service-0.0.1-SNAPSHOT.jar > ng-workflow-service.out &

