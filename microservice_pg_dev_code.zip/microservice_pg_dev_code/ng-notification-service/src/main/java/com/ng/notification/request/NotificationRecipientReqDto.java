package com.ng.notification.request;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The persistent class for the M_NOTIFICATION_RECIPIENT database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter

public class NotificationRecipientReqDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer notifRecipientId;

	private Integer createdBy;

	private Timestamp createdOn;

	private Boolean isActive;

	private String notifRecipientDescription;

	private String notifRecipientType;

}