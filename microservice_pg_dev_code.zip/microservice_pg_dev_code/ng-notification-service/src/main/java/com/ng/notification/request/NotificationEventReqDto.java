package com.ng.notification.request;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The persistent class for the M_NOTIFICATION_EVENT database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter

public class NotificationEventReqDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer notifEventId;

	private Integer menuId;

	private Integer createdBy;

	private Timestamp createdOn;

	private Boolean isActive;

	private String notifEventCode;

	private String notifEventDescription;

}