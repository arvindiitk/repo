package com.ng.notification.request;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The persistent class for the M_MENU database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter

public class MenuReqDto implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer menuId;

	private Integer createdBy;

	private Timestamp createdOn;

	private Boolean isActive;

	private String menuName;

	private Integer menuSeq;

	private String menuUrl;

	private Integer parentMenuId;

}