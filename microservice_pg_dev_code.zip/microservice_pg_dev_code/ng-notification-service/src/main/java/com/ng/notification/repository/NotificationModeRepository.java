package com.ng.notification.repository;

import java.util.List;
import com.ng.notification.entity.NotificationMode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NotificationModeRepository extends JpaRepository<NotificationMode, Integer> {
   
	public List<NotificationMode> findByIsActiveOrderByCreatedOnDesc(boolean b);

}
