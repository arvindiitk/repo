package com.ng.notification.service;

import java.util.List;
import java.util.Optional;

import com.ng.notification.entity.Notification;
import com.ng.notification.entity.NotificationEntity;
import com.ng.notification.entity.NotificationEvent;
import com.ng.notification.entity.NotificationMode;
import com.ng.notification.entity.NotificationRecipient;
import com.ng.notification.request.NotificationEventReqDto;
import com.ng.notification.request.NotificationModeReqDto;
import com.ng.notification.request.NotificationRecipientReqDto;
import com.ng.notification.request.NotificationReqDto;

public interface NotificationService {
   
    public NotificationRecipient saveOrUpdate(NotificationRecipientReqDto notificationRecipient);
    public List<NotificationRecipient> findAll();
    public Optional<NotificationRecipient> findByNotifRecipientId(Integer notifRecipientId);
    
    public NotificationMode saveOrUpdate(NotificationModeReqDto notificationMode);
    public List<NotificationMode> findAllNotifMode();
    public Optional<NotificationMode> findByNotifModeId(Integer notificationModeId);
    
    public NotificationEvent saveOrUpdate(NotificationEventReqDto notificationEvent);
    public List<NotificationEvent> findAllNotifEvent();
    public Optional<NotificationEvent> findByNotifEventId(Integer notificationEventId);
    
    public Notification saveOrUpdate(NotificationReqDto notification);
    public List<NotificationEntity> findAllNotif();
    public Optional<Notification> findByNotifId(Integer notificationId);

}
