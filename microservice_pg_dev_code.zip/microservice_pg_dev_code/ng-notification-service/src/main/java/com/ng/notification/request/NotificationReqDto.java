package com.ng.notification.request;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;

import com.ng.notification.entity.Notification;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The persistent class for the M_NOTIFICATION database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter

public class NotificationReqDto implements Serializable {
	private static final long serialVersionUID = 1L;	
	@Valid
	private List<Notification> notificationList;
	private Integer notificationId;
}