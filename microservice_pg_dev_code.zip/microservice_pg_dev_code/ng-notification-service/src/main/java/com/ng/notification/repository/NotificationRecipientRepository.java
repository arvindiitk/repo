package com.ng.notification.repository;

import java.util.List;
import com.ng.notification.entity.NotificationRecipient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NotificationRecipientRepository extends JpaRepository<NotificationRecipient, Integer>  {
	
	public List<NotificationRecipient> findByIsActiveOrderByCreatedOnDesc(boolean b);
	
}