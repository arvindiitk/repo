package com.ng.notification.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ng.notification.entity.Notification;
import com.ng.notification.entity.NotificationEntity;
import com.ng.notification.entity.NotificationEvent;
import com.ng.notification.entity.NotificationMode;
import com.ng.notification.entity.NotificationRecipient;
import com.ng.notification.entity.User;
import com.ng.notification.repository.NotificationEventRepository;
import com.ng.notification.repository.NotificationModeRepository;
import com.ng.notification.repository.NotificationRecipientRepository;
import com.ng.notification.repository.NotificationRepository;
import com.ng.notification.repository.NotificationRepositoryForFindAll;
import com.ng.notification.repository.UserRepository;
import com.ng.notification.request.NotificationEventReqDto;
import com.ng.notification.request.NotificationModeReqDto;
import com.ng.notification.request.NotificationRecipientReqDto;
import com.ng.notification.request.NotificationReqDto;
import com.ng.notification.service.NotificationService;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
@Transactional
public class NotificationServiceImpl implements NotificationService {

	@Autowired
	private NotificationRecipientRepository notifRecipientRepository;

	@Autowired
	private NotificationModeRepository notifModeRepository;

	@Autowired
	private NotificationRepository notifRepository;
	
	@Autowired
	private NotificationRepositoryForFindAll notifRepositoryForFinddAll;
	
	@Autowired
	private NotificationEventRepository notifEventRepository;
	
	@Autowired
	private UserRepository userRepository;

	
	/**
	 * save saveUpdateNotificationRecipient details
	 */
	@Override
	public NotificationRecipient saveOrUpdate(NotificationRecipientReqDto notificationRecipientReq) {
		NotificationRecipient notificationRecipient = new NotificationRecipient();
		BeanUtils.copyProperties(notificationRecipientReq, notificationRecipient);
		return notifRecipientRepository.save(notificationRecipient);
	}

	@Override
	public List<NotificationRecipient> findAll() {
		List<NotificationRecipient> notificationRecipients =notifRecipientRepository.findByIsActiveOrderByCreatedOnDesc(true);
		getNameList(notificationRecipients);
		return notificationRecipients;
	}

	@Override
	public Optional<NotificationRecipient> findByNotifRecipientId(Integer notifRecipientId) {
		return notifRecipientRepository.findById(notifRecipientId);
	}

	/**
	 * save saveUpdateNotificationMode details
	 */

	@Override
	public NotificationMode saveOrUpdate(NotificationModeReqDto notificationModeReq) {
		NotificationMode notificationMode = new NotificationMode();
		BeanUtils.copyProperties(notificationModeReq, notificationMode);
		return notifModeRepository.save(notificationMode);
	}

	@Override
	public List<NotificationMode> findAllNotifMode() {
		List<NotificationMode> notificationModes =notifModeRepository.findByIsActiveOrderByCreatedOnDesc(true);
		getNameListNotificationMode(notificationModes);
		return notificationModes;
	}

	@Override
	public Optional<NotificationMode> findByNotifModeId(Integer notifModeId) {
		return notifModeRepository.findById(notifModeId);
	}

	/**
	 * save saveUpdateNotificationEvent details
	 */

	@Override
	public NotificationEvent saveOrUpdate(NotificationEventReqDto notificationEventReq) {
		NotificationEvent notificationEvent = new NotificationEvent();
		BeanUtils.copyProperties(notificationEventReq, notificationEvent);
		return notifEventRepository.save(notificationEvent);
	}

	@Override
	public List<NotificationEvent> findAllNotifEvent() {
		List<NotificationEvent> notificationEvents =notifEventRepository.findByIsActiveOrderByCreatedOnDesc(true);
		getNameListNotificationEvent(notificationEvents);
		return notificationEvents;
	}

	@Override
	public Optional<NotificationEvent> findByNotifEventId(Integer notifModeId) {
		return notifEventRepository.findById(notifModeId);
	}
	
	/**
	 * save saveUpdateNotification details
	 */

	@Override
	public Notification saveOrUpdate(NotificationReqDto notificationReq) {
		for(Notification notification : notificationReq.getNotificationList()) {
			notifRepository.save(notification);
		}
		return null;
	}

	@Override
	public List<NotificationEntity> findAllNotif() {
		return  notifRepositoryForFinddAll.findByIsActiveOrderByCreatedOnDesc(true);
	}

	@Override
	public Optional<Notification> findByNotifId(Integer notifId) {
		return notifRepository.findById(notifId);
	}
	
	public List<Notification> getNameListNotification(List<Notification> notifications) {
		for (Notification notification : notifications) {
			List<User>  user = userRepository.findById(notification.getCreatedBy()).stream().collect(Collectors.toList());
			notification.setCreatedByName(!user.isEmpty() ? user.get(0).getUserName() : null);			
		}
		return notifications;
	} 
	
	public List<NotificationEvent> getNameListNotificationEvent(List<NotificationEvent> notificationEvents) {
		for (NotificationEvent notificationEvent : notificationEvents) {
			List<User>  user = userRepository.findById(notificationEvent.getCreatedBy()).stream().collect(Collectors.toList());
			notificationEvent.setCreatedByName(!user.isEmpty() ? user.get(0).getUserName() : null);			
		}
		return notificationEvents;
	} 
	
	public List<NotificationMode> getNameListNotificationMode(List<NotificationMode> notificationModes) {
		for (NotificationMode notificationMode : notificationModes) {
			List<User>  user = userRepository.findById(notificationMode.getCreatedBy()).stream().collect(Collectors.toList());
			notificationMode.setCreatedByName(!user.isEmpty() ? user.get(0).getUserName() : null);			
		}
		return notificationModes;
	} 
	
	public List<NotificationRecipient> getNameList(List<NotificationRecipient> notificationRecipients) {
		for (NotificationRecipient notificationRecipient : notificationRecipients) {
			List<User>  user = userRepository.findById(notificationRecipient	.getCreatedBy()).stream().collect(Collectors.toList());
			notificationRecipient.setCreatedByName(!user.isEmpty() ? user.get(0).getUserName() : null);			
		}
		return notificationRecipients;
	} 

}
