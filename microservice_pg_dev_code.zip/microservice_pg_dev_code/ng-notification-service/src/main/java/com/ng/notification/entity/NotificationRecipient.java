package com.ng.notification.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.notification.constants.Constants;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The persistent class for the M_NOTIFICATION_RECIPIENT database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Valid
@Entity
@Table(name = "M_NOTIFICATION_RECIPIENT")

public class NotificationRecipient implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "NOTIF_RECIPIENT_ID", unique = true, nullable = false)
	private Integer notifRecipientId;

	@Column(name = "CREATED_BY", nullable = false)
	private Integer createdBy;
	
	@Transient
	public String createdByName;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT,timezone = "GMT+5:30")
	@Column(name = "CREATED_ON", nullable = false, updatable = false)
	private Timestamp createdOn;

	@Column(name = "IS_ACTIVE", nullable = false)
	private Boolean isActive;

	@Column(name = "NOTIF_RECIPIENT_DESCRIPTION")
	private String notifRecipientDescription;

	@Column(name = "NOTIF_RECIPIENT_TYPE", nullable = false)
	private String notifRecipientType;

	// bi-directional many-to-one association to Notification
	@JsonBackReference(value="notifications")
	@OneToMany(mappedBy = "notificationRecipient",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private List<Notification> notifications;

}