package com.ng.notification.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ng.notification.entity.NotificationEntity;

@Repository
public interface NotificationRepositoryForFindAll extends JpaRepository<NotificationEntity, Integer> {
	@Query(value = "Select notif.NOTIFICATION_ID, notif.NOTIF_CONTENT , notif.CREATED_BY,usr.USER_NAME, notif.CREATED_ON,notif.IS_ACTIVE,"
			+ "notifEvent.NOTIF_EVENT_ID, notifEvent.NOTIF_EVENT_DESCRIPTION,"
			+ "mode.NOTIF_MODE_ID, mode.NOTIF_MODE_DESCRIPTION,"
			+ "recip.NOTIF_RECIPIENT_ID, recip.NOTIF_RECIPIENT_DESCRIPTION "
			+ "from M_NOTIFICATION notif "
			+ "inner join M_NOTIFICATION_EVENT notifEvent on notif.NOTIF_EVENT_ID = notifEvent.NOTIF_EVENT_ID "
			+ "inner join M_NOTIFICATION_MODE mode on notif.NOTIF_MODE_ID = mode.NOTIF_MODE_ID "
			+ "inner join M_NOTIFICATION_RECIPIENT recip on notif.NOTIF_RECIPIENT_ID = recip.NOTIF_RECIPIENT_ID "
			+ "inner join M_USER usr on notif.CREATED_BY = usr.USER_ID ORDER BY notif.NOTIFICATION_ID DESC ", nativeQuery= true)
	public List<NotificationEntity> findByIsActiveOrderByCreatedOnDesc(boolean b);
}
