package com.ng.notification.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.Valid;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Valid
@Entity
public class NotificationEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "NOTIFICATION_ID", unique = true, nullable = false)
	private Integer notificationId;
	
	@Column(name = "NOTIF_CONTENT", nullable = false)
	private String notifContent;
	
	@Column(name = "CREATED_BY", nullable = false)
	private Integer createdBy;	

	@Column(name = "USER_NAME", nullable = false)
	public String createdByName;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy HH:MM")
	@Column(name = "CREATED_ON", nullable = false, updatable = false)
	private Timestamp createdOn;
	
	@Column(name = "IS_ACTIVE", nullable = false)
	private Boolean isActive;
	
	@Column(name = "NOTIF_EVENT_ID", unique = true, nullable = false)
	private Integer notifEventId;
	
	@Column(name = "NOTIF_EVENT_DESCRIPTION")
	private String notifEventDescription;
	
	@Column(name = "NOTIF_MODE_ID", unique = true, nullable = false)
	private Integer notifModeId;
	
	@Column(name = "NOTIF_MODE_DESCRIPTION")
	private String notifModeDescription;
	
	@Column(name = "NOTIF_RECIPIENT_ID", unique = true, nullable = false)
	private Integer notifRecipientId;
	
	@Column(name = "NOTIF_RECIPIENT_DESCRIPTION")
	private String notifRecipientDescription;	
}