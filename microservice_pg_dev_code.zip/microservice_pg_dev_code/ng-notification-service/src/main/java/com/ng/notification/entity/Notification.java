package com.ng.notification.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.ng.notification.constants.Constants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The persistent class for the M_NOTIFICATION database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter
@Valid
@Entity
@Table(name = "M_NOTIFICATION")

public class Notification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "NOTIFICATION_ID", unique = true, nullable = false)
	private Integer notificationId;
	
	@Column(name = "NOTIF_EVENT_ID", unique = true, nullable = false)
	private Integer notifEventId;
	
	@Column(name = "NOTIF_MODE_ID", unique = true, nullable = false)
	private Integer notifModeId;
	
	@Column(name = "NOTIF_RECIPIENT_ID", unique = true, nullable = false)
	private Integer notifRecipientId;

	@Column(name = "CREATED_BY", nullable = false)
	private Integer createdBy;

	@CreationTimestamp
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT,timezone = "GMT+5:30")
	@Column(name = "CREATED_ON", nullable = false, updatable = false)
	private Timestamp createdOn;

	@Column(name = "IS_ACTIVE", nullable = false)
	private Boolean isActive;

	@NotBlank(message="Notification content can't be blank")
	@Column(name = "NOTIF_CONTENT", nullable = false)
	private String notifContent;
	
	@Transient
	public String createdByName;

	// bi-directional many-to-one association to MNotificationEvent
	@JsonBackReference(value="notificationEvent")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "NOTIF_EVENT_ID", nullable = false,insertable = false ,updatable = false)
	private NotificationEvent notificationEvent;

	// bi-directional many-to-one association to MNotificationMode
	@JsonBackReference(value="notificationMode")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "NOTIF_MODE_ID", nullable = false,insertable = false ,updatable = false)
	private NotificationMode notificationMode;

	// bi-directional many-to-one association to MNotificationRecipient
	@JsonBackReference(value="notificationRecipient")
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "NOTIF_RECIPIENT_ID", nullable = false,insertable = false ,updatable = false)
	private NotificationRecipient notificationRecipient;
}