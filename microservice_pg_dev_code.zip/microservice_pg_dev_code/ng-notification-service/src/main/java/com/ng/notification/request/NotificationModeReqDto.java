package com.ng.notification.request;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The persistent class for the M_NOTIFICATION_MODE database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
@Getter
@Setter

public class NotificationModeReqDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer notifModeId;

	private Integer createdBy;

	private Timestamp createdOn;

	private Boolean isActive;

	private String notifModeCode;

	private String notifModeDescription;

}