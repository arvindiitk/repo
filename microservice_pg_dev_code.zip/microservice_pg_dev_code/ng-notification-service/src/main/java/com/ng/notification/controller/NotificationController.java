package com.ng.notification.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ng.notification.constants.Constants;
import com.ng.notification.entity.Notification;
import com.ng.notification.entity.NotificationEntity;
import com.ng.notification.entity.NotificationEvent;
import com.ng.notification.entity.NotificationMode;
import com.ng.notification.entity.NotificationRecipient;
import com.ng.notification.request.NotificationEventReqDto;
import com.ng.notification.request.NotificationModeReqDto;
import com.ng.notification.request.NotificationRecipientReqDto;
import com.ng.notification.request.NotificationReqDto;
import com.ng.notification.response.ApiResponse;
import com.ng.notification.service.NotificationService;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@AllArgsConstructor
@RestController
@Slf4j
@Getter
@Setter
@RequestMapping("/ng-notification")
@Transactional(timeout = 180)
public class NotificationController {
	@Autowired
	NotificationService notificationService;

	/**
	 * save saveUpdateNotificationRecipient details
	 */

	@PostMapping(value = "/notifRecipient/ng-saveUpdateNotificationRecipient", consumes = { "application/json" })
	public ResponseEntity<Object> saveUpdateNotificationRecipient(
			@RequestBody NotificationRecipientReqDto notificationRecipient) {
		log.info("NotificationController: ng-saveUpdateNotificationRecipient {}", notificationRecipient);
		NotificationRecipient notifRecipient = notificationService.saveOrUpdate(notificationRecipient);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.NOTIFICATION_RECIPIENT_DETAILS_SUCCESS).data(notifRecipient).build();
		log.info("NotificationController: ng-saveUpdateNotificationRecipient response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@GetMapping("/notifRecipient/ng-getAllNotificationRecipientDetails")
	public ResponseEntity<Object> getAllNotificationRecipientDetails() {
		log.info("NotificationController :getAllNotificationRecipientDetails {} ");

		List<NotificationRecipient> filteredList = notificationService.findAll().stream()
				.filter(NotificationRecipient::getIsActive).collect(Collectors.toList());

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("NotificationController.getAllNotificationRecipientDetails : success response");
		return ResponseEntity.ok().body(apiResponse);

	}

	@PostMapping(value = "/notifRecipient/ng-getNotificationRecipientById", consumes = { "application/json" })
	public ResponseEntity<Object> getNotificationRecipientById(
			@RequestBody NotificationRecipientReqDto notificationRecipient) {
		log.info("NotificationController :getNotificationRecipientById {} ");
		Optional<NotificationRecipient> filteredList = notificationService
				.findByNotifRecipientId(notificationRecipient.getNotifRecipientId());

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[NotificationController.getNotificationRecipientById] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}

	/**
	 * save saveUpdateNotificationMode details
	 */
	@PostMapping(value = "/notifMode/ng-saveUpdateNotificationMode", consumes = { "application/json" })
	public ResponseEntity<Object> saveUpdateNotificationMode(@RequestBody NotificationModeReqDto notificationMode) {
		log.info("NotificationController: ng-saveUpdateNotificationMode {}", notificationMode);
		NotificationMode notifMode = notificationService.saveOrUpdate(notificationMode);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.NOTIFICATION_MODE_DETAILS_SUCCESS).data(notifMode).build();
		log.info("NotificationController: ng-saveUpdateNotificationRecipient response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@GetMapping("/notifMode/ng-getAllNotificationnotifModeDetails")
	public ResponseEntity<Object> getAllNotificationnotifModeDetails() {
		log.info("NotificationController :getAllNotificationnotifModeDetails {} ");

		List<NotificationMode> filteredList = notificationService.findAllNotifMode().stream()
				.filter(NotificationMode::getIsActive).collect(Collectors.toList());

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("NotificationController.getAllNotificationnotifModeDetails : success response");
		return ResponseEntity.ok().body(apiResponse);

	}

	@PostMapping(value = "/notifMode/ng-getNotificationModeById", consumes = { "application/json" })
	public ResponseEntity<Object> getNotificationModeById(@RequestBody NotificationModeReqDto notificationMode) {
		log.info("NotificationController :getNotificationModeById {} ");
		Optional<NotificationMode> filteredList = notificationService
				.findByNotifModeId(notificationMode.getNotifModeId());

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[NotificationController.getNotificationModeById] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}

	/**
	 * save saveUpdateNotificationEvent details
	 */
	@PostMapping(value = "/notifEvent/ng-saveUpdateNotificationEvent", consumes = { "application/json" })
	public ResponseEntity<Object> saveUpdateNotificationEvent(@RequestBody NotificationEventReqDto notificationEvent) {
		log.info("NotificationController: ng-saveUpdateNotificationEvent {}", notificationEvent);
		NotificationEvent notifEvent = notificationService.saveOrUpdate(notificationEvent);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.NOTIFICATION_EVENT_DETAILS_SUCCESS).data(notifEvent).build();
		log.info("NotificationController: ng-saveUpdateNotificationEvent response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@GetMapping("/notifEvent/ng-getAllNotificationnotifEventDetails")
	public ResponseEntity<Object> getAllNotificationnotifEventDetails() {
		log.info("NotificationController :getAllNotificationnotifEventDetails {} ");

		List<NotificationEvent> filteredList = notificationService.findAllNotifEvent().stream()
				.filter(NotificationEvent::getIsActive).collect(Collectors.toList());

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("NotificationController.getAllNotificationnotifEventDetails : success response");
		return ResponseEntity.ok().body(apiResponse);

	}

	@PostMapping(value = "/notifEvent/ng-getNotificationEventById", consumes = { "application/json" })
	public ResponseEntity<Object> getNotificationEventById(@RequestBody NotificationEventReqDto notificationEvent) {
		log.info("NotificationController :getNotificationEventById {} ");
		Optional<NotificationEvent> filteredList = notificationService
				.findByNotifEventId(notificationEvent.getNotifEventId());

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[NotificationController.getNotificationEventById] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}

	/**
	 * save saveUpdateNotification details
	 */
	@PostMapping(value = "/notif/ng-saveUpdateNotification", consumes = { "application/json" })
	public ResponseEntity<Object> saveUpdateNotification(@Valid @RequestBody NotificationReqDto notification) {
		log.info("NotificationController: ng-saveUpdateNotification {}", notification);
		Notification notif = notificationService.saveOrUpdate(notification);
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.NOTIFICATION_DETAILS_SUCCESS).data(notif).build();
		log.info("NotificationController: ng-saveUpdateNotification response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@GetMapping("/notif/ng-getAllNotificationNotifDetails")
	public ResponseEntity<Object> getAllNotificationNotifDetails() {
		log.info("NotificationController :getAllNotificationNotifDetails {} ");

		List<NotificationEntity> filteredList = notificationService.findAllNotif().stream()
				.filter(NotificationEntity::getIsActive).collect(Collectors.toList());

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("NotificationController.getAllNotificationNotifDetails : success response");
		return ResponseEntity.ok().body(apiResponse);

	}

	@PostMapping(value = "/notif/ng-getNotificationById", consumes = { "application/json" })
	public ResponseEntity<Object> getNotificationById(@RequestBody NotificationReqDto notification) {
		log.info("NotificationController :getNotificationById {} ");
		Optional<Notification> filteredList = notificationService.findByNotifId(notification.getNotificationId());

		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.SUCCESS).data(filteredList).build();
		log.info("[NotificationController.getNotificationById] : success response");
		return ResponseEntity.ok().body(apiResponse);

	}

}
