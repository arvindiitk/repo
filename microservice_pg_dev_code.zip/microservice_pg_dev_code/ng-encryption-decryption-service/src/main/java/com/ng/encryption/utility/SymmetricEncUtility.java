package com.ng.encryption.utility;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.Validate;
import org.bouncycastle.jcajce.provider.digest.SHA256;
import org.bouncycastle.jcajce.provider.digest.SHA3;

import com.ng.encryption.constants.Constants;

import lombok.extern.slf4j.Slf4j;

/**
 * The Class PasswordUtility.
 * 
 * @author Adarsh Kumar
 * @since June 1, 2018
 */
@Slf4j
public class SymmetricEncUtility implements Serializable {
	/**
	 * 
	 */

	private static final long serialVersionUID = 3998105784709641266L;
	private static final Random RANDOM = new SecureRandom();
	private static final int DEFAULT_SIZE = 256;
	private static final char[] symbols;

	static {
		final StringBuilder tmp = new StringBuilder();
		for (char ch = '0'; ch <= '9'; ++ch) {
			tmp.append(ch);
		}
		for (char ch = 'a'; ch <= 'z'; ++ch) {
			tmp.append(ch);
		}
		symbols = tmp.toString().toCharArray();
	}

	/**
	 * Gets the salt 64.
	 *
	 * @return the salt 64
	 */
	public byte[] getSalt64() {
		return getSalt(DEFAULT_SIZE);
	}

	/**
	 * Gets the salt 32.
	 *
	 * @return the salt 32
	 */
	public byte[] getSalt32() {
		return getSalt(32);
	}

	public byte[] getSalt(int size) {
		final byte[] salt;
		if (size < 32) {
			String.format("Size < 32, using default of: %d", DEFAULT_SIZE);
			salt = new byte[DEFAULT_SIZE];
		} else {
			salt = new byte[size];
		}
		RANDOM.nextBytes(salt);
		return salt;
	}

	public byte[] hash(String password, byte[] salt) {

		Validate.notNull(password, Constants.PASSWORD);
		Validate.notNull(salt, "Salt must not be null");

		final byte[] passwordBytes = password.getBytes(StandardCharsets.UTF_8);
		final byte[] all = ArrayUtils.addAll(passwordBytes, salt);
		SHA3.DigestSHA3 md = new SHA3.Digest512();
		md.update(all);
		return md.digest();

	}

	/**
	 * Generates SHA256 hash of the supplied screen
	 *
	 * @param password the password
	 * @return the byte[]
	 */
	public static String hashWithoutSalt(String password) throws UnsupportedEncodingException {

		Validate.notNull(password, Constants.PASSWORD);

		final byte[] passwordBytes = password.getBytes(StandardCharsets.UTF_8);
		final byte[] all = ArrayUtils.addAll(passwordBytes);
		SHA256.Digest md = new SHA256.Digest();
		md.update(all);
		return bytesArrayToStr(md.digest());

	}

	public boolean isExpectedPassword(final String password, final byte[] salt, final byte[] hash) {

		Validate.notNull(password, "Password must not be null");
		Validate.notNull(salt, "Salt must not be null");
		Validate.notNull(hash, "Hash must not be null");

		final byte[] passwordBytes = password.getBytes(StandardCharsets.UTF_8);
		final byte[] all = ArrayUtils.addAll(passwordBytes, salt);

		SHA3.DigestSHA3 md = new SHA3.Digest512();
		md.update(all);
		final byte[] digest = md.digest();
		return Arrays.equals(digest, hash);

	}

	/**
	 * Compares the two passwords.
	 *
	 * @param password the password
	 * @param hash     the hash
	 * @return true, if is expected password
	 */
	public boolean isExpectedPassword(final String password, final byte[] hash) {

		Validate.notNull(password, "Password must not be null");
		Validate.notNull(hash, "Hash must not be null");

		final byte[] passwordBytes = password.getBytes(StandardCharsets.UTF_8);
		//final byte[] all = ArrayUtils.addAll(passwordBytes);

		SHA256.Digest md = new SHA256.Digest();
		md.update(passwordBytes);
		final byte[] digest = md.digest();
		return Arrays.equals(digest, hash);

	}

	public static String bytesArrayToStr(byte[] array) {
		StringBuilder hexString = new StringBuilder();
		for (int i = 0; i < array.length; i++) {
			String hex = Integer.toHexString(0xff & array[i]);
			if (hex.length() == 1)
				hexString.append('0');
			hexString.append(hex);
		}
		return hexString.toString();
	}

	public static String generateRandomPassword(final Integer length) {

		if (length < 1) {
			throw new IllegalArgumentException("length must be greater than 0");
		}

		final char[] buf = new char[length];
		for (int idx = 0; idx < buf.length; ++idx) {
			buf[idx] = symbols[RANDOM.nextInt(symbols.length)];
		}
		return shuffle(new String(buf));
	}

	private static String shuffle(final String input) {
		final List<Character> characters = new ArrayList<Character>();
		for (char c : input.toCharArray()) {
			characters.add(c);
		}
		final StringBuilder output = new StringBuilder(input.length());
		SecureRandom srcRandom = new SecureRandom();
		while (!characters.isEmpty()) {

			int randPicker = (int) (srcRandom.nextFloat() * characters.size());

			output.append(characters.remove(randPicker));
		}
		return output.toString();
	}

	public static Map<String, String> getPassForDB(String loginId, String simplePass) {

		// Login request pass encryption
		Map<String, String> saltPass = new HashMap<>();
		AesUtil aesUtil = new AesUtil(256, 1000);
		String hexloginId = Hex.encodeHexString(loginId.getBytes());
		String four = loginId;
		if (four.length() >= 16) {
			four = four.substring(0, 16);
		} else {
			while (four.length() < 16) {
				four = four + four;
			}
			four = four.substring(0, 16);
		}
		String hexFour = Hex.encodeHexString(four.getBytes());
		String passToUi = aesUtil.encrypt(hexloginId, hexFour, hexloginId, simplePass);
		String passToUa = aesUtil.encrypt(hexloginId, hexFour, hexloginId, passToUi);
		String dbSalt = HashUtil.getSalt();
		saltPass.put("salt", dbSalt);
		String passToDb = null;
		try {
			passToDb = gethashedPass(dbSalt, passToUa);
		} catch (Exception e) {
			log.info("Hasing failed for pass", e);
		}
		saltPass.put("pass", passToDb);
		return saltPass;
	}

	public static String gethashedPass(String salt, String pwd) throws Exception {
		return HashUtil.createHash(pwd, salt);
	}

	public static Map<String, String> changePassAndSalt(String pwd) throws Exception {
		Map<String, String> saltPass = new HashMap<>();
		String salt = HashUtil.getSalt();
		saltPass.put("salt", salt);
		String dbPass = HashUtil.createHash(pwd, salt);
		saltPass.put("pass", dbPass);
		return saltPass;
	}

	public static String dataEncryption(String loginId, String pass) {
		AesUtil aesUtil = new AesUtil(256, 1000);
		String hexloginId = Hex.encodeHexString(loginId.getBytes());
		String four = loginId;
		if (four.length() >= 16) {
			four = four.substring(0, 16);
		} else {
			while (four.length() < 16) {
				four = four + four;
			}
			four = four.substring(0, 16);
		}
		String hexFour = Hex.encodeHexString(four.getBytes());
		return aesUtil.encrypt(hexloginId, hexFour, hexloginId, pass);
	}

	public static String dataDecryption(String loginId, String pass) {
		AesUtil aesUtil = new AesUtil(256, 1000);
		String hexloginId = Hex.encodeHexString(loginId.getBytes());
		String four = loginId;
		if (four.length() >= 16) {
			four = four.substring(0, 16);
		} else {
			while (four.length() < 16) {
				four = four + four;
			}
			four = four.substring(0, 16);
		}
		String hexFour = Hex.encodeHexString(four.getBytes());
		return aesUtil.decrypt(hexloginId, hexFour, hexloginId, pass);
	}

	public static String dataEncryption(String loginId, byte[] pass) {
		AesUtil aesUtil = new AesUtil(256, 1000);
		String hexloginId = Hex.encodeHexString(loginId.getBytes());
		String four = loginId;
		if (four.length() >= 16) {
			four = four.substring(0, 16);
		} else {
			while (four.length() < 16) {
				four = four + four;
			}
			four = four.substring(0, 16);
		}
		String hexFour = Hex.encodeHexString(four.getBytes());
		return aesUtil.encrypt(hexloginId, hexFour, hexloginId, pass);
	}

	public static String dataDecryption(String loginId, byte[] pass) {
		AesUtil aesUtil = new AesUtil(256, 1000);
		String hexloginId = Hex.encodeHexString(loginId.getBytes());
		String four = loginId;
		if (four.length() >= 16) {
			four = four.substring(0, 16);
		} else {
			while (four.length() < 16) {
				four = four + four;
			}
			four = four.substring(0, 16);
		}
		String hexFour = Hex.encodeHexString(four.getBytes());
		return aesUtil.decrypt(hexloginId, hexFour, hexloginId, pass);
	}
}
