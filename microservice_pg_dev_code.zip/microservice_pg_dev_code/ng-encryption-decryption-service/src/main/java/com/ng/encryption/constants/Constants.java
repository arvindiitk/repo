package com.ng.encryption.constants;

public final class Constants  {
	
	private Constants() {
		super();
	}
	public static final String TIME_FORMAT = "HH:mm:ss";
    public static final String EMPTY = "";
    public static final String SUCCESS = "SUCCESS";
    public static final String GENERATE_KEY_PAIR = "Key Pair Generated Successfully for User-Id ";
    public static final String GENERATE_PUBLIC_KEY = "Public Key Generated Successfully for User-Id ";
    public static final String GET_PUBLIC_KEY = "Public Key Getting Successfully of User-Id ";
    public static final String GENERATE_SYMMETERIC_KEY = "Symmeteric Key Generated Successfully for User-Id ";
    public static final String GET_SYMMETERIC_KEY = "Symmeteric Key Getting Successfully Of User-Id ";
    public static final String GENERATE_ENCRYPTED_DATA = "Input Data Encrypted Successfully.";
  
    public static final String ERROR = "error";
    public static final String DATE_FORMAT = "dd/MM/yyyy";
	public static final String DATE_TIME_FORMAT = "dd-MM-yyyy HH:mm";
	public static final String E_0001 = "01234";
	public static final String QR_ERROR="QR00001";
	public static final String PRIMERRY_KEY_ERROR = "E002620";
    public static final String E002620 = "Violation of PRIMARY KEY constraint. Cannot insert duplicate key.";
    public static final String CONSTRAINT_SQL_ERROR = "E002627";
    public static final String E002627 = "Constraint Violation Exception.";
    public static final String SQL_ERROR = "E002628";
    public static final String E002628 = "Data Base Server Exception.";
    public static final String UNIQUE_KEY_CONSTRAINT_ERROR = "E002629";
	public static final String E002629 = "Record already exists";
	public static final int SYMMETRIC_KEY_SIZE = 128;
	public static final String PASSWORD= "Password must not be null";
	public static final int RSAKEYSIZE= 4096; //2048
	public static String CIPHER_MODE = "RSA/None/OAEPWithMD5AndMGF1Padding";


}
