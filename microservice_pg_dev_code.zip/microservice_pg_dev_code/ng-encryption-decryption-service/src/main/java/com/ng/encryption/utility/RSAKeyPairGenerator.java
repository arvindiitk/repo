package com.ng.encryption.utility;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.Base64;
import java.util.Properties;

import com.ng.encryption.constants.Constants;
import com.ng.encryption.response.GenerateKeyPairsResDto;

import lombok.extern.slf4j.Slf4j;
@Slf4j
public class RSAKeyPairGenerator {

	public static void writeToFile(String path, String key) throws IOException {
		File f = new File(Normalizer.normalize(path, Form.NFKC));
		f.getParentFile().mkdirs();
		FileWriter fw = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(fw);

		try {
			bw.write(key);

		} finally {
			if (null != bw)
				bw.close();
			if (null != fw)
				fw.close();
		}
	}

	public static String readFromFile(String path) throws IOException {
		FileReader fw = new FileReader(Normalizer.normalize(path, Form.NFKC));
		BufferedReader bw = new BufferedReader(fw);
		String publicKey = null;
		try {
			publicKey = bw.readLine();
		} finally {
			if (null != bw)
				bw.close();
			if (null != fw)
				fw.close();
		}
		return publicKey;
	}

	public static GenerateKeyPairsResDto generateKeyPair(String encryptionPass, String path) throws Exception {
		if (encryptionPass.isEmpty())
			throw new Exception("Please provide the encryption password");
		if (path.isEmpty())
			path = "RSA";
		KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
		keyGen.initialize(Constants.RSAKEYSIZE);

		KeyPair pair = keyGen.generateKeyPair();
		PrivateKey privateKey = pair.getPrivate();
		PublicKey publicKey = pair.getPublic();
		GenerateKeyPairsResDto keyPairsResponse = new GenerateKeyPairsResDto();
		keyPairsResponse.setPrivateKey(
				ecryptAndEncodePrivateKey(encryptionPass, Base64.getEncoder().encodeToString(privateKey.getEncoded())));
		keyPairsResponse.setPublicKey(Base64.getEncoder().encodeToString(publicKey.getEncoded()));
		writeToFile(path + "/privateKey.txt", keyPairsResponse.getPrivateKey());
		writeToFile(path + "/publicKey.txt", keyPairsResponse.getPublicKey());
		return keyPairsResponse;
	}

	public static GenerateKeyPairsResDto generateKeyPair(String path) throws Exception {
		if (path.isEmpty())
			path = "RSA";
		GenerateKeyPairsResDto keyPairsResponse = new GenerateKeyPairsResDto();
		readFromFile(path + "/publicKey.txt");
		keyPairsResponse.setPublicKey(readFromFile(path + "/publicKey.txt"));
		return keyPairsResponse;
	}

	public static String ecryptAndEncodePrivateKey(String encryptionPass, String privateKey) {

		log.info("RSAKeyPairGenerator.ecryptAndEncodePrivateKey. private key encryption: started");
		String hashedValOfPrivateKey = null;
		try {
			hashedValOfPrivateKey = SymmetricEncUtility.hashWithoutSalt(privateKey);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String encryptedPrivateKey = SymmetricEncUtility.dataEncryption(encryptionPass, privateKey);
		log.info("RSAKeyPairGenerator.ecryptAndEncodePrivateKey. private key encryption: completed");
		String encodedEncryptedPrivateKey = Base64.getEncoder().encodeToString(encryptedPrivateKey.getBytes());
		String encodedEncryptedHashed = Base64.getEncoder().encodeToString(hashedValOfPrivateKey.getBytes());
		String mergedValue = encodedEncryptedPrivateKey + "&&" + encodedEncryptedHashed;
		return Base64.getEncoder().encodeToString(mergedValue.getBytes());

	}

	public static String decryptAndDecodePrivateKey(String decryptionPass, String privateKey) throws Exception {

		String mergedEncryptedData = new String(Base64.getDecoder().decode(privateKey.getBytes()));
		log.info("Merged data decoding is completed");
		String[] splitMergedEncrypted = mergedEncryptedData.split("&&");
		log.info(
				"Splitting base64EncryptedInputData,base64EncryptedSymmetricKey,base64EncryptedHashedValueOfData is  completed");
		String decodedEncryptedPrivate = new String(Base64.getDecoder().decode(splitMergedEncrypted[0].getBytes()));
		log.info("Decrypted Data encoding is completed");
		String decodedEncryptedHashed = new String(Base64.getDecoder().decode(splitMergedEncrypted[1].getBytes()));
		log.info("Decrypted symmetric encoding is completed");
		String decryptedInputData = null;
		try {
			decryptedInputData = SymmetricEncUtility.dataDecryption(decryptionPass, decodedEncryptedPrivate);
		} catch (Exception ee) {
			throw new Exception("Incorrect combination of passcode / private key.");
		}
		log.info("Data deryption using symmetric key is completed");
		String hashedValOfPrivateKey = SymmetricEncUtility.hashWithoutSalt(decryptedInputData);
		if (decodedEncryptedHashed.equals(hashedValOfPrivateKey))
			return decryptedInputData;
		else
			throw new Exception("Checksum failed. Incorrect combination of passcode / private key.");
	}

	public static Properties readPropertiesFile(String fileName) throws IOException {
		FileInputStream fis = null;
		Properties prop = null;
		try {
			String relativePath = new File(Normalizer.normalize(fileName, Form.NFKC)).getCanonicalPath();
			fis = new FileInputStream(relativePath);
			prop = new Properties();
			prop.load(fis);
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			fis.close();
		}
		return prop;
	}
	
}
