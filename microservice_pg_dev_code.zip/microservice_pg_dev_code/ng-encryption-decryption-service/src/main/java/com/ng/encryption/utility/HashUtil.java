package com.ng.encryption.utility;

import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class HashUtil {

	private static final Logger log = LoggerFactory.getLogger(HashUtil.class);
	private static final String PBKDF2_ALGORITHM = "PBKDF2WithHmacSHA1";

	private static final int SALT_BYTE_SIZE = 24;
	private static final int HASH_BYTE_SIZE = 24;
	private static final int PBKDF2_ITERATIONS = 1000;

	/**
	 * 
	 * @return Random hex string salt
	 */
	public static String getSalt() {
		SecureRandom random = new SecureRandom();
		byte[] salt = new byte[SALT_BYTE_SIZE];
		random.nextBytes(salt);

		return toHexString(salt);
	}

	/**
	 *
	 * @return Random % digit Number
	 */
	public static int getRandomNumber() {
		SecureRandom random = new SecureRandom();
		int num = random.nextInt(10000);
		return num;
	}

	/**
	 * Create Hash by input content and salt
	 * 
	 * @param content
	 * @param hexSalt
	 *            Must be hexadecimal string
	 * @return
	 * @throws TimsServiceException 
	 */
	public static String createHash(String content, String hexSalt)
			throws Exception {
		byte[] hash = pbkdf2(content.toCharArray(), fromHexString(hexSalt), PBKDF2_ITERATIONS, HASH_BYTE_SIZE);
		return toHexString(hash);
	}

	private static byte[] pbkdf2(char[] content, byte[] salt, int iterations, int bytes)
			throws Exception {
		PBEKeySpec spec = new PBEKeySpec(content, salt, iterations, bytes * 8);
		SecretKeyFactory skf;
		try {
		skf = SecretKeyFactory.getInstance(PBKDF2_ALGORITHM);
		return skf.generateSecret(spec).getEncoded();
		} catch (NoSuchAlgorithmException | InvalidKeySpecException checkedException) {
			log.error("Issue with Hashing, either NO Algo Found or Key Ussue", checkedException);
			throw new Exception(checkedException.getMessage());
		}
	}

	private static byte[] fromHexString(String hex) {
		byte[] binary = new byte[hex.length() / 2];
		for (int i = 0; i < binary.length; i++) {
			binary[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
		}
		return binary;
	}

	private static String toHexString(byte[] array) {
		BigInteger bi = new BigInteger(1, array);
		String hex = bi.toString(16);
		int paddingLength = (array.length * 2) - hex.length();
		if (paddingLength > 0)
			return String.format("%0" + paddingLength + "d", 0) + hex;
		else
			return hex;
	}

}
