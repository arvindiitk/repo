package com.ng.encryption.service;

import org.springframework.stereotype.Service;

import com.ng.encryption.request.DecryptDataRequestDto;
import com.ng.encryption.request.EncryptDataRequestDto;
import com.ng.encryption.request.GenerateKeyPairReqDto;
import com.ng.encryption.response.DecryptDataResDto;
import com.ng.encryption.response.EncryptDataResDto;
import com.ng.encryption.response.GenerateKeyPairsResDto;

@Service
public interface EncryptionService {
	
	public GenerateKeyPairsResDto generateKeyPairs(GenerateKeyPairReqDto keyPairsRequest)throws Exception;

	public GenerateKeyPairsResDto getPublicKey(GenerateKeyPairReqDto keyPairsRequest)throws Exception;

	public GenerateKeyPairsResDto generateSymmetricKey(GenerateKeyPairReqDto keyPairsRequest)throws Exception;

	public EncryptDataResDto encryptionData(EncryptDataRequestDto encRequest)throws Exception;

	public DecryptDataResDto decryptionData(DecryptDataRequestDto decRequest) throws Exception;

	public GenerateKeyPairsResDto getSymmetricKeyByUsers(GenerateKeyPairReqDto keyPairsRequest)throws Exception;
	
	public EncryptDataResDto encryptionDataWithRandomSymmetricKey(EncryptDataRequestDto encRequest)throws Exception;

	public DecryptDataResDto decryptionDataWithRandomSymmetricKey(DecryptDataRequestDto decRequest) throws Exception;
}