package com.ng.encryption.response;

public class DecryptDataResDto {

	String outputData;

	public String getOutputData() {
		return outputData;
	}

	public void setOutputData(String outputData) {
		this.outputData = outputData;
	}
}
