package com.ng.encryption.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ng.encryption.constants.Constants;
import com.ng.encryption.exception.ResourceNotFoundException;
import com.ng.encryption.request.DecryptDataRequestDto;
import com.ng.encryption.request.EncryptDataRequestDto;
import com.ng.encryption.request.GenerateKeyPairReqDto;
import com.ng.encryption.response.ApiResponse;
import com.ng.encryption.response.DecryptDataResDto;
import com.ng.encryption.response.EncryptDataResDto;
import com.ng.encryption.response.GenerateKeyPairsResDto;
import com.ng.encryption.service.EncryptionService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/ng-encryption-decryption")
@Transactional(timeout = 300)
public class EncryptionController {

	@Autowired
	EncryptionService encService;
	

	@PostMapping(value = "/generateKeyPairsByOrgIdAndUser", consumes = { "application/json" })
	public ResponseEntity<Object> generateKeyPairsByOrgIdAndUser(@RequestBody GenerateKeyPairReqDto keyPairsRequest)
			throws ResourceNotFoundException, Exception {

		log.info("EncryptionController generateKeyPairsByOrgIdAndUser : Starts");
		GenerateKeyPairsResDto keyPairsResponse = new GenerateKeyPairsResDto();
		//try {
			keyPairsResponse = encService.generateKeyPairs(keyPairsRequest);
		/*} catch (Exception ee) {
			log.info(" EncryptionController Getting Error generateKeyPairs Method:" + ee);
		}*/
		log.info("Natgrid EncryptionController generateKeyPairs : Ends");
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.GENERATE_KEY_PAIR+" "+keyPairsRequest.getUserId()).data(keyPairsResponse).build();
		log.info(" EncryptionController  generateKeyPairs: success response");
		return ResponseEntity.ok().body(apiResponse);

	}

	@PostMapping(value = "/getPublicKeyByOrgIdAndUser", consumes = { "application/json" })
	public ResponseEntity<Object> getPublicKeyByOrgIdAndUser(@RequestBody GenerateKeyPairReqDto keyPairsRequest)
			throws ResourceNotFoundException, Exception {
		log.info("EncryptionController getPublicKeyByOrgIdAndUser : Starts");
		GenerateKeyPairsResDto publicKeyResponse = new GenerateKeyPairsResDto();
		//try {
			publicKeyResponse = encService.getPublicKey(keyPairsRequest);
		/*} catch (Exception exp) {
			log.info("EncryptionController Getting error in getPublicKey Method :" +exp);
			
		}*/
		log.info("EncryptionController getPublicKeyByOrgIdAndUser : End");
		
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.GET_PUBLIC_KEY+" "+keyPairsRequest.getUserId()).data(publicKeyResponse).build();
		
		log.info(" EncryptionController  getPublicKeyByOrgIdAndUser: success response");
		return ResponseEntity.ok().body(apiResponse);
		
	}

	@PostMapping(value = "/generateSymmetricKeyByOrgIdUserAndPublicKey",consumes = { "application/json" })
	public ResponseEntity<Object> generateSymmetricKeyByOrgIdAndUser(@RequestBody GenerateKeyPairReqDto keyPairsRequest)
			throws ResourceNotFoundException, Exception {
		log.info("EncryptionController generateSymmetricKeyByOrgIdAndUser : Starts");
		GenerateKeyPairsResDto genSymmetricKeyResponse = new GenerateKeyPairsResDto();
		//try {
			genSymmetricKeyResponse = encService.generateSymmetricKey(keyPairsRequest);
		/*} catch (Exception ee) {
			log.info("EncryptionController Error While Getting generateSymmetricKey Method:"+ee);
			
		}*/
		log.info(" EncryptionController generateSymmetricKeyByOrgIdAndUser : Ends");
		
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.GENERATE_SYMMETERIC_KEY+" "+keyPairsRequest.getUserId()).data(genSymmetricKeyResponse).build();
		
		log.info(" EncryptionController  generateSymmetricKeyByOrgIdAndUser: success response");
		return ResponseEntity.ok().body(apiResponse);
		
	}

	@PostMapping(value = "/getSymmetricKeyUsersByOrgIdUserAndPublicKeys", consumes = { "application/json" })
	public ResponseEntity<Object> getSymmetricKeyUsersByOrgIdUserAndPublicKeys(@RequestBody GenerateKeyPairReqDto keyPairsRequest)
			throws ResourceNotFoundException, Exception {
		
		log.info(" EncryptionController getSymmetricKeyUsersByOrgIdUserAndPublicKeys : Starts");
		GenerateKeyPairsResDto symmetricKeyPairsResponse = new GenerateKeyPairsResDto();
		//try {
			symmetricKeyPairsResponse = encService.getSymmetricKeyByUsers(keyPairsRequest);
		/*} catch (Exception ee) {
			log.info(" EncryptionController Error While Getting getSymmetricKeyByUsers Method: Ends");
			
		}*/
		log.info(" EncryptionController.getSymmetricKeyUsersByOrgIdUserAndPublicKeys : Ends");
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.GET_SYMMETERIC_KEY+" "+keyPairsRequest.getUserId()).data(symmetricKeyPairsResponse).build();
		
		log.info(" EncryptionController  getSymmetricKeyUsersByOrgIdUserAndPublicKeys: success response");
		return ResponseEntity.ok().body(apiResponse);
	}

	@PostMapping(value = "/generateEncryptedData",consumes = { "application/json" })
	public ResponseEntity<Object> generateEncryptedData(@RequestBody EncryptDataRequestDto encRequest)
			throws ResourceNotFoundException, Exception {
		log.info("Natgrid EncryptionController.generateEncryptedData : Starts");
		EncryptDataResDto encryptDataResponse = new EncryptDataResDto();
		//try {
			encryptDataResponse = encService.encryptionData(encRequest);
		/*} catch (Exception ee) {
			log.info(" EncryptionController Error While Getting encryptionData Method:"+ee);
			
		}*/
		log.info(" EncryptionController generateEncryptedData : Ends");
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.GENERATE_ENCRYPTED_DATA).data(encryptDataResponse).build();
		
		log.info(" EncryptionController  generateEncryptedData: success response");
		return ResponseEntity.ok().body(apiResponse);
		
	}

	@PostMapping(value = "/generateDecryptedData", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> generateDecryptedData(@RequestBody DecryptDataRequestDto decRequest)
			throws ResourceNotFoundException, Exception {
		log.info("Natgrid EncryptionController.generateDecryptedData : Starts");

		DecryptDataResDto decryptDataResponse = new DecryptDataResDto();
		//try {
			decryptDataResponse = encService.decryptionData(decRequest);
		/*} catch (Exception ee) {
			log.info("Error occurred during decryption." + ee);
			
		}*/
		log.info(" EncryptionController generateDecryptedData : Ends");
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.GENERATE_ENCRYPTED_DATA).data(decryptDataResponse).build();
		
		log.info(" EncryptionController  generateDecryptedData: success response");
		return ResponseEntity.ok().body(apiResponse);
		
	}
	
	
	@PostMapping(value = "/generateEncryptedDataWithRandomSymmetricKey",consumes = { "application/json" })
	public ResponseEntity<Object> generateEncryptedDataWithRandomSymmetricKey(@RequestBody EncryptDataRequestDto encRequest)
			throws ResourceNotFoundException, Exception {
		log.info("Natgrid EncryptionController.generateEncryptedData : Starts");
		EncryptDataResDto encryptDataResponse = new EncryptDataResDto();
		//try {
			encryptDataResponse = encService.encryptionDataWithRandomSymmetricKey(encRequest);
		/*} catch (Exception ee) {
			log.info(" EncryptionController Error While Getting encryptionData Method:"+ee);
			
		}*/
		log.info(" EncryptionController generateEncryptedData : Ends");
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.GENERATE_ENCRYPTED_DATA).data(encryptDataResponse).build();
		
		log.info(" EncryptionController  generateEncryptedData: success response");
		return ResponseEntity.ok().body(apiResponse);
		
	}

	@PostMapping(value = "/generateDecryptedDataWithRandomSymmetricKey", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> generateDecryptedDataWithRandomSymmetricKey(@RequestBody DecryptDataRequestDto decRequest)
			throws ResourceNotFoundException, Exception {
		log.info("Natgrid EncryptionController.generateDecryptedData : Starts");

		DecryptDataResDto decryptDataResponse = new DecryptDataResDto();
		//try {
			decryptDataResponse = encService.decryptionDataWithRandomSymmetricKey(decRequest);
		/*} catch (Exception ee) {
			log.info("Error occurred during decryption." + ee);
			
		}*/
		log.info(" EncryptionController generateDecryptedData : Ends");
		ApiResponse<?> apiResponse = ApiResponse.builder().status(String.valueOf(HttpStatus.OK.value()))
				.message(Constants.GENERATE_ENCRYPTED_DATA).data(decryptDataResponse).build();
		
		log.info(" EncryptionController  generateDecryptedData: success response");
		return ResponseEntity.ok().body(apiResponse);
		
	}

}
