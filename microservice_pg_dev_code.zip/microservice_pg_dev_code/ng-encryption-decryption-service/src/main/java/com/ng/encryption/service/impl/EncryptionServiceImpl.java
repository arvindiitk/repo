package com.ng.encryption.service.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ng.encryption.constants.Constants;
import com.ng.encryption.request.DecryptDataRequestDto;
import com.ng.encryption.request.EncryptDataRequestDto;
import com.ng.encryption.request.GenerateKeyPairReqDto;
import com.ng.encryption.response.DecryptDataResDto;
import com.ng.encryption.response.EncryptDataResDto;
import com.ng.encryption.response.GenerateKeyPairsResDto;
import com.ng.encryption.service.EncryptionService;
import com.ng.encryption.utility.AesUtil;
import com.ng.encryption.utility.RSAKeyPairGenerator;
import com.ng.encryption.utility.RSAUtil;
import com.ng.encryption.utility.SymmetricEncUtility;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class EncryptionServiceImpl implements EncryptionService {

	@Value("${key.generation.path}")
	private String keyGenerationPath;


	private String readKeyFromPath(String userId, String orgId)throws Exception {
		String privateKey = null;
		try {
			privateKey = new String(
					Files.readAllBytes(Paths.get(keyGenerationPath + orgId + "_" + userId + "/privateKey.txt")),
					StandardCharsets.UTF_8);
		} catch (Exception ee) {
			log.info("Private key not found"+ee);
			throw new Exception("Private Key not found");
		}

		return privateKey.trim();

	}

	private String readPubKeyFromPath(String userId, String orgId) throws Exception {
		String publicKey = null;

		try {
			publicKey = new String(
					Files.readAllBytes(Paths.get(keyGenerationPath + orgId + "_" + userId + "/publicKey.txt")),
					StandardCharsets.UTF_8);

		} catch (Exception ee) {
			log.info("Public key not found");
			throw new Exception("Public Key not found");
		}

		if (publicKey.isEmpty()) {
			log.info("Public key not found");
		}

		return publicKey.trim();
	}

	public EncryptDataResDto encryptionData(EncryptDataRequestDto encRequest) throws Exception{
		log.info("EncryptionDecryptionService.encryptionData : Start");
		String hashedValueOfInputData = null;
		String privateKey = null;
		String encryptedInputData = null;
		long startEncrytionAt = System.currentTimeMillis();

		try {
			String passcodePrivateKey = readKeyFromPath(encRequest.getUserId(), encRequest.getOrgId());
			privateKey = RSAKeyPairGenerator.decryptAndDecodePrivateKey(encRequest.getPassCode(), passcodePrivateKey);

			String symmetricKey = RSAUtil.decrypt(encRequest.getGeneratedSymmetricKey(), privateKey);

			encryptedInputData = SymmetricEncUtility.dataEncryption(symmetricKey, encRequest.getInputData());
			hashedValueOfInputData = SymmetricEncUtility.hashWithoutSalt(encRequest.getInputData());

		} catch (Exception ee) {
			log.info(
					"EncryptionServiceImpl Error while getting passcodePrivateKey|symmetricKey|encryptedInputData|hashedValueOfInputData");
			throw new Exception("Exception during encryption of data");

		}
		String encryptedHashedValueOfData = null;
		try {

			encryptedHashedValueOfData = RSAUtil.encryptUsingPrivate(hashedValueOfInputData, privateKey);
			log.info("Hash encryption using source private key is completed");
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
				| NoSuchAlgorithmException e) {
			log.info("Invalid source private key.");

		} catch (Exception e) {
			log.info("Invalid source private key.");
			throw new Exception("Exception during encryption of data");
		}

		String base64EncryptedInputData = Base64.getEncoder().encodeToString(encryptedInputData.getBytes());
		String base64EncryptedHashedValueOfData = Base64.getEncoder()
				.encodeToString(encryptedHashedValueOfData.getBytes());

		String mergeData = base64EncryptedInputData + "&&" + base64EncryptedHashedValueOfData;
		log.info(
				"Merging base64EncryptedInputData,base64EncryptedHashedValueOfData is  completed");
		String encResponseData = Base64.getEncoder().encodeToString(mergeData.getBytes());
		log.info("Merged data encoding is completed");
		EncryptDataResDto encryptDataResponse = new EncryptDataResDto();
		encryptDataResponse.setOutputData(encResponseData);
		long endEncrytionAt = System.currentTimeMillis();
		log.info("Total time is encryption process is :" + (endEncrytionAt - startEncrytionAt));
		log.info("EncryptionDecryptionService.encryptionData : End");

		return encryptDataResponse;
	}

	public DecryptDataResDto decryptionData(DecryptDataRequestDto decRequest) throws Exception{

		long startDecryptionAt = System.currentTimeMillis();

		String payload = decRequest.getInputData();
		log.info("EncryptionDecryptionService.decryptionData : Start. Payload size: "
				+ (payload == null ? "null" : payload.length()));

		String mergedEncryptedData = new String(Base64.getDecoder().decode(payload.getBytes()));
		String[] splitMergedEncrypted = mergedEncryptedData.split("&&");
		log.info(
				"Splitting of base64EncryptedInputData, base64EncryptedSymmetricKey and base64EncryptedHashedValueOfData is completed. Total sections: "
						+ splitMergedEncrypted.length);

		if (splitMergedEncrypted.length != 2) {
			log.info("Invalid payload. Expected 3 sections but found " + splitMergedEncrypted.length);

		} else {
			log.info(
					"Size stats. base64EncryptedInputData=%s, base64EncryptedHashedValue=%s",
					splitMergedEncrypted[0].length(), splitMergedEncrypted[1].length());
		}

		String decodedEncryptedInputData = new String(Base64.getDecoder().decode(splitMergedEncrypted[0].getBytes()));

		String decodedEncryptedHashedData = new String(Base64.getDecoder().decode(splitMergedEncrypted[1].getBytes()));

		log.info("Decoding of data, and hash is completed. Size stats. data=%s, hash=%s",
				decodedEncryptedInputData.length(), decodedEncryptedHashedData.length());

		String symmetricKey = null;
		try {

			String passcodePrivateKey = readKeyFromPath(decRequest.getUserId(), decRequest.getOrgId());
			String privateKey = RSAKeyPairGenerator.decryptAndDecodePrivateKey(decRequest.getPassCode(),
					passcodePrivateKey);
			symmetricKey = RSAUtil.decrypt(decRequest.getEncryptedSymmetricKey(), privateKey);
			log.info("Symmetric deryption using private key is completed");

		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
				| NoSuchAlgorithmException e) {
			log.info("private key may be incorrect or some other issue." + e);

		} catch (Exception e) {
			log.error("Error during RSA decryption." + e);
			throw new Exception("Exception during decryption of data");
		}
		String hashedValueOfEncryptedData = null;
		try {

			if (decRequest.getSourcePublicKey().equals("SELF")) {
				decRequest.setSourcePublicKey(readPubKeyFromPath(decRequest.getOrgId(), decRequest.getUserId()));
			}
			hashedValueOfEncryptedData = RSAUtil.decryptUsingPublic(decodedEncryptedHashedData,
					decRequest.getSourcePublicKey());
			log.info("Hash decryption using source private key is completed. Size: "
					+ hashedValueOfEncryptedData.length());
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
				| NoSuchAlgorithmException e) {
			log.info("Invalid source publickey or data is incorrect." + e);
		} catch (Exception e) {
			log.info("Error during RSA decryption" + e);
			throw new Exception("Exception during decryption of data");
		}

		String decryptedInputData = SymmetricEncUtility.dataDecryption(symmetricKey, decodedEncryptedInputData);
		log.info("Data decryption using symmetric key is completed. Size: " + decryptedInputData.length());

		String hashedValueOfInputData = null;
		try {
			hashedValueOfInputData = SymmetricEncUtility.hashWithoutSalt(decryptedInputData);
		} catch (UnsupportedEncodingException e) {

			e.printStackTrace();
		}

		long endDecryptionAt = System.currentTimeMillis();
		DecryptDataResDto decryptDataResponse = new DecryptDataResDto();
		if (hashedValueOfInputData.equals(hashedValueOfEncryptedData)) {
			log.info("Hash matched successfully.");
			decryptDataResponse.setOutputData(decryptedInputData);
			return decryptDataResponse;
		}
		log.info("Total time in decryption: " + (endDecryptionAt - startDecryptionAt));
		log.info("EncryptionDecryptionService.decryptionData : End");
		return decryptDataResponse;
	}

	public GenerateKeyPairsResDto generateKeyPairs(GenerateKeyPairReqDto keyPairsRequest)throws Exception {
		log.info("EncryptionServiceImpl generateKeyPairs : Starts");
		GenerateKeyPairsResDto keyPairsResponse = new GenerateKeyPairsResDto();
		String path = keyGenerationPath + keyPairsRequest.getOrgId() + "_" + keyPairsRequest.getUserId() + "/";
		try {
			keyPairsResponse = RSAKeyPairGenerator.generateKeyPair(keyPairsRequest.getEncryptionPass(), path);
		} catch (Exception e) {

			log.info(" EncryptionServiceImpl Error generate in keyPairsResponse :" + e);
			throw new Exception("ERROR during key generation");
		}
		log.info("EncryptionServiceImpl generateKeyPairs : Ends");
		return keyPairsResponse;
	}

	public GenerateKeyPairsResDto getPublicKey(GenerateKeyPairReqDto keyPairsRequest) throws Exception{
		log.info("EncryptionServiceImpl.getPublicKey : Starts");
		GenerateKeyPairsResDto keyPairsResponse = new GenerateKeyPairsResDto();
		String path = keyGenerationPath + keyPairsRequest.getOrgId() + "_" + keyPairsRequest.getUserId() + "/";
		try {
			keyPairsResponse.setPublicKey(RSAKeyPairGenerator.readFromFile(path + "/publicKey.txt"));
		} catch (IOException e) {
			log.info("EncryptionServiceImpl error inside readFromFile  : Ends" + e);
			throw new Exception("ERROR during publickey feching");
		}
		log.info("EncryptionServiceImpl getPublicKey : Ends");
		return keyPairsResponse;
	}

	public GenerateKeyPairsResDto generateSymmetricKey(GenerateKeyPairReqDto keyPairsRequest) throws Exception{
		log.info(" EncryptionServiceImpl generateSymmetricKey : Starts");
		GenerateKeyPairsResDto keyPairsResponse = new GenerateKeyPairsResDto();
		String symmetricKey = AesUtil.random(Constants.SYMMETRIC_KEY_SIZE);
		try {
			symmetricKey = RSAUtil.encrypt(symmetricKey, keyPairsRequest.getGeneratedPublicKey());
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
				| NoSuchAlgorithmException e) {
			log.info(" EncryptionServiceImpl generateSymmetricKey : Ends" + e);
		}
		keyPairsResponse.setGeneratedSymmetricKey(symmetricKey);
		log.info("EncryptionServiceImpl generateSymmetricKey : Ends");
		return keyPairsResponse;
	}

	public GenerateKeyPairsResDto getSymmetricKeyByUsers(GenerateKeyPairReqDto keyPairsRequest)throws Exception {
		log.info("EncryptionServiceImpl getSymmetricKeyByUsers : Starts");
		GenerateKeyPairsResDto keyPairsResponse = new GenerateKeyPairsResDto();
		String encSymmetricKey = null;
		try {
			encSymmetricKey = keyPairsRequest.getEncryptedSymmetricKey();
			String passcodePrivateKey = readKeyFromPath(keyPairsRequest.getUserId(), keyPairsRequest.getOrgId());
			String privateKey = RSAKeyPairGenerator.decryptAndDecodePrivateKey(keyPairsRequest.getEncryptionPass(),
					passcodePrivateKey);
			String symmetricKey = RSAUtil.decrypt(encSymmetricKey, privateKey);
			encSymmetricKey = RSAUtil.encrypt(symmetricKey, keyPairsRequest.getDestinationPublicKey());
		} catch (Exception e) {
			log.info(" EncryptionServiceImpl getSymmetricKeyByUsers : Ends" + e);
			throw new Exception("ERROR during symmetric feching");
		}
		keyPairsResponse.setGeneratedSymmetricKey(encSymmetricKey);
		log.info(" EncryptionServiceImpl getSymmetricKeyByUsers : Ends");
		return keyPairsResponse;
	}

	
	public EncryptDataResDto encryptionDataWithRandomSymmetricKey(EncryptDataRequestDto encRequest) throws Exception{
		log.info("EncryptionDecryptionService.encryptionData : Start");
		String hashedValueOfInputData = null;
		String privateKey = null;
		String encryptedInputData = null;
		long startEncrytionAt = System.currentTimeMillis();
		String encryptedSymmetricKey = null;
		try {
			String passcodePrivateKey = readKeyFromPath(encRequest.getUserId(), encRequest.getOrgId());
			privateKey = RSAKeyPairGenerator.decryptAndDecodePrivateKey(encRequest.getPassCode(), passcodePrivateKey);
			String symmetricKey = AesUtil.random(Constants.SYMMETRIC_KEY_SIZE);
			//String symmetricKey = RSAUtil.decrypt(encRequest.getGeneratedSymmetricKey(), privateKey);

			encryptedInputData = SymmetricEncUtility.dataEncryption(symmetricKey, encRequest.getInputData());
			hashedValueOfInputData = SymmetricEncUtility.hashWithoutSalt(encRequest.getInputData());
			encryptedSymmetricKey = RSAUtil.encrypt(symmetricKey, encRequest.getDestinationPublicKey());
		} catch (Exception ee) {
			log.info(
					"EncryptionServiceImpl Error while getting passcodePrivateKey|symmetricKey|encryptedInputData|hashedValueOfInputData");
			throw new Exception("Exception during encryption of data");

		}
		String encryptedHashedValueOfData = null;
		try {

			encryptedHashedValueOfData = RSAUtil.encryptUsingPrivate(hashedValueOfInputData, privateKey);
			log.info("Hash encryption using source private key is completed");
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
				| NoSuchAlgorithmException e) {
			log.info("Invalid source private key.");

		} catch (Exception e) {
			log.info("Invalid source private key.");
			throw new Exception("Exception during encryption of data");
		}

		String base64EncryptedInputData = Base64.getEncoder().encodeToString(encryptedInputData.getBytes());
		String base64EncryptedHashedValueOfData = Base64.getEncoder()
				.encodeToString(encryptedHashedValueOfData.getBytes());
		String base64EncryptedSymmetricKey = Base64.getEncoder().encodeToString(encryptedSymmetricKey.getBytes());
		String mergeData = base64EncryptedInputData + "&&" + base64EncryptedHashedValueOfData+"&&"+base64EncryptedSymmetricKey;
		log.info(
				"Merging base64EncryptedInputData,base64EncryptedSymmetricKey,base64EncryptedHashedValueOfData is  completed");
		String encResponseData = Base64.getEncoder().encodeToString(mergeData.getBytes());
		log.info("Merged data encoding is completed");
		EncryptDataResDto encryptDataResponse = new EncryptDataResDto();
		encryptDataResponse.setOutputData(encResponseData);
		long endEncrytionAt = System.currentTimeMillis();
		log.info("Total time is encryption process is :" + (endEncrytionAt - startEncrytionAt));
		log.info("EncryptionDecryptionService.encryptionData : End");

		return encryptDataResponse;
	}

	public DecryptDataResDto decryptionDataWithRandomSymmetricKey(DecryptDataRequestDto decRequest) throws Exception{

		long startDecryptionAt = System.currentTimeMillis();

		String payload = decRequest.getInputData();
		log.info("EncryptionDecryptionService.decryptionData : Start. Payload size: "
				+ (payload == null ? "null" : payload.length()));

		String mergedEncryptedData = new String(Base64.getDecoder().decode(payload.getBytes()));
		String[] splitMergedEncrypted = mergedEncryptedData.split("&&");
		log.info(
				"Splitting of base64EncryptedInputData, base64EncryptedSymmetricKey and base64EncryptedHashedValueOfData is completed. Total sections: "
						+ splitMergedEncrypted.length);

		if (splitMergedEncrypted.length != 3) {
			log.info("Invalid payload. Expected 3 sections but found " + splitMergedEncrypted.length);

		} else {
			log.info(
					"Size stats. base64EncryptedInputData=%s, base64EncryptedHashedValue=%s, base64EncryptedSymmetricKey=%s",
					splitMergedEncrypted[0].length(), splitMergedEncrypted[1].length(), splitMergedEncrypted[2].length());
		}

		String decodedEncryptedInputData = new String(Base64.getDecoder().decode(splitMergedEncrypted[0].getBytes()));

		String decodedEncryptedHashedData = new String(Base64.getDecoder().decode(splitMergedEncrypted[1].getBytes()));
		
		String decodedEncryptedSymmetricKey = new String(Base64.getDecoder().decode(splitMergedEncrypted[2].getBytes()));
		log.info("Decoding of data, symmetric key and hash is completed. Size stats. data=%s, key=%s, hash=%s",
				decodedEncryptedInputData.length(),decodedEncryptedSymmetricKey.length(), decodedEncryptedHashedData.length());

		String symmetricKey = null;
		try {

			String passcodePrivateKey = readKeyFromPath(decRequest.getUserId(), decRequest.getOrgId());
			String privateKey = RSAKeyPairGenerator.decryptAndDecodePrivateKey(decRequest.getPassCode(),
					passcodePrivateKey);
			symmetricKey = RSAUtil.decrypt(decodedEncryptedSymmetricKey, privateKey);
			log.info("Symmetric deryption using private key is completed");

		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
				| NoSuchAlgorithmException e) {
			log.info("private key may be incorrect or some other issue." + e);

		} catch (Exception e) {
			log.error("Error during RSA decryption." + e);
			throw new Exception("Exception during decryption of data");
		}
		String hashedValueOfEncryptedData = null;
		try {

			if (decRequest.getSourcePublicKey().equals("SELF")) {
				decRequest.setSourcePublicKey(readPubKeyFromPath(decRequest.getOrgId(), decRequest.getUserId()));
			}
			hashedValueOfEncryptedData = RSAUtil.decryptUsingPublic(decodedEncryptedHashedData,
					decRequest.getSourcePublicKey());
			log.info("Hash decryption using source private key is completed. Size: "
					+ hashedValueOfEncryptedData.length());
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
				| NoSuchAlgorithmException e) {
			log.info("Invalid source publickey or data is incorrect." + e);
		} catch (Exception e) {
			log.info("Error during RSA decryption" + e);
			throw new Exception("Exception during decryption of data");
		}

		String decryptedInputData = SymmetricEncUtility.dataDecryption(symmetricKey, decodedEncryptedInputData);
		log.info("Data decryption using symmetric key is completed. Size: " + decryptedInputData.length());

		String hashedValueOfInputData = null;
		try {
			hashedValueOfInputData = SymmetricEncUtility.hashWithoutSalt(decryptedInputData);
		} catch (UnsupportedEncodingException e) {

			e.printStackTrace();
		}

		long endDecryptionAt = System.currentTimeMillis();
		DecryptDataResDto decryptDataResponse = new DecryptDataResDto();
		if (hashedValueOfInputData.equals(hashedValueOfEncryptedData)) {
			log.info("Hash matched successfully.");
			decryptDataResponse.setOutputData(decryptedInputData);
			return decryptDataResponse;
		}
		log.info("Total time in decryption: " + (endDecryptionAt - startDecryptionAt));
		log.info("EncryptionDecryptionService.decryptionData : End");
		return decryptDataResponse;
	}
}
