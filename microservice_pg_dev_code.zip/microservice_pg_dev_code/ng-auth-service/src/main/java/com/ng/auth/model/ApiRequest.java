package com.ng.auth.model;

import org.springframework.stereotype.Component;


@Component
public class ApiRequest {
   
	String captcha;
    String userid;
    String otp;
	public String getCaptcha() {
		return captcha;
	}
	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	@Override
	public String toString() {
		return "ApiRequest [captcha=" + captcha + ", userid=" + userid + ", otp=" + otp + "]";
	}
    
    
    
}
