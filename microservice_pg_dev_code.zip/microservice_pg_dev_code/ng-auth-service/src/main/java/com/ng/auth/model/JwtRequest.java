package com.ng.auth.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ToString
public class JwtRequest {

	private String access_token;
    private String expires_in;
    private String refresh_token;
    private String token_type;
    private String session_state;
    private String username;
	
   
}
