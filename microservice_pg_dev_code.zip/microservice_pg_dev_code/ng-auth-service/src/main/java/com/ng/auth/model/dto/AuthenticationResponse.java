package com.ng.auth.model.dto;

import java.io.Serializable;

import com.ng.auth.model.entity.MUser;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
public class AuthenticationResponse implements Serializable {
    /**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String jwt;
    private MUser user;

}
