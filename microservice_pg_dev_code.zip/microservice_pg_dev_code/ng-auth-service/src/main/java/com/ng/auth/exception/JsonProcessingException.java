package com.ng.auth.exception;

public class JsonProcessingException extends RuntimeException {
    /**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public JsonProcessingException(String message) {
        super(message);
    }
}
