package com.ng.auth.exception;

public class URISyntaxException extends RuntimeException {
    /**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public URISyntaxException(String message) {
        super(message);
    }
}
