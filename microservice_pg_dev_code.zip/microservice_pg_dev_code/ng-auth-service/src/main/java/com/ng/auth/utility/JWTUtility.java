package com.ng.auth.utility;

import java.io.Serializable;

import org.springframework.stereotype.Component;

import com.google.gson.JsonObject;
import com.ng.auth.exception.InvalidTokenException;

@Component
public class JWTUtility implements Serializable {

	private static final long serialVersionUID = 234234523523L;
	private JwtTokenValidator jwtTokenValidator = new JwtTokenValidator();
	
	public JsonObject decodeTokenPayloadToJsonObject(String token) throws InvalidTokenException {
		return jwtTokenValidator.validateAuthorizationHeader(token);
	}
	
}
