package com.ng.auth.exception;

public class JsonValidationFailedException extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	/*
	 * private final Set<ValidationMessage> validationMessages;
	 * 
	 * public JsonValidationFailedException(Set<ValidationMessage>
	 * validationMessages) { super("Json validation failed: " + validationMessages);
	 * this.validationMessages = validationMessages; }
	 * 
	 * public Set<ValidationMessage> getValidationMessages() { return
	 * validationMessages; }
	 */
	 
}