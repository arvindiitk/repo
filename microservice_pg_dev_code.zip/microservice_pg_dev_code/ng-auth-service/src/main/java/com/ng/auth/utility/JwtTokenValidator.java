package com.ng.auth.utility;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.common.base.Preconditions;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.ng.auth.exception.InvalidTokenException;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@NoArgsConstructor
public class JwtTokenValidator {

   
    public JsonObject validateAuthorizationHeader(String authorizationHeader) throws InvalidTokenException {
        return validateToken(authorizationHeader);
    }

    private JsonObject validateToken(String value) throws InvalidTokenException {
        DecodedJWT decodedJWT = decodeToken(value);
        verifyTokenHeader(decodedJWT);
        return decodeTokenPayloadToJsonObject(decodedJWT);
    }

    private DecodedJWT decodeToken(String value) throws InvalidTokenException {
        DecodedJWT decodedJWT = JWT.decode(value);
        log.debug("Token decoded successfully");
        return decodedJWT;
    }

    private void verifyTokenHeader(DecodedJWT decodedJWT) throws InvalidTokenException {
        try {
            Preconditions.checkArgument(decodedJWT.getType().equals("JWT"));
            log.debug("Token's header is correct");
        } catch (IllegalArgumentException ex) {
            throw new InvalidTokenException("Token is not JWT type", ex);
        }
    }

    private JsonObject decodeTokenPayloadToJsonObject(DecodedJWT decodedJWT) throws InvalidTokenException {
        try {
            String payloadAsString = decodedJWT.getPayload();
            return new Gson().fromJson(
                    new String(Base64.getDecoder().decode(payloadAsString), StandardCharsets.UTF_8),
                    JsonObject.class);
        }   catch (RuntimeException exception){
            throw new InvalidTokenException("Invalid JWT or JSON format of each of the jwt parts", exception);
        }
    }
   
}
