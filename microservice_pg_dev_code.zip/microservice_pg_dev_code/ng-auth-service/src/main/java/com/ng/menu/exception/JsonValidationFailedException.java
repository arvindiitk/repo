package com.ng.menu.exception;

public class JsonValidationFailedException extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	 
}