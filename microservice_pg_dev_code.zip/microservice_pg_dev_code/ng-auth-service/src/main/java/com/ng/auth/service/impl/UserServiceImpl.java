package com.ng.auth.service.impl;


import java.util.List;
import java.util.Optional;

import com.ng.auth.model.ApiResponse;
import com.ng.auth.model.entity.MUser;
import com.ng.auth.repository.OrgUserRepo;
import com.ng.auth.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private OrgUserRepo orgUserRepo;

    public List<MUser> findLoginId(String loginId) {
        return  orgUserRepo.findByLoginId(loginId);
    }
    
    public Optional<MUser> updateCaptcha(String loginId,String captcha) {
        return  orgUserRepo.insertCaptcha(loginId,captcha);
    }
 
    public <T> ApiResponse<Object> setMessage(ApiResponse<Object> apiResponse, String status,String message,String errorList,T data,String token) {
    	apiResponse.setStatus(status);
    	apiResponse.setMessage(message);
    	apiResponse.setErrors(errorList);
    	apiResponse.setData(data);
    	apiResponse.setJwttoken(token);
		return apiResponse;
    }
  
}
