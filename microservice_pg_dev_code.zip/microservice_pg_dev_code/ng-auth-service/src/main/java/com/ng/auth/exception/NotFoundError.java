package com.ng.auth.exception;

/**
 * Throw an exception if declaration list not found
 */
public class NotFoundError extends RuntimeException{
    /**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public NotFoundError(String message) {
        super(message);
    }
}
