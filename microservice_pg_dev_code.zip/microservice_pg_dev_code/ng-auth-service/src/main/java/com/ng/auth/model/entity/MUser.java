package com.ng.auth.model.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.Valid;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;
import lombok.ToString;


/**
 * The persistent class for the M_USER database table.
 * 
 */
@Data
@ToString
@Valid
@Entity
@Table(name="M_USER")
public class MUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="USER_ID", unique=true, nullable=false)
	private Integer userId;
		
	@Column(name="IS_PASSWORD_FLAG", nullable=false)
	private Boolean isPasswordFlag;
	
	@Column(name="ORG_TYPE_ALIAS", nullable=false)
	private String orgTypeAlias;

}