package com.ng.auth.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.ng.auth.model.ApiResponse;
import com.ng.auth.model.JwtRequest;
import com.ng.auth.model.entity.MUser;
import com.ng.auth.service.impl.UserServiceImpl;
import com.ng.auth.utility.Constants;
import com.ng.auth.utility.JWTUtility;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class NgAuthcontroller<T> {

	@Autowired
	private JWTUtility jwtUtility;

	@Autowired
	private UserServiceImpl userService;

	private Map map =new HashMap<String,T>();
	
	@PostMapping(value = "/login", produces = "application/json")
	public <T> ResponseEntity<Object> authenticate(@RequestBody JwtRequest jwtRequest) {
		ApiResponse<Object> apiResponse=new ApiResponse<>();
		try {
			JsonObject jsonObject = jwtUtility.decodeTokenPayloadToJsonObject(jwtRequest.getAccess_token());
			String username="";
			
			String preferred_username =String.valueOf(jsonObject.get("preferred_username"));
			preferred_username=preferred_username.replace("\"", "");
			System.out.println("preferred_username>>>"+preferred_username+"<<");
			if(preferred_username.equals("service-account-springboot-auth"))
				username=jwtRequest.getUsername();
			else
				username=preferred_username;
			System.out.println("username>>>"+username+"<<");
			List<?> userDetailMap = userService.findLoginId(username);
			if (userDetailMap.isEmpty())
			{
				String error = "Authentication failed !!";
				String message="User Id is not matched !!";
				apiResponse = userService.setMessage(apiResponse, Constants.LOGIN_INCORRECT_ID, message,
						error, null, null);
			}
			else
			{
				map.clear();
				MUser userDetail= (MUser)userDetailMap.get(0);
				map.put("user_id", userDetail.getUserId().toString());
				map.put("is_password_flag", userDetail.getIsPasswordFlag());
				map.put("org_type_alias", userDetail.getOrgTypeAlias());
				JsonArray array = jsonObject.getAsJsonObject("realm_access").getAsJsonArray("roles");
				List list =new ArrayList<>();
				for(JsonElement o: array){
				   	list.add(o.getAsString());
				}
				map.put("user_role",list );
				jsonObject.addProperty("user_id", userDetail.getUserId().toString());
				jsonObject.addProperty("is_password_flag", userDetail.getIsPasswordFlag());
				jsonObject.addProperty("org_type_alias", userDetail.getOrgTypeAlias());
				apiResponse = userService.setMessage(apiResponse, String.valueOf(HttpStatus.OK.value()), Constants.SUCCESS,
					null, map,jwtRequest.getAccess_token() );
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			apiResponse = userService.setMessage(apiResponse, String.valueOf(HttpStatus.OK.value()),ex.getMessage(),
					null, new HashMap<String,T>(),jwtRequest.getAccess_token() );
			ex.printStackTrace();
		}
		return ResponseEntity.ok().body(apiResponse);
	}
}