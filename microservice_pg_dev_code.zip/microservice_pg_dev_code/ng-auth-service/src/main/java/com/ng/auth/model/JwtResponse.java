package com.ng.auth.model;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

/*@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter*/
@Component

public class JwtResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
    private String jwtToken;
    private transient List<Object> userDetailList;
    private List<String> errorMessage=new ArrayList<>();
    
	public String getJwtToken() {
		return jwtToken;
	}
	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}
	public List<Object> getUserDetailList() {
		return userDetailList;
	}
	public void setUserDetailList(List<Object> userDetailList) {
		this.userDetailList = userDetailList;
	}
	public List<String> getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(List<String> errorMessage) {
		this.errorMessage = errorMessage;
	}

    
}