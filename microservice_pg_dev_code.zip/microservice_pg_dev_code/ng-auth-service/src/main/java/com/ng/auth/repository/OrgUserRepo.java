package com.ng.auth.repository;

import java.util.List;
import java.util.Optional;

import com.ng.auth.model.entity.MUser;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgUserRepo extends JpaRepository<MUser, Integer> {

	@Query(value = "SELECT mUser.USER_ID, mUser.IS_PASSWORD_FLAG, orgType.ORG_TYPE_ALIAS FROM M_USER mUser "
			+ "INNER JOIN M_USER_ORG userOrg ON userOrg.USER_ID=mUser.USER_ID "
			+ "INNER JOIN M_ORG mOrg ON mOrg.ORG_ID=userOrg.ORG_ID "
			+ "INNER JOIN M_ORG_TYPE orgType ON orgType.ORG_TYPE_ID=mOrg.ORG_TYPE_ID "
			+ "WHERE mUser.USER_LOGIN_ID=:loginId ", nativeQuery = true)
	List<MUser> findByLoginId(String loginId);

	@Query(value = "UPDATE  M_USER SET IS_ACTIVE =?2 WHERE USER_LOGIN_ID =?1", nativeQuery = true)
	Optional<MUser> insertCaptcha(String loginId, String captcha);
}
