package com.ng.org.type.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import com.ng.org.type.entity.OrgType;
import com.ng.org.type.entity.User;
import com.ng.org.type.repository.OrgTypesRepository;
import com.ng.org.type.repository.UserRepository;
import com.ng.org.type.request.OrgTypeReq;
import com.ng.org.type.service.OrgTypesService;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
@Transactional
public class OrgTypesServiceImpl implements OrgTypesService {
	@Autowired
    private OrgTypesRepository orgTypesRepository;
	
	@Autowired
    private UserRepository userRepository;

	@Override
    public OrgType saveOrUpdate(OrgTypeReq orgTypeReq) {
    	OrgType orgType=new OrgType();
    	BeanUtils.copyProperties(orgTypeReq, orgType);
        return orgTypesRepository.save(orgType);
    }
	@Override
	public List<OrgType> findByIsActive(boolean isActive) {
		List<OrgType> orgTypes=orgTypesRepository.findByIsActiveOrderByCreatedOnDesc(isActive);
		getNameList(orgTypes);
		return orgTypes;
	}
		
	public List<OrgType> getNameList(List<OrgType> orgTypes) {
		for (OrgType orgType : orgTypes) {
			List<User>  user = userRepository.findById(orgType.getCreatedBy()).stream().collect(Collectors.toList());
			orgType.setCreatedByName(!user.isEmpty() ? user.get(0).getUserName() : null);			
		}
		return orgTypes;
	} 

}
