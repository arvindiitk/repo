package com.ng.org.type.request;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class OrgTypeReq implements Serializable{
	private static final long serialVersionUID = 1L;

	private Integer orgTypeId;
	private Integer createdBy;
	private Timestamp createdOn;	
	private Boolean isActive;	
	private String orgTpeDesc;	
	private String orgTypeAlias;	
	private String orgTypeName;
}
