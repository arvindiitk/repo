package com.ng.org.type.controller;

import java.util.List;
import java.util.stream.Collectors;

import com.ng.org.type.constants.Constants;
import com.ng.org.type.entity.OrgType;
import com.ng.org.type.exception.ResourceNotFoundException;
import com.ng.org.type.request.OrgTypeReq;
import com.ng.org.type.response.ApiResponse;
import com.ng.org.type.service.OrgTypesService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@RequestMapping("/ng-org-type")
@Transactional(timeout = 180)
public class OrgTypesController {
    @Autowired
    OrgTypesService orgTypesService;

    @GetMapping("/orgType/ng-getAllOrgTypes")
    public ResponseEntity<Object> getAllOrgTypes()throws ResourceNotFoundException {
        log.info("OrgTypesController :getAllOrgTypes {} ");

        List<OrgType> filteredList = orgTypesService.findByIsActive(true).stream()
        		.filter(e->!e.getOrgTypeAlias().equalsIgnoreCase("NGN")).collect(Collectors.toList());        
//        if(filteredList.isEmpty()) {
//        	throw new ResourceNotFoundException("Request list"+" "+Constants.NOT_FOUND);
//        }
        filteredList = filteredList.stream().collect(Collectors.toList());

        ApiResponse<?> apiResponse = ApiResponse.builder()
                .status(String.valueOf(HttpStatus.OK.value()))
                .message(Constants.SUCCESS)
                .data(filteredList)
                .build();
        log.info("[OrgTypesController.getAllOrgTypes] : success response");
        return ResponseEntity.ok().body(apiResponse);

    }
    
    /**
     * save Organization Type details 
     */

    @PostMapping(value="/orgType/ng-saveUpdateOrgTypes",consumes = {"application/json"})
    public ResponseEntity<Object>  saveUpdateOrgTypes(@RequestBody OrgTypeReq orgRequest){
        log.info("OrgTypesController: createOrgTypes ng-saveUpdateOrgTypes {}",orgRequest);
        OrgType orgType= orgTypesService.saveOrUpdate(orgRequest);
        ApiResponse<?> apiResponse = ApiResponse.builder()
                .status(String.valueOf(HttpStatus.OK.value()))
                .message(Constants.ORGTYPECREATE)
                .data(orgType)
                .build();
        log.info("OrgTypesController: createOrgTypes ng-saveUpdateOrgTypes response");
        return ResponseEntity.ok().body(apiResponse);
    }
}
