package com.ng.org.type.service;

import java.util.List;

import com.ng.org.type.entity.OrgType;
import com.ng.org.type.request.OrgTypeReq;

public interface OrgTypesService {
  
    public List<OrgType> findByIsActive(boolean isActive); 
    public OrgType saveOrUpdate(OrgTypeReq orgTypes);

}
