package com.ng.org.type.repository;

import java.util.List;

import com.ng.org.type.entity.OrgType;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface OrgTypesRepository extends JpaRepository<OrgType, Integer> {
   
	public List<OrgType> findByOrgTypeId(Integer orgTypeId);
    
    public List<OrgType> findAll();
    
    public List<OrgType> findByIsActiveOrderByCreatedOnDesc(Boolean isActive);
    
    public List<OrgType> findByOrgTypeName(String orgTypeName);
}
